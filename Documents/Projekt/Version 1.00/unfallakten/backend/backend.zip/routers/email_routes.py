"""
Modul 7 – Router: E-Mail-Import
=================================
REST-Endpunkte für den E-Mail-Import.

Endpunkte:
  POST /email/import                        Import-Lauf starten
  GET  /email/import/status                 Verbindungsstatus
  GET  /email/import/log                    Import-Log
  GET  /email/import/log/statistik          Zusammenfassung
  POST /email/import/log/<id>/zuordnen      Manuelle Akte-Zuordnung  ← NEU v9
  GET  /email/import/aktensuche            Akten-Suche für Dropdown  ← NEU v9

FIXES v9:
  - Status-Validierung: zugeordnet/nicht_zugeordnet statt verarbeitet/kein_treffer
  - akte_id: bleibt TEXT (az), kein int-Cast mehr
  - ordne_akte_manuell_zu() importiert und eingebunden
"""

import logging
from flask import Blueprint, request, jsonify, g
from ..auth.middleware import login_erforderlich
from ..email_import.import_service import (
    fuehre_import_lauf_durch, hole_import_log,
    hole_import_statistik, ordne_akte_manuell_zu,
    importiere_in_akte, ImportFehler
)
from ..email_import.imap_client import (
    ist_konfiguriert, teste_verbindung, get_imap_config
)
from ..db.database import get_connection

logger = logging.getLogger(__name__)
email_bp = Blueprint("email", __name__, url_prefix="/email")

ERLAUBTE_STATUS = ("zugeordnet", "nicht_zugeordnet", "fehler", "ignoriert")


def _j(daten, status=200):
    return jsonify(daten), status

def _err(msg, status, **extra):
    return jsonify({"fehler": msg, "status": status, **extra}), status


# ── POST /email/import ────────────────────────────────────────────────────────

@email_bp.route("/import", methods=["POST"])
@login_erforderlich
def starte_import():
    """
    POST /email/import
    Startet einen manuellen E-Mail-Import-Lauf.

    Body (optional):
      { "max_nachrichten": 20 }

    Response 200:
      { "verarbeitet", "kein_treffer", "fehler", "ignoriert",
        "anhaenge", "laufzeit_s", "details" }
    """
    daten = request.get_json(silent=True) or {}
    max_n = daten.get("max_nachrichten")
    if max_n is not None:
        try:
            max_n = int(max_n)
            if max_n < 1 or max_n > 200:
                return _err("max_nachrichten muss zwischen 1 und 200 liegen.", 422)
        except (TypeError, ValueError):
            return _err("max_nachrichten muss eine Zahl sein.", 422)

    try:
        bericht = fuehre_import_lauf_durch(
            bearbeiter_id=g.benutzer_id,
            max_nachrichten=max_n,
        )
        return _j(bericht)
    except ImportFehler as e:
        return _err(e.nachricht, e.status_code)
    except Exception as e:
        logger.error("Unerwarteter Import-Fehler: %s", e)
        return _err(f"Interner Fehler: {e}", 500)


# ── GET /email/import/status ──────────────────────────────────────────────────

@email_bp.route("/import/status", methods=["GET"])
@login_erforderlich
def import_status():
    """
    GET /email/import/status

    Response 200:
      { "konfiguriert", "verbindung_ok", "nachricht", "ungelesen",
        "konfiguration": { "host", "port", "user", "folder" } }
    """
    konfiguriert = ist_konfiguriert()

    if not konfiguriert:
        return _j({
            "konfiguriert":  False,
            "verbindung_ok": False,
            "nachricht": (
                "E-Mail-Import nicht konfiguriert. "
                "Bitte EMAIL_HOST, EMAIL_USER und EMAIL_PASSWORD setzen."
            ),
            "ungelesen":     0,
            "konfiguration": None,
        })

    verbindungstest = teste_verbindung()
    cfg = get_imap_config()

    return _j({
        "konfiguriert":  True,
        "verbindung_ok": verbindungstest["ok"],
        "nachricht":     verbindungstest["nachricht"],
        "ungelesen":     verbindungstest.get("ungelesen", 0),
        "konfiguration": {
            "host":   cfg["host"],
            "port":   cfg["port"],
            "user":   cfg["user"],
            "folder": cfg["folder"],
        },
    })


# ── GET /email/import/log ─────────────────────────────────────────────────────

@email_bp.route("/import/log", methods=["GET"])
@login_erforderlich
def import_log():
    """
    GET /email/import/log

    Query-Parameter:
      limit   = 50   (max 200)
      status  = zugeordnet|nicht_zugeordnet|fehler|ignoriert
      akte_id = <az TEXT>

    Response 200:
      { "log": [...], "gesamt": int }
    """
    limit   = min(int(request.args.get("limit", 200)), 500)
    status  = request.args.get("status")
    # FIX: akte_id ist TEXT (az), kein int-Cast
    akte_id = request.args.get("akte_id")

    if status and status not in ERLAUBTE_STATUS:
        return _err(
            f"Ungültiger Status. Erlaubt: {', '.join(ERLAUBTE_STATUS)}", 422
        )

    eintraege = hole_import_log(limit=limit, status=status, akte_id=akte_id)
    # Frontend erwartet key "log"
    return _j({"log": eintraege, "gesamt": len(eintraege)})


# ── GET /email/import/log/statistik ──────────────────────────────────────────

@email_bp.route("/import/log/statistik", methods=["GET"])
@login_erforderlich
def import_statistik():
    """
    GET /email/import/log/statistik

    Response 200:
      { "gesamt", "zugeordnet", "nicht_zugeordnet",
        "fehler", "ignoriert", "letzter_import" }
    """
    return _j(hole_import_statistik())


# ── POST /email/import/log/<id>/zuordnen ─────────────────────────────────────

@email_bp.route("/import/log/<int:log_id>/zuordnen", methods=["POST"])
@login_erforderlich
def log_eintrag_zuordnen(log_id: int):
    """
    POST /email/import/log/<id>/zuordnen
    Ordnet eine ungematchte E-Mail manuell einer Akte zu.

    Body:
      { "az": "31/21" }

    Response 200:
      { "ok": true, "az": "31/21" }

    Response 404:
      { "fehler": "Akte '99/99' nicht gefunden." }

    Response 422:
      { "fehler": "az fehlt im Request-Body." }
    """
    daten = request.get_json(silent=True) or {}
    az = (daten.get("az") or "").strip()

    if not az:
        return _err("az fehlt im Request-Body.", 422)

    ergebnis = ordne_akte_manuell_zu(log_id, az)

    if not ergebnis["ok"]:
        return _err(ergebnis["fehler"], 404)

    return _j(ergebnis)


# ── GET /email/import/aktensuche ──────────────────────────────────────────────

@email_bp.route("/import/aktensuche", methods=["GET"])
@login_erforderlich
def aktensuche_fuer_zuordnung():
    """
    GET /email/import/aktensuche?q=<suchbegriff>
    Sucht Akten fuer das Zuordnungs-Dropdown.
    Reihenfolge: zuerst RA-Micro, dann SQLite als Fallback.

    Query-Parameter:
      q = Suchbegriff (min. 2 Zeichen)

    Response 200:
      { "akten": [{ "az", "label" }, ...] }
    """
    q = (request.args.get("q") or "").strip()

    if len(q) < 2:
        return _j({"akten": []})

    akten = []
    gefundene_az = set()

    # ── 1. RA-Micro suchen ────────────────────────────────────────────────────
    try:
        from ..ramicro.connector import get_ramicro_connection, RaMicroNichtAktiv, RaMicroVerbindungsFehler
        such_muster_sql = f"%{q}%"
        with get_ramicro_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                """
                SELECT TOP 20
                    a.sAktenNummer AS az,
                    a.sAktenNummer + COALESCE(' - ' + a.sMandant, '') AS label
                FROM tblAkten a
                WHERE (
                    a.sAktenNummer LIKE %s
                    OR UPPER(a.sMandant) LIKE UPPER(%s)
                    OR UPPER(a.sGegner)  LIKE UPPER(%s)
                    OR UPPER(a.sAktenKurzBezeichnung) LIKE UPPER(%s)
                )
                AND (a.dtAblage IS NULL OR CAST(a.dtAblage AS DATE) = '1899-12-30')
                ORDER BY a.sAktenNummer
                """,
                (such_muster_sql, such_muster_sql, such_muster_sql, such_muster_sql)
            )
            rows = cur.fetchall()
            for r in rows:
                az = r["az"]
                if az and az not in gefundene_az:
                    akten.append({"az": az, "label": r["label"] or az})
                    gefundene_az.add(az)
        logger.debug("Aktensuche RA-Micro: %d Treffer fuer '%s'", len(akten), q)
    except Exception as e:
        logger.debug("Aktensuche RA-Micro nicht verfuegbar: %s", e)

    # ── 2. SQLite als Fallback / Ergaenzung ───────────────────────────────────
    such_muster = f"%{q.upper()}%"
    with get_connection() as conn:
        zeilen = conn.execute(
            """
            SELECT DISTINCT
                a.az,
                a.az || COALESCE(' - ' || b.name, '') AS label
            FROM unfallakte a
            LEFT JOIN beteiligte b
                ON b.akte_id = a.az
                AND b.rolle  = 'mandant'
            WHERE UPPER(a.az) LIKE ?
               OR UPPER(COALESCE(b.name, '')) LIKE ?
               OR UPPER(COALESCE(b.kfz_kennzeichen, '')) LIKE ?
            ORDER BY a.az
            LIMIT 20
            """,
            (such_muster, such_muster, such_muster)
        ).fetchall()

    for z in zeilen:
        if z["az"] not in gefundene_az:
            akten.append({"az": z["az"], "label": z["label"] or z["az"]})
            gefundene_az.add(z["az"])

    # Gesamt max 20 Treffer
    return _j({"akten": akten[:20]})

# ── GET /email/import/log/<id>/dokumente ─────────────────────────────────────

@email_bp.route("/import/log/<int:log_id>/dokumente", methods=["GET"])
@login_erforderlich
def log_eintrag_dokumente(log_id: int):
    """
    GET /email/import/log/<id>/dokumente
    Gibt die gespeicherten Dokumente fuer einen Import-Log-Eintrag zurueck.
    Liest importierte_dok (JSON-Array von dok_ids) und joint mit dokumente.

    Response 200:
      { "dokumente": [{ "id", "dateiname", "dateityp", "dateigroesse", "akte_id" }] }
    """
    import json as _json

    with get_connection() as conn:
        log = conn.execute(
            "SELECT akte_id, importierte_dok FROM email_import_log WHERE id = ?",
            (log_id,)
        ).fetchone()

    if not log:
        return _err("Log-Eintrag nicht gefunden.", 404)

    importierte_dok = log["importierte_dok"]
    if not importierte_dok:
        return _j({"dokumente": []})

    try:
        dok_ids = _json.loads(importierte_dok)
    except (ValueError, TypeError):
        return _j({"dokumente": []})

    if not dok_ids:
        return _j({"dokumente": []})

    platzhalter = ",".join("?" * len(dok_ids))
    with get_connection() as conn:
        zeilen = conn.execute(
            f"""
            SELECT id, dateiname, dateityp, dateigroesse, akte_id
            FROM dokumente
            WHERE id IN ({platzhalter})
            ORDER BY id
            """,
            dok_ids
        ).fetchall()

    return _j({"dokumente": [dict(z) for z in zeilen]})

# ── POST /email/import/log/<id>/in-akte ──────────────────────────────────────

@email_bp.route("/import/log/<int:log_id>/in-akte", methods=["POST"])
@login_erforderlich
def log_in_akte_importieren(log_id: int):
    """
    POST /email/import/log/<id>/in-akte
    Importiert Anhaenge + .eml einer E-Mail in den Dokumentenbereich der Akte.

    Response 200:
      { "ok": true, "dok_ids": [...], "importiert_am": "14:23" }
    Response 400:
      { "fehler": "Keine Akte zugeordnet." }
    """
    try:
        ergebnis = importiere_in_akte(log_id, bearbeiter_id=g.benutzer_id)
        if not ergebnis["ok"]:
            return _err(ergebnis["fehler"], 400)
        return _j(ergebnis)
    except Exception as e:
        logger.error("in-akte Import Fehler: %s", e)
        return _err(f"Interner Fehler: {e}", 500)


# ── Absender-Vorlagen CRUD ────────────────────────────────────────────────────

@email_bp.route("/import/absender-vorlagen", methods=["GET"])
@login_erforderlich
def absender_vorlagen_liste():
    """GET /email/import/absender-vorlagen – Alle Vorlagen."""
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT * FROM email_absender_vorlagen ORDER BY kategorie, name"
        ).fetchall()
    return _j({"vorlagen": [dict(r) for r in rows]})


@email_bp.route("/import/absender-vorlagen", methods=["POST"])
@login_erforderlich
def absender_vorlage_erstellen():
    """POST /email/import/absender-vorlagen – Neue Vorlage anlegen."""
    d = request.get_json(silent=True) or {}
    name      = (d.get("name") or "").strip()
    domain    = (d.get("domain") or "").strip().lower().lstrip("@")
    kategorie = (d.get("kategorie") or "sonstiges").strip()
    notizen   = (d.get("notizen") or "").strip() or None

    if not name:
        return _err("name ist erforderlich.", 422)
    if not domain or "." not in domain:
        return _err("domain ist erforderlich (z.B. gutachter-xyz.de).", 422)
    if kategorie not in ("gutachter", "versicherung", "gericht", "sonstiges"):
        return _err("Ungueltige Kategorie.", 422)

    try:
        with get_connection() as conn:
            conn.execute(
                "INSERT INTO email_absender_vorlagen (name, domain, kategorie, notizen) "
                "VALUES (?, ?, ?, ?)",
                (name, domain, kategorie, notizen)
            )
            neu = conn.execute(
                "SELECT * FROM email_absender_vorlagen WHERE domain = ?", (domain,)
            ).fetchone()
        return _j(dict(neu)), 201
    except Exception as e:
        if "UNIQUE" in str(e):
            return _err(f"Domain '{domain}' ist bereits vorhanden.", 409)
        return _err(str(e), 500)


@email_bp.route("/import/absender-vorlagen/<int:vid>", methods=["PATCH"])
@login_erforderlich
def absender_vorlage_aktualisieren(vid: int):
    """PATCH /email/import/absender-vorlagen/<id> – Vorlage aktualisieren."""
    d = request.get_json(silent=True) or {}
    felder = {}
    if "name"      in d: felder["name"]      = d["name"].strip()
    if "domain"    in d: felder["domain"]     = d["domain"].strip().lower().lstrip("@")
    if "kategorie" in d: felder["kategorie"]  = d["kategorie"].strip()
    if "notizen"   in d: felder["notizen"]    = d["notizen"].strip() or None
    if "aktiv"     in d: felder["aktiv"]      = 1 if d["aktiv"] else 0

    if not felder:
        return _err("Keine Felder angegeben.", 422)

    set_sql = ", ".join(f"{k} = ?" for k in felder)
    with get_connection() as conn:
        conn.execute(
            f"UPDATE email_absender_vorlagen SET {set_sql} WHERE id = ?",
            (*felder.values(), vid)
        )
        aktu = conn.execute(
            "SELECT * FROM email_absender_vorlagen WHERE id = ?", (vid,)
        ).fetchone()

    if not aktu:
        return _err("Vorlage nicht gefunden.", 404)
    return _j(dict(aktu))


@email_bp.route("/import/absender-vorlagen/<int:vid>", methods=["DELETE"])
@login_erforderlich
def absender_vorlage_loeschen(vid: int):
    """DELETE /email/import/absender-vorlagen/<id> – Vorlage loeschen."""
    with get_connection() as conn:
        conn.execute(
            "DELETE FROM email_absender_vorlagen WHERE id = ?", (vid,)
        )
    return _j({"ok": True})
