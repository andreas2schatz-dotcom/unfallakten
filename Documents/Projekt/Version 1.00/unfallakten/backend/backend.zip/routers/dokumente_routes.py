"""
Modul 4 – Router: Dokumente
=============================
REST-Endpunkte für Dokumenten-Upload und -Verwaltung.

Endpunkte:
  GET    /akten/<id>/dokumente               Dokumente einer Akte listen
  POST   /akten/<id>/dokumente               PDF/Bild hochladen + parsen
  GET    /akten/<id>/dokumente/<did>         Dokument-Metadaten abrufen
  GET    /akten/<id>/dokumente/<did>/datei   Datei herunterladen
  GET    /akten/<id>/dokumente/<did>/parse   Parse-Ergebnis abrufen
  POST   /akten/<id>/dokumente/<did>/korrektur  Parse-Ergebnis manuell korrigieren
  DELETE /akten/<id>/dokumente/<did>         Dokument löschen
"""

import json
import logging
from flask import Blueprint, request, jsonify, g, send_file
from ..auth.middleware import login_erforderlich
from ..models.akte import hole_akte_by_id
from ..models.dokument import (
    hole_dokumente_by_akte, GUELTIGE_TYPEN,
    aktualisiere_parse_status
)
from ..pdf.upload_service import (
    verarbeite_upload, hole_dokument_datei,
    loesche_dokument_mit_datei, korrigiere_parse_ergebnis,
    UploadFehler, _dok_dict
)
from ..db.database import get_connection
import io

logger = logging.getLogger(__name__)
dokumente_bp = Blueprint("dokumente", __name__,
                          url_prefix="/akten/<path:akte_id>/dokumente")


def _j(daten, status=200):
    return jsonify(daten), status

def _err(msg, status, **extra):
    return jsonify({"fehler": msg, "status": status, **extra}), status

def _pruefe_akte(akte_id):
    return hole_akte_by_id(akte_id)

def _hole_dok_row(dokument_id: int):
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM dokumente WHERE id = ?", (dokument_id,)
        ).fetchone()


# ── Liste ──────────────────────────────────────────────────────────────────────

@dokumente_bp.route("", methods=["GET"])
@login_erforderlich
def liste(akte_id: str):
    """
    GET /akten/<id>/dokumente
    Listet alle Dokumente einer Akte auf.

    Query-Parameter:
      typ   Filter nach Dokumenttyp
    """
    if not _pruefe_akte(akte_id):
        return _err(f"Akte {akte_id} nicht gefunden.", 404)

    typ = request.args.get("typ")
    dokumente = hole_dokumente_by_akte(akte_id, typ=typ)
    return _j({"dokumente": [_dok_dict(d) for d in dokumente]})


# ── Upload ─────────────────────────────────────────────────────────────────────

@dokumente_bp.route("", methods=["POST"])
@login_erforderlich
def upload(akte_id: str):
    """
    POST /akten/<id>/dokumente
    Lädt ein Dokument hoch und startet die PDF-Verarbeitung.

    Request: multipart/form-data
      - datei: Datei-Feld
      - typ:   Dokumenttyp (gutachten/abrechnungsschreiben/...)
      - auto_schaden: "true" → Schadenpositionen automatisch übernehmen

    Response 201:
      {
        "dokument":       { Dokument-Metadaten },
        "parse_ergebnis": { Extrahierte Felder, Konfidenz, Warnungen }
      }
    """
    if not _pruefe_akte(akte_id):
        return _err(f"Akte {akte_id} nicht gefunden.", 404)

    # Datei aus multipart holen
    if "datei" not in request.files:
        return _err(
            "Kein 'datei'-Feld im Request. "
            "Bitte als multipart/form-data senden.", 422
        )

    datei = request.files["datei"]
    if not datei.filename:
        return _err("Kein Dateiname.", 422)

    typ = request.form.get("typ", "sonstiges").strip()
    auto_schaden = request.form.get("auto_schaden", "false").lower() == "true"

    datei_bytes = datei.read()

    try:
        ergebnis = verarbeite_upload(
            akte_id=akte_id,
            dateiname=datei.filename,
            datei_bytes=datei_bytes,
            typ=typ,
            bearbeiter_id=g.benutzer_id,
            auto_schaden=auto_schaden,
        )
    except UploadFehler as e:
        return _err(e.nachricht, e.status_code)
    except Exception as e:
        logger.error("Upload-Fehler: %s", e)
        return _err(f"Interner Fehler beim Upload: {e}", 500)

    return _j(ergebnis, 201)


# ── Metadaten ─────────────────────────────────────────────────────────────────

@dokumente_bp.route("/<int:dokument_id>", methods=["GET"])
@login_erforderlich
def metadaten(akte_id: str, dokument_id: int):
    """
    GET /akten/<id>/dokumente/<did>
    Gibt Metadaten eines Dokuments zurück.
    """
    if not _pruefe_akte(akte_id):
        return _err(f"Akte {akte_id} nicht gefunden.", 404)

    row = _hole_dok_row(dokument_id)
    if not row or row["akte_id"] != akte_id:
        return _err(f"Dokument {dokument_id} nicht gefunden.", 404)

    from ..models.dokument import Dokument
    dok = Dokument.from_row(row)
    return _j(_dok_dict(dok))


# ── Datei-Download ────────────────────────────────────────────────────────────

@dokumente_bp.route("/<int:dokument_id>/datei", methods=["GET"])
@login_erforderlich
def download(akte_id: str, dokument_id: int):
    """
    GET /akten/<id>/dokumente/<did>/datei
    Gibt die Rohdatei zum Download zurück.

    Response: application/pdf oder entsprechender MIME-Typ
    """
    if not _pruefe_akte(akte_id):
        return _err(f"Akte {akte_id} nicht gefunden.", 404)

    row = _hole_dok_row(dokument_id)
    if not row or row["akte_id"] != akte_id:
        return _err(f"Dokument {dokument_id} nicht gefunden.", 404)

    ergebnis = hole_dokument_datei(dokument_id)
    if not ergebnis:
        return _err("Datei nicht auf dem Server gefunden.", 404)

    datei_bytes, dateiname, dateityp = ergebnis

    mime_map = {
        "pdf":  "application/pdf",
        "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "jpg":  "image/jpeg",
        "png":  "image/png",
    }
    mime = mime_map.get(dateityp, "application/octet-stream")

    return send_file(
        io.BytesIO(datei_bytes),
        mimetype=mime,
        as_attachment=True,
        download_name=dateiname,
    )


# ── Parse-Ergebnis ────────────────────────────────────────────────────────────

@dokumente_bp.route("/<int:dokument_id>/parse", methods=["GET"])
@login_erforderlich
def parse_ergebnis(akte_id: str, dokument_id: int):
    """
    GET /akten/<id>/dokumente/<did>/parse
    Gibt das gespeicherte Parse-Ergebnis zurück.

    Response 200:
      {
        "parse_status":    "erfolgreich",
        "parse_konfidenz": 0.72,
        "parse_ergebnis":  { ... extrahierte Felder ... },
        "warnungen":       [ ... ]
      }
    """
    if not _pruefe_akte(akte_id):
        return _err(f"Akte {akte_id} nicht gefunden.", 404)

    row = _hole_dok_row(dokument_id)
    if not row or row["akte_id"] != akte_id:
        return _err(f"Dokument {dokument_id} nicht gefunden.", 404)

    parse_json = row["parse_json"]
    ergebnis = None
    if parse_json:
        try:
            ergebnis = json.loads(parse_json)
        except json.JSONDecodeError:
            ergebnis = {"fehler": "Parse-JSON konnte nicht gelesen werden."}

    return _j({
        "parse_status":    row["parse_status"],
        "parse_konfidenz": row["parse_konfidenz"],
        "parse_fehler":    row["parse_fehler"],
        "parse_ergebnis":  ergebnis,
    })


# ── Manuelle Korrektur ────────────────────────────────────────────────────────

@dokumente_bp.route("/<int:dokument_id>/korrektur", methods=["POST"])
@login_erforderlich
def manuelle_korrektur(akte_id: str, dokument_id: int):
    """
    POST /akten/<id>/dokumente/<did>/korrektur
    Speichert ein manuell korrigiertes Parse-Ergebnis.

    Body:
      {
        "reparaturkosten": 6240.50,
        "sv_kosten":        890.00,
        ...
      }

    Response 200: Aktualisierter Parse-Status
    """
    if not _pruefe_akte(akte_id):
        return _err(f"Akte {akte_id} nicht gefunden.", 404)

    row = _hole_dok_row(dokument_id)
    if not row or row["akte_id"] != akte_id:
        return _err(f"Dokument {dokument_id} nicht gefunden.", 404)

    korrigiert = request.get_json(silent=True) or {}
    if not korrigiert:
        return _err("Kein korrigierter Body angegeben.", 422)

    dok = korrigiere_parse_ergebnis(dokument_id, korrigiert)
    if not dok:
        return _err("Dokument konnte nicht aktualisiert werden.", 500)

    from ..models.dokument import logge_aktivitaet
    logge_aktivitaet(
        aktion="parse_manuell_korrigiert",
        beschreibung=f"Parse-Ergebnis von Dokument {dokument_id} manuell korrigiert.",
        akte_id=akte_id,
        benutzer_id=g.benutzer_id,
    )

    return _j({
        "nachricht":       "Parse-Ergebnis manuell korrigiert.",
        "parse_status":    dok.parse_status,
        "parse_konfidenz": dok.parse_konfidenz,
    })


# ── Löschen ───────────────────────────────────────────────────────────────────

@dokumente_bp.route("/<int:dokument_id>", methods=["DELETE"])
@login_erforderlich
def loesche(akte_id: str, dokument_id: int):
    """
    DELETE /akten/<id>/dokumente/<did>
    Löscht ein Dokument aus DB und Dateisystem.

    Response 200: { "nachricht": "Dokument gelöscht." }
    """
    if not _pruefe_akte(akte_id):
        return _err(f"Akte {akte_id} nicht gefunden.", 404)

    row = _hole_dok_row(dokument_id)
    if not row or row["akte_id"] != akte_id:
        return _err(f"Dokument {dokument_id} nicht gefunden.", 404)

    dateiname = row["dateiname"]
    erfolg = loesche_dokument_mit_datei(dokument_id)
    if not erfolg:
        return _err("Löschen fehlgeschlagen.", 500)

    from ..models.dokument import logge_aktivitaet
    logge_aktivitaet(
        aktion="dokument_geloescht",
        beschreibung=f"Dokument gelöscht: {dateiname}",
        akte_id=akte_id,
        benutzer_id=g.benutzer_id,
    )

    return _j({"nachricht": f"Dokument {dokument_id} ({dateiname}) gelöscht."})
