"""
Modul 9 – PDF-Parser-Route
============================
Endpunkt für den Upload und das Parsen von Versicherungs-PDFs
(Abrechnungsschreiben + Prüfberichte) im Kontext des Regulierungsverlaufs.

Endpunkte:
  POST /akten/<id>/parse-pdf      PDF hochladen + sofort parsen
  GET  /akten/<id>/parse-pdf/test Verbindungstest (ohne Datei)
"""

import io
import logging
import tempfile
import os
from flask import Blueprint, request, jsonify, g
from ..auth.middleware import login_erforderlich

logger = logging.getLogger(__name__)

pdf_parse_bp = Blueprint("pdf_parse", __name__,
                         url_prefix="/akten/<path:akte_id>")


def _err(msg, status=400, **kw):
    return jsonify({"fehler": msg, "status": status, **kw}), status


def _parse_versicherungs_pdf(datei_bytes: bytes) -> dict:
    """
    Führt den vollständigen Parser-Workflow durch:
      1. Text extrahieren
      2. Dokument klassifizieren
      3. Je nach Typ: Abrechnungsschreiben oder Prüfbericht parsen

    Returns: strukturiertes Ergebnis-Dict
    """
    import json
    from ..parsers.pdf_utils import extract_text_from_pdf, normalize_text
    from ..parsers.document_classifier import classify_document
    from ..parsers.abrechnungsschreiben_parser import parse_abrechnungsschreiben
    from ..parsers.pruefbericht_parser import parse_pruefbericht
    from ..parsers.gutachten_parser import parse_gutachten

    # In temporäre Datei schreiben (pdfplumber benötigt Dateipfad oder Stream)
    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
        tmp.write(datei_bytes)
        tmp_pfad = tmp.name

    try:
        full_text, page_texts, has_image_pages = extract_text_from_pdf(tmp_pfad)
    finally:
        try:
            os.unlink(tmp_pfad)
        except OSError:
            pass

    norm_text = normalize_text(full_text)

    # Klassifizieren
    meta = classify_document(norm_text, has_image_pages)

    basis = {
        "dokumenttyp":          meta.dokumenttyp,
        "versicherer":          meta.versicherer,
        "versicherer_kuerzel":  meta.versicherer_kuerzel,
        "pruefdienstleister":   meta.pruefdienstleister,
        "schadennummer":        meta.schadennummer,
        "aktenzeichen_kanzlei": meta.aktenzeichen_kanzlei,
        "schreibdatum":         meta.schreibdatum,
        "schadendatum":         meta.schadendatum,
        "hat_bildseiten":       meta.hat_bildseiten,
        "klassifizier_konfidenz": round(meta.konfidenz, 3),
        "seiten_anzahl":        len(page_texts),
    }

    if meta.dokumenttyp == "abrechnungsschreiben":
        r = parse_abrechnungsschreiben(norm_text, meta.versicherer_kuerzel)
        positionen = []
        for p in r.positionen:
            positionen.append({
                "art":           p.art,
                "bezeichnung":   p.bezeichnung,
                "betrag_brutto": p.betrag_brutto,
                "betrag_netto":  p.betrag_netto,
                "mwst_betrag":   p.mwst_betrag,
                "pruefbericht_abzug": p.pruefbericht_abzug,
                "hinweis":       p.hinweis,
                "konfidenz":     round(p.konfidenz, 3),
            })
        zahlungen = []
        for z in r.zahlungen:
            zahlungen.append({
                "empfaenger":     z.empfaenger,
                "betrag":         z.betrag,
                "datum":          z.datum,
                "konto_hinweis":  z.konto_hinweis,
            })
        ergebnis = {
            **basis,
            "abrechnungsart":   r.abrechnungsart,
            "gesamtbetrag":     r.gesamtbetrag,
            "mwst_hinweis":     r.mwst_hinweis,
            "positionen":       positionen,
            "zahlungen":        zahlungen,
            "parse_konfidenz":  round(r.konfidenz, 3),
            "warnungen":        r.warnungen,
        }

    elif meta.dokumenttyp == "pruefbericht":
        r = parse_pruefbericht(norm_text, meta.pruefdienstleister, has_image_pages)
        fahrzeug = {
            "hersteller":     r.fahrzeug.hersteller,
            "typ":            r.fahrzeug.typ,
            "erstzulassung":  r.fahrzeug.erstzulassung,
            "kennzeichen":    r.fahrzeug.kennzeichen,
        }
        ref_ws = None
        if r.referenzwerkstatt:
            w = r.referenzwerkstatt
            ref_ws = {
                "name":             w.name,
                "adresse":          w.adresse,
                "entfernung_km":    w.entfernung_km,
                "lohn_mechanik":    w.lohn_mechanik,
                "lohn_elektrik":    w.lohn_elektrik,
                "lohn_karosserie":  w.lohn_karosserie,
                "lohn_lack":        w.lohn_lack,
            }
        abzuege = [
            {
                "kategorie":   a.kategorie,
                "bezeichnung": a.bezeichnung,
                "betrag":      a.betrag,
            }
            for a in r.abzuege_detail
        ]
        ergebnis = {
            **basis,
            "pruefdienstleister":   r.pruefdienstleister,
            "auftraggeber":         r.auftraggeber,
            "vorgangsnummer":       r.vorgangsnummer,
            "fahrzeug":             fahrzeug,
            "reparaturkosten_brutto":           r.reparaturkosten_brutto,
            "reparaturkosten_netto_vor_pruefung": r.reparaturkosten_netto_vor_pruefung,
            "abzug_technisch":          r.abzug_technisch,
            "abzug_werkstattalternative": r.abzug_werkstattalternative,
            "abzug_nfa":                r.abzug_nfa,
            "abzug_gesamt":             r.abzug_gesamt,
            "reparaturkosten_nach_pruefung": r.reparaturkosten_nach_pruefung,
            "referenzwerkstatt":        ref_ws,
            "abzuege_detail":           abzuege,
            "ist_image_pdf":            r.ist_image_pdf,
            "parse_konfidenz":          round(r.konfidenz, 3),
            "warnungen":                r.warnungen,
        }

    elif meta.dokumenttyp == "gutachten":
        r = parse_gutachten(norm_text, meta.pruefdienstleister)
        fz = r.fahrzeug
        ergebnis = {
            **basis,
            # SV-Büro & Metadaten
            "sv_buero":             r.sv_buero,
            "gutachter":            r.gutachter,
            "auftragsnummer":       r.auftragsnummer,
            "auftragsdatum":        r.auftragsdatum,
            "besichtigungsdatum":   r.besichtigungsdatum,
            # Versicherung
            "versicherung_name":            r.versicherung_name,
            "versicherungsschein_nummer":   r.versicherungsschein_nummer,
            "schadennummer_versicherung":   r.schadennummer_versicherung,
            # Fahrzeug
            "fahrzeug": {
                "hersteller":      fz.hersteller,
                "typ":             fz.typ,
                "kennzeichen":     fz.kennzeichen,
                "erstzulassung":   fz.erstzulassung,
                "kilometerstand":  fz.kilometerstand,
                "farbe":           fz.farbe,
                "vin":             fz.vin,
            },
            # Schadenart
            "schadenart":                    r.schadenart,
            "abrechnungsart":                r.abrechnungsart,
            "wirtschaftlicher_totalschaden": r.wirtschaftlicher_totalschaden,
            "totalschadengrenze":            r.totalschadengrenze,
            # Kernbeträge → direkt als Schadenpositionen nutzbar
            # Netto und Brutto getrennt für korrekte Vorsteuer-Behandlung
            "schadenpositionen": {
                "reparaturkosten":      r.reparaturkosten_netto or r.reparaturkosten_brutto,
                "rep_gutachten_netto":  r.reparaturkosten_netto,
                "rep_gutachten_mwst":   (r.reparaturkosten_brutto or 0) - (r.reparaturkosten_netto or 0)
                                        if r.reparaturkosten_brutto and r.reparaturkosten_netto else 0,
                "wiederbeschaffung":    r.wiederbeschaffungswert,
                "restwert":             r.restwert,
                "wertminderung":        r.wertminderung,
                "nutzungsausfall":      r.nutzungsausfall_gesamt,
                # SV-Kosten: netto + ust getrennt (Migration 14)
                "sv_kosten":            r.sv_kosten_netto or r.sv_kosten_brutto,
                "sv_kosten_netto":      r.sv_kosten_netto,
                "sv_kosten_ust":        (r.sv_kosten_brutto or 0) - (r.sv_kosten_netto or 0)
                                        if r.sv_kosten_brutto and r.sv_kosten_netto else 0,
            },
            # Rohe Beträge für Detailanzeige
            "reparaturkosten_netto":      r.reparaturkosten_netto,
            "reparaturkosten_brutto":     r.reparaturkosten_brutto,
            "wiederbeschaffungswert":     r.wiederbeschaffungswert,
            "restwert":                   r.restwert,
            "wertminderung":              r.wertminderung,
            "wertverbesserung":           r.wertverbesserung,
            "nutzungsausfall_tagessatz":  r.nutzungsausfall_tagessatz,
            "nutzungsausfall_tage":       r.nutzungsausfall_tage,
            "nutzungsausfall_gesamt":     r.nutzungsausfall_gesamt,
            "sv_kosten_netto":            r.sv_kosten_netto,
            "sv_kosten_brutto":           r.sv_kosten_brutto,
            "parse_konfidenz":            r.konfidenz,
            "warnungen":                  r.warnungen,
        }

    else:
        ergebnis = {
            **basis,
            "parse_konfidenz": 0.0,
            "warnungen": [
                "Dokumenttyp konnte nicht erkannt werden. "
                "Bitte manuell als Abrechnungsschreiben oder Prüfbericht klassifizieren."
            ],
        }

    return ergebnis


# ── Endpunkte ──────────────────────────────────────────────────────────────────

@pdf_parse_bp.route("/parse-pdf", methods=["POST"])
@login_erforderlich
def parse_pdf(akte_id: str):
    """
    POST /akten/<id>/parse-pdf

    Multipart-Form mit Feld "datei" (PDF).
    Returns strukturiertes Parse-Ergebnis ohne DB-Abhängigkeit.
    Schreibt nach erfolgreichem Parse einen Eintrag in die Akten-Chronik.
    """
    if "datei" not in request.files:
        return _err("Kein Datei-Feld 'datei' im Request.")

    datei = request.files["datei"]
    if not datei.filename:
        return _err("Keine Datei ausgewählt.")

    if not datei.filename.lower().endswith(".pdf"):
        return _err("Nur PDF-Dateien werden unterstützt.")

    datei_bytes = datei.read()
    if len(datei_bytes) == 0:
        return _err("Leere Datei.")
    if len(datei_bytes) > 20 * 1024 * 1024:
        return _err("Datei zu groß (max. 20 MB).")

    try:
        ergebnis = _parse_versicherungs_pdf(datei_bytes)
    except Exception as e:
        logger.error("PDF-Parse-Fehler für Akte %d: %s", akte_id, e, exc_info=True)
        return _err(f"PDF konnte nicht verarbeitet werden: {str(e)}", 500)

    # ── Akten-Chronik-Eintrag ──────────────────────────────────────────────
    try:
        from ..models.dokument import logge_aktivitaet

        dokumenttyp = ergebnis.get("dokumenttyp", "unbekannt")
        konfidenz   = ergebnis.get("parse_konfidenz") or ergebnis.get("klassifizier_konfidenz", 0)
        benutzer_id = getattr(g, "benutzer_id", None)

        # Lesbare Bezeichnung je Dokumenttyp
        typ_labels = {
            "gutachten":            "Gutachten",
            "abrechnungsschreiben": "Abrechnungsschreiben",
            "pruefbericht":         "Prüfbericht",
        }
        typ_label = typ_labels.get(dokumenttyp, "PDF-Dokument")

        # Konfidenz als Prozent für die Beschreibung
        konfidenz_pct = f"{round(konfidenz * 100)} %" if konfidenz else "–"

        beschreibung = (
            f"{typ_label} hochgeladen: {datei.filename}"
            f" · Konfidenz {konfidenz_pct}"
        )

        # Ergänze nützliche Parse-Details je Typ
        if dokumenttyp == "gutachten":
            sv = ergebnis.get("sv_buero", "")
            schadenart = ergebnis.get("schadenart", "")
            if sv:
                beschreibung += f" · SV-Büro: {sv}"
            if schadenart:
                beschreibung += f" · {schadenart.capitalize()}"
        elif dokumenttyp == "abrechnungsschreiben":
            versicherer = ergebnis.get("versicherer", "")
            betrag = ergebnis.get("gesamtbetrag")
            if versicherer:
                beschreibung += f" · {versicherer}"
            if betrag:
                beschreibung += f" · {betrag:,.2f} €".replace(",", "X").replace(".", ",").replace("X", ".")
        elif dokumenttyp == "pruefbericht":
            dienstleister = ergebnis.get("pruefdienstleister", "")
            abzug = ergebnis.get("abzug_gesamt")
            if dienstleister:
                beschreibung += f" · {dienstleister}"
            if abzug:
                beschreibung += f" · Abzug: {abzug:,.2f} €".replace(",", "X").replace(".", ",").replace("X", ".")

        logge_aktivitaet(
            aktion=f"pdf_import_{dokumenttyp}",
            beschreibung=beschreibung,
            akte_id=akte_id,
            benutzer_id=benutzer_id,
            tabelle="pdf_parse",
        )
    except Exception as log_err:
        # Logging-Fehler dürfen das Parse-Ergebnis nicht blockieren
        logger.warning("Chronik-Eintrag fehlgeschlagen für Akte %d: %s", akte_id, log_err)

    return jsonify({
        "akte_id": akte_id,
        "dateiname": datei.filename,
        "ergebnis": ergebnis,
    }), 200


@pdf_parse_bp.route("/parse-pdf/test", methods=["GET"])
@login_erforderlich
def parse_pdf_test(akte_id: str):
    """Einfacher Verbindungstest."""
    return jsonify({"status": "ok", "akte_id": akte_id}), 200
