"""
Modul 3 – Router: Schaden & Regulierung
=========================================
REST-Endpunkte für Schadenpositionen und Regulierungsvorgänge.

Endpunkte Schaden:
  GET    /akten/<id>/schaden           Schadenpositionen abrufen
  PUT    /akten/<id>/schaden           Schadenpositionen setzen/ersetzen

Endpunkte Regulierung:
  GET    /akten/<id>/regulierungen         Alle Regulierungsvorgänge
  POST   /akten/<id>/regulierungen         Neuen Regulierungsvorgang anlegen
  GET    /akten/<id>/regulierungen/status  Aktueller Regulierungsstand
"""

import logging
from flask import Blueprint, request, jsonify, g
from ..auth.middleware import login_erforderlich
from ..models.akte import hole_akte_by_id
from ..models.schaden import (
    setze_schadenpositionen, hole_schadenpositionen,
    erstelle_regulierung, hole_regulierungen_by_akte,
    hole_regulierungsstatus
)
from ..models.dokument import logge_aktivitaet

logger = logging.getLogger(__name__)

schaden_bp = Blueprint("schaden", __name__,
                        url_prefix="/akten/<path:akte_id>/schaden")
regulierung_bp = Blueprint("regulierung", __name__,
                            url_prefix="/akten/<path:akte_id>/regulierungen")


def _j(daten, status=200):
    return jsonify(daten), status

def _err(msg, status, **extra):
    return jsonify({"fehler": msg, "status": status, **extra}), status

def _body():
    return request.get_json(silent=True) or {}

def _pruefe_akte(akte_id):
    return hole_akte_by_id(akte_id)

def _schaden_dict(s) -> dict:
    if not s:
        return None
    # wdm_extras_json (JSON-String in DB) → _extras (Array) für Frontend
    import json as _json
    _extras = []
    _raw_extras = getattr(s, "wdm_extras_json", None)
    if _raw_extras:
        try:
            parsed = _json.loads(_raw_extras)
            if isinstance(parsed, list):
                _extras = parsed
        except Exception:
            _extras = []
    return {
        "id": s.id, "akte_id": s.akte_id,
        # Ursprüngliche Felder
        "reparaturkosten":   s.reparaturkosten,
        "wiederbeschaffung": s.wiederbeschaffung,
        "restwert":          s.restwert,
        "wertminderung":     s.wertminderung,
        "nutzungsausfall":   s.nutzungsausfall,
        "mietwagenkosten":   s.mietwagenkosten,
        "sv_kosten":         s.sv_kosten,
        "abschleppkosten":   s.abschleppkosten,
        "standkosten":       s.standkosten,
        "anabmeldekosten":   s.anabmeldekosten,
        "schmerzensgeld":    s.schmerzensgeld,
        "sonstiges":         s.sonstiges,
        "sonstiges_beschr":  s.sonstiges_beschr,
        "gesamt_brutto":     s.gesamt_brutto,
        "quelle":            s.quelle,
        "erfasst_am":        s.erfasst_am,
        # Migration 6 (umbenannt in Migration 10)
        "verdienstausfall":  getattr(s, "verdienstausfall",  0.0),
        "haushalt":          getattr(s, "haushalt",          0.0),
        "rep_gutachten_netto": getattr(s, "rep_gutachten_netto", 0.0),
        "rep_gutachten_mwst":  getattr(s, "rep_gutachten_mwst",  0.0),
        "unkostenpauschale": getattr(s, "unkostenpauschale", 0.0),
        "wdm_extras_json":   getattr(s, "wdm_extras_json",  None),
        "wdm_info_json":     getattr(s, "wdm_info_json",    None),
        # Migration 8
        "kostennb":          getattr(s, "kostennb",          0.0),
        "kostennb_ust":      getattr(s, "kostennb_ust",      0.0),
        # Migration 10
        "rep_rechnung_netto":  getattr(s, "rep_rechnung_netto",  0.0),
        "rep_rechnung_brutto": getattr(s, "rep_rechnung_brutto", 0.0),
        # Migration 12
        "abrechnungsart":      getattr(s, "abrechnungsart",      None),
        # Migration 14 – Netto/USt-Felder für Nebenkosten
        "sv_kosten_netto":        getattr(s, "sv_kosten_netto",        0.0),
        "sv_kosten_ust":          getattr(s, "sv_kosten_ust",          0.0),
        "abschleppkosten_netto":  getattr(s, "abschleppkosten_netto",  0.0),
        "abschleppkosten_ust":    getattr(s, "abschleppkosten_ust",    0.0),
        "standkosten_netto":      getattr(s, "standkosten_netto",      0.0),
        "standkosten_ust":        getattr(s, "standkosten_ust",        0.0),
        "anabmeldekosten_netto":  getattr(s, "anabmeldekosten_netto",  0.0),
        "anabmeldekosten_ust":    getattr(s, "anabmeldekosten_ust",    0.0),
        "mietwagenkosten_netto":  getattr(s, "mietwagenkosten_netto",  0.0),
        "mietwagenkosten_ust":    getattr(s, "mietwagenkosten_ust",    0.0),
        # Extras: als geparste Liste (nicht als JSON-String) — Frontend nutzt _extras
        "_extras":             _extras,
    }

def _reg_dict(r) -> dict:
    return {
        "id": r.id, "akte_id": r.akte_id,
        "datum":             r.datum,
        "betrag_gefordert":  r.betrag_gefordert,
        "betrag_reguliert":  r.betrag_reguliert,
        "differenz":         r.differenz,
        "status":            r.status,
        "vers_referenz":     r.vers_referenz,
        "kuerz_begruendung": r.kuerz_begruendung,
        "erfasst_am":        r.erfasst_am,
    }


# ══════════════════════════════════════════════════════════════════════════════
# SCHADENPOSITIONEN
# ══════════════════════════════════════════════════════════════════════════════

@schaden_bp.route("", methods=["GET"])
@login_erforderlich
def hole_schaden(akte_id: str):
    """GET /akten/<id>/schaden — Schadenpositionen abrufen."""
    if not _pruefe_akte(akte_id):
        return _err(f"Akte {akte_id} nicht gefunden.", 404)

    schaden = hole_schadenpositionen(akte_id)
    if not schaden:
        return _j({"schaden": None, "hinweis": "Noch keine Schadenpositionen erfasst."})
    return _j({"schaden": _schaden_dict(schaden)})


@schaden_bp.route("", methods=["PUT"])
@login_erforderlich
def setze_schaden(akte_id: str):
    """
    PUT /akten/<id>/schaden — Schadenpositionen setzen/ersetzen.
    """
    if not _pruefe_akte(akte_id):
        return _err(f"Akte {akte_id} nicht gefunden.", 404)

    daten = _body()

    numerische_felder = [
        # Basis
        "reparaturkosten", "wiederbeschaffung", "restwert", "wertminderung",
        "nutzungsausfall", "mietwagenkosten", "sv_kosten", "abschleppkosten",
        "standkosten", "anabmeldekosten", "schmerzensgeld", "sonstiges",
        # Migration 6 (umbenannt in Migration 10)
        "verdienstausfall", "haushalt",
        "rep_gutachten_netto", "rep_gutachten_mwst",
        "unkostenpauschale",
        # Rückwärtskompatibilität: alte Feldnamen (vor Migration 10)
        "rep_fiktiv_netto", "rep_fiktiv_mwst",
        # Migration 8
        "kostennb", "kostennb_ust",
        # Migration 10
        "rep_rechnung_netto", "rep_rechnung_brutto",
        # Migration 14 – Netto/USt-Felder für Nebenkosten
        "sv_kosten_netto",       "sv_kosten_ust",
        "abschleppkosten_netto", "abschleppkosten_ust",
        "standkosten_netto",     "standkosten_ust",
        "anabmeldekosten_netto", "anabmeldekosten_ust",
        "mietwagenkosten_netto", "mietwagenkosten_ust",
    ]

    positionen = {}
    for feld in numerische_felder:
        try:
            raw = daten.get(feld, 0)      # 0 wenn nicht im Body → überschreibt alte Werte
            val = float(raw) if raw not in (None, "") else 0.0
            if feld == "restwert":
                val = abs(val)
            elif val < 0:
                return _err(f"'{feld}' darf nicht negativ sein.", 422, feld=feld)
            # Alte Feldnamen auf neue mappen (Backward-Compat)
            mapped = {"rep_fiktiv_netto": "rep_gutachten_netto",
                      "rep_fiktiv_mwst":  "rep_gutachten_mwst"}.get(feld, feld)
            positionen[mapped] = val
        except (TypeError, ValueError):
            return _err(f"'{feld}' muss eine Zahl sein.", 422, feld=feld)

    for feld in ("sonstiges_beschr", "quelle", "wdm_extras_json", "wdm_info_json", "abrechnungsart"):
        if feld in daten:
            positionen[feld] = daten[feld]

    # _extras (Frontend-Array) → wdm_extras_json (JSON-String in DB)
    if "_extras" in daten and isinstance(daten["_extras"], list):
        import json as _json
        positionen["wdm_extras_json"] = _json.dumps(daten["_extras"], ensure_ascii=False)

    schaden = setze_schadenpositionen(
        akte_id=akte_id,
        bearbeiter_id=g.benutzer_id,
        **positionen
    )

    logge_aktivitaet(
        aktion="schaden_aktualisiert",
        beschreibung=f"Schadenpositionen gesetzt. Gesamt: {schaden.gesamt_brutto:.2f} €",
        akte_id=akte_id,
        benutzer_id=g.benutzer_id,
    )

    return _j({"schaden": _schaden_dict(schaden)})


# ══════════════════════════════════════════════════════════════════════════════
# REGULIERUNG
# ══════════════════════════════════════════════════════════════════════════════

@regulierung_bp.route("", methods=["GET"])
@login_erforderlich
def liste_regulierungen(akte_id: str):
    """GET /akten/<id>/regulierungen — Alle Regulierungsvorgänge."""
    if not _pruefe_akte(akte_id):
        return _err(f"Akte {akte_id} nicht gefunden.", 404)
    return _j({"regulierungen": [_reg_dict(r) for r in hole_regulierungen_by_akte(akte_id)]})


@regulierung_bp.route("", methods=["POST"])
@login_erforderlich
def erstelle_reg(akte_id: str):
    """
    POST /akten/<id>/regulierungen — Regulierungsvorgang anlegen.

    Body: { datum, betrag_gefordert, betrag_reguliert, vers_referenz?, kuerz_begruendung? }
    Status wird automatisch gesetzt: vollreguliert / teilreguliert / offen.
    """
    if not _pruefe_akte(akte_id):
        return _err(f"Akte {akte_id} nicht gefunden.", 404)

    daten = _body()
    datum = daten.get("datum", "").strip()
    if not datum:
        return _err("datum ist erforderlich.", 422, feld="datum")

    try:
        gefordert = float(daten.get("betrag_gefordert", 0))
        reguliert = float(daten.get("betrag_reguliert", 0))
    except (TypeError, ValueError):
        return _err("betrag_gefordert und betrag_reguliert müssen Zahlen sein.", 422)

    if gefordert < 0:
        return _err("betrag_gefordert darf nicht negativ sein.", 422)

    try:
        reg = erstelle_regulierung(
            akte_id=akte_id,
            datum=datum,
            betrag_gefordert=gefordert,
            betrag_reguliert=reguliert,
            bearbeiter_id=g.benutzer_id,
            vers_referenz=daten.get("vers_referenz"),
            kuerz_begruendung=daten.get("kuerz_begruendung"),
        )
    except ValueError as e:
        return _err(str(e), 422)

    return _j({"regulierung": _reg_dict(reg)}, 201)


@regulierung_bp.route("/status", methods=["GET"])
@login_erforderlich
def regulierungsstatus(akte_id: str):
    """GET /akten/<id>/regulierungen/status — Aktueller Regulierungsstand."""
    if not _pruefe_akte(akte_id):
        return _err(f"Akte {akte_id} nicht gefunden.", 404)
    return _j(hole_regulierungsstatus(akte_id))
