import React, { useState, useRef, useEffect, useCallback, useReducer } from "react";
import {
  auth as apiAuth, akten as apiAkten, beteiligte as apiBeteiligte,
  schaden as apiSchaden, dokumente as apiDokumente, word as apiWord,
  forderungen as apiForderungen,
  emailImport as apiEmail, wiedervorlage as apiWV, aktensuche as apiAktensuche,
  ramicroAkte as apiRaMicroAkte, ramicroListe, ramicroWdm,
  kuerzungsarten as apiKuerzungsarten,
  abrechnungen as apiAbrechnungen,
  pruefberichte as apiPruefberichte,
  parsePdf as apiParsePdf,
  ping, tokenStore, ApiError, request,
} from "./api.js";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line
} from "recharts";

/* ══════════════════════════════════════════════════════════════
   DESIGN TOKENS
══════════════════════════════════════════════════════════════ */
const T = {
  navy:"#1B2A4A", navyDark:"#111d35", navyMid:"#243660", navyLight:"#2e4270",
  gold:"#C8A84B", goldLight:"#dfc070", goldPale:"#f8f1e0", goldTrim:"rgba(200,168,75,0.18)",
  white:"#FFFFFF", offWhite:"#F6F4EF", surface:"#FAFAF8",
  border:"#E2DDD3", borderSoft:"rgba(226,221,211,0.6)",
  text:"#1a1a2e", textMid:"#3d4060", textMuted:"#6b7094", textFaint:"#9da3be",
  green:"#10b981", greenBg:"#ecfdf5",
  amber:"#f59e0b", amberBg:"#fffbeb",
  red:"#ef4444",   redBg:"#fef2f2",
  blue:"#3b82f6",  blueBg:"#eff6ff",
};

const STATUS_MAP = {
  offen:          { label:"Offen",          color:T.blue,  bg:T.blueBg  },
  in_regulierung: { label:"In Regulierung", color:T.amber, bg:T.amberBg },
  abgeschlossen:  { label:"Abgeschlossen",  color:T.green, bg:T.greenBg },
  klage:          { label:"Klage",          color:T.red,   bg:T.redBg   },
};

const REG_STATUS = {
  vollreguliert: { label:"Vollreguliert", color:T.green },
  teilreguliert: { label:"Teilreguliert", color:T.amber },
  abgelehnt:     { label:"Abgelehnt",     color:T.red   },
  ausstehend:    { label:"Ausstehend",    color:T.textMuted },
};

/* ══════════════════════════════════════════════════════════════
   MOCK DATA
══════════════════════════════════════════════════════════════ */

const INITIAL_STATE = {};



/* E-Mail-Import Mock-Daten */
const IMAP_CONFIG = {
  host:"mail.anwalt-offenbach.de", port:993, ssl:true,
  user:"import@anwalt-offenbach.de", ordner:"INBOX", max_fetch:50,
  letzte_sync:"09.03.2026 08:00", naechste_sync:"09.03.2026 09:00",
  status:"verbunden",
};

/* ══════════════════════════════════════════════════════════════
   UTILS
══════════════════════════════════════════════════════════════ */
function fmtEuro(v) {
  if (v==null) return "–";
  return new Intl.NumberFormat("de-DE",{style:"currency",currency:"EUR",minimumFractionDigits:2,maximumFractionDigits:2}).format(v);
}
function fmtSize(bytes) {
  if (!bytes) return "";
  return bytes < 1048576 ? `${Math.round(bytes/1024)} KB` : `${(bytes/1048576).toFixed(1)} MB`;
}

/* ══════════════════════════════════════════════════════════════
   ICONS
══════════════════════════════════════════════════════════════ */
const Ic = {
  logo:     <svg viewBox="0 0 24 24" fill="currentColor" style={{width:22,height:22}}><text x="12" y="18" textAnchor="middle" fontFamily="Georgia,serif" fontSize="20" fontWeight="bold">§</text></svg>,
  dash:     <svg viewBox="0 0 24 24" fill="currentColor" style={{width:16,height:16}}><path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/></svg>,
  akte:     <svg viewBox="0 0 24 24" fill="currentColor" style={{width:14,height:14}}><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg>,
  x:        <svg viewBox="0 0 24 24" fill="currentColor" style={{width:13,height:13}}><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>,
  search:   <svg viewBox="0 0 24 24" fill="currentColor" style={{width:15,height:15}}><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>,
  user:     <svg viewBox="0 0 24 24" fill="currentColor" style={{width:16,height:16}}><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>,
  logout:   <svg viewBox="0 0 24 24" fill="currentColor" style={{width:15,height:15}}><path d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z"/></svg>,
  plus:     <svg viewBox="0 0 24 24" fill="currentColor" style={{width:14,height:14}}><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>,
  edit:     <svg viewBox="0 0 24 24" fill="currentColor" style={{width:13,height:13}}><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>,
  trash:    <svg viewBox="0 0 24 24" fill="currentColor" style={{width:13,height:13}}><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>,
  upload:   <svg viewBox="0 0 24 24" fill="currentColor" style={{width:28,height:28}}><path d="M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z"/></svg>,
  download: <svg viewBox="0 0 24 24" fill="currentColor" style={{width:13,height:13}}><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>,
  pdf:      <svg viewBox="0 0 24 24" fill="currentColor" style={{width:18,height:18}}><path d="M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8.5 7.5c0 .83-.67 1.5-1.5 1.5H9v2H7.5V7H10c.83 0 1.5.67 1.5 1.5v1zm5 2c0 .83-.67 1.5-1.5 1.5h-2.5V7H15c.83 0 1.5.67 1.5 1.5v3zm4-3H19v1h1.5V11H19v2h-1.5V7h3v1.5zM4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6z"/></svg>,
  word:     <svg viewBox="0 0 24 24" fill="currentColor" style={{width:16,height:16}}><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zM6 20V4h7v5h5v11H6z"/></svg>,
  check:    <svg viewBox="0 0 24 24" fill="currentColor" style={{width:14,height:14}}><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>,
  chevR:    <svg viewBox="0 0 24 24" fill="currentColor" style={{width:13,height:13}}><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg>,
  email:    <svg viewBox="0 0 24 24" fill="currentColor" style={{width:15,height:15}}><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>,
  refresh:  <svg viewBox="0 0 24 24" fill="currentColor" style={{width:15,height:15}}><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>,
  attach:   <svg viewBox="0 0 24 24" fill="currentColor" style={{width:13,height:13}}><path d="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.38 1.12 2.5 2.5 2.5s2.5-1.12 2.5-2.5V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z"/></svg>,
  settings: <svg viewBox="0 0 24 24" fill="currentColor" style={{width:15,height:15}}><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>,
};

/* ══════════════════════════════════════════════════════════════
   SHARED ATOMS
══════════════════════════════════════════════════════════════ */
function StatusBadge({ status, map = STATUS_MAP }) {
  const s = map[status] || { label: status, color: "#888", bg: "#f0f0f0" };
  const bg = s.bg || s.color + "18";
  return (
    <span style={{ display:"inline-flex", alignItems:"center", gap:5, background:bg, color:s.color, border:`1px solid ${s.color}33`, borderRadius:20, padding:"2px 9px", fontSize:"0.845rem", fontWeight:600, whiteSpace:"nowrap" }}>
      <span style={{ width:6, height:6, borderRadius:"50%", background:s.color, flexShrink:0 }} />
      {s.label}
    </span>
  );
}

function Card({ children, style = {} }) {
  return <div style={{ background:T.white, borderRadius:12, border:`1px solid ${T.border}`, boxShadow:"0 2px 8px rgba(0,0,0,0.04)", overflow:"hidden", ...style }}>{children}</div>;
}

function CardHead({ title, action }) {
  return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0.9rem 1.4rem", borderBottom:`1px solid ${T.border}` }}>
      <h3 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1rem", fontWeight:700, color:T.navy, margin:0 }}>{title}</h3>
      {action}
    </div>
  );
}

function Btn({ children, variant="primary", onClick, onMouseDown, disabled=false, size="md", style={} }) {
  const pad  = { sm:"5px 10px", md:"8px 14px", lg:"10px 18px" }[size];
  const fs   = { sm:"0.74rem",  md:"0.82rem",  lg:"0.88rem"  }[size];
  const vars = {
    primary:   { background:T.navy,    color:T.white,    border:"none" },
    secondary: { background:T.surface, color:T.textMid,  border:`1px solid ${T.border}` },
    gold:      { background:T.gold,    color:T.navy,     border:"none" },
    danger:    { background:T.redBg,   color:T.red,      border:`1px solid ${T.red}33` },
  };
  return (
    <button disabled={disabled} onClick={disabled ? null : onClick} onMouseDown={onMouseDown}
      style={{ display:"inline-flex", alignItems:"center", gap:6, borderRadius:7, fontFamily:"'IBM Plex Sans',sans-serif", fontWeight:600, cursor:disabled?"default":"pointer", transition:"all 0.15s", opacity:disabled?0.55:1, padding:pad, fontSize:fs, ...vars[variant], ...style }}>
      {children}
    </button>
  );
}

function FieldInput({ label, value, onChange, type="text", placeholder="", required=false }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
      {label && <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600, color:T.textMid, letterSpacing:"0.05em", textTransform:"uppercase" }}>{label}{required && <span style={{ color:T.red }}> *</span>}</label>}
      <input type={type} value={value} placeholder={placeholder} onChange={e => onChange(e.target.value)}
        style={{ padding:"8px 10px", border:`1.5px solid ${T.border}`, borderRadius:7, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.985rem", color:T.text, background:T.surface, outline:"none" }}
        onFocus={e => e.target.style.borderColor = T.gold}
        onBlur={e  => e.target.style.borderColor = T.border} />
    </div>
  );
}

function FieldSelect({ label, value, onChange, options }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
      {label && <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600, color:T.textMid, letterSpacing:"0.05em", textTransform:"uppercase" }}>{label}</label>}
      <select value={value} onChange={e => onChange(e.target.value)}
        style={{ padding:"8px 10px", border:`1.5px solid ${T.border}`, borderRadius:7, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.985rem", color:T.text, background:T.surface, outline:"none", cursor:"pointer" }}>
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

function Toast({ msg, onDone }) {
  useEffect(() => { const t = setTimeout(onDone, 2600); return () => clearTimeout(t); }, []);
  return (
    <div style={{ position:"fixed", bottom:24, right:24, zIndex:600, background:T.navy, color:T.white, padding:"10px 18px", borderRadius:10, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.975rem", boxShadow:"0 8px 32px rgba(0,0,0,0.25)", borderLeft:`3px solid ${T.gold}`, display:"flex", alignItems:"center", gap:8, animation:"slideUp 0.3s ease-out" }}>
      <span style={{ color:T.white }}>{Ic.check}</span>{msg}
    </div>
  );
}

function SlidePanel({ open, onClose, title, children }) {
  return (
    <>
      {open && <div onClick={onClose} style={{ position:"fixed", inset:0, background:"rgba(17,29,53,0.45)", zIndex:300, backdropFilter:"blur(2px)" }} />}
      <div style={{ position:"fixed", top:0, right:0, bottom:0, width:500, background:T.white, boxShadow:"-8px 0 48px rgba(0,0,0,0.18)", zIndex:310, display:"flex", flexDirection:"column", transform:open?"translateX(0)":"translateX(105%)", transition:"transform 0.3s cubic-bezier(0.16,1,0.3,1)" }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"1.1rem 1.5rem", borderBottom:`1px solid ${T.border}`, background:T.navy, flexShrink:0 }}>
          <span style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.175rem", fontWeight:700, color:T.white }}>{title}</span>
          <button onClick={onClose} style={{ background:"rgba(255,255,255,0.1)", border:"none", borderRadius:6, padding:7, cursor:"pointer", color:T.white, display:"flex" }}>{Ic.x}</button>
        </div>
        <div style={{ flex:1, overflowY:"auto", padding:"1.4rem" }}>{children}</div>
      </div>
    </>
  );
}


/* ══════════════════════════════════════════════════════════════
   API / BACKEND INTEGRATION LAYER
══════════════════════════════════════════════════════════════ */

/**
 * useBackend – erkennt ob das Backend erreichbar ist.
 * Im Demo-Modus (kein Backend) werden alle Operationen gegen
 * den lokalen Reducer-State ausgeführt.
 */
function useBackend() {
  const [online,  setOnline]  = useState(null); // null = prüfend
  const [checked, setChecked] = useState(false);
  useEffect(() => {
    ping().then(ok => { setOnline(ok); setChecked(true); });
  }, []);
  return { online, checked };
}

/** Konvertiert ApiError → benutzerfreundliche deutsche Nachricht */
function apiErrMsg(err) {
  if (!err) return "Unbekannter Fehler.";
  if (err instanceof ApiError) {
    if (err.status === 0)   return "Keine Verbindung zum Server.";
    if (err.status === 401) return "Sitzung abgelaufen. Bitte neu anmelden.";
    if (err.status === 403) return "Keine Berechtigung für diese Aktion.";
    if (err.status === 404) return "Datensatz nicht gefunden.";
    if (err.status === 409) return "Konflikt: Datensatz existiert bereits.";
    if (err.status >= 500)  return `Serverfehler (${err.status}). Bitte IT informieren.`;
    return err.message || `Fehler ${err.status}`;
  }
  return err.message || "Unbekannter Fehler.";
}

/** Kleiner Status-Indikator für die TopNav */
function BackendBadge({ online }) {
  if (online === null) return (
    <div style={{ display:"flex", alignItems:"center", gap:5, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.845rem", color:"rgba(255,255,255,0.45)", padding:"4px 9px", background:"rgba(255,255,255,0.06)", borderRadius:6, border:"1px solid rgba(255,255,255,0.1)" }}>
      <span style={{ width:6, height:6, borderRadius:"50%", background:"rgba(255,255,255,0.3)" }}/>Verbinde …
    </div>
  );
  if (online) return (
    <div style={{ display:"flex", alignItems:"center", gap:5, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.845rem", color:"rgba(100,220,150,0.9)", padding:"4px 9px", background:"rgba(16,185,129,0.1)", borderRadius:6, border:"1px solid rgba(16,185,129,0.2)" }}>
      <span style={{ width:6, height:6, borderRadius:"50%", background:"#10b981" }}/>Live-API
    </div>
  );
  return (
    <div style={{ display:"flex", alignItems:"center", gap:5, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.845rem", color:"rgba(200,168,75,0.85)", padding:"4px 9px", background:"rgba(200,168,75,0.1)", borderRadius:6, border:"1px solid rgba(200,168,75,0.2)" }}>
      <span style={{ width:6, height:6, borderRadius:"50%", background:T.gold }}/>Demo-Modus
    </div>
  );
}

/** Lade-Skeleton für Tabellen / Karten */
function Skeleton({ width="100%", height=18, radius=6, style={} }) {
  return (
    <div style={{ width, height, borderRadius:radius, background:"linear-gradient(90deg,#f0ece4 25%,#e8e2d8 50%,#f0ece4 75%)", backgroundSize:"200% 100%", animation:"shimmer 1.5s infinite", ...style }}/>
  );
}

/** Fehler-Hinweis-Karte */
function ApiErrorBanner({ error, onRetry }) {
  if (!error) return null;
  return (
    <div style={{ background:T.redBg, border:`1px solid ${T.red}33`, borderRadius:10, padding:"10px 14px", display:"flex", alignItems:"center", gap:10, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.955rem", color:T.red, marginBottom:"1rem" }}>
      <span>⚠</span>
      <span style={{ flex:1 }}>{apiErrMsg(error)}</span>
      {onRetry && <Btn variant="danger" size="sm" onClick={onRetry}>Erneut versuchen</Btn>}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   LOGIN
══════════════════════════════════════════════════════════════ */
function LoginPage({ onLogin }) {
  const [email, setEmail] = useState("koch@anwalt-offenbach.de");
  const [pw, setPw]       = useState("Kanzlei2024!");
  const [loading, setL]   = useState(false);
  const [fehler, setF]    = useState("");
  const [ok, setOk]       = useState(false);

  useEffect(() => { setTimeout(() => setOk(true), 60); }, []);

  const submit = async () => {
    setF("");
    if (!email || !pw) { setF("Bitte alle Felder ausfüllen."); return; }
    setL(true);
    try {
      const benutzer = await apiAuth.login(email, pw);
      if (benutzer) { onLogin(benutzer); return; }
      throw new Error("Keine Benutzerdaten erhalten.");
    } catch (apiErr) {

      setF(apiErr.status === 401 ? "Ungültige E-Mail oder Passwort." : apiErrMsg(apiErr));
    } finally {
      setL(false);
    }
  };

  const inp = {
    width:"100%", padding:"11px 14px", border:`1.5px solid ${T.border}`,
    borderRadius:8, fontSize:"1.045rem", fontFamily:"'IBM Plex Sans',sans-serif",
    color:T.text, background:T.surface, outline:"none", boxSizing:"border-box",
  };

  return (
    <div style={{ minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center",
      background:"#ffffff", position:"relative", overflow:"hidden" }}>

      {/* Dezente Linie oben in Kanzleifarbe */}
      <div style={{ position:"fixed", top:0, left:0, right:0, height:4,
        background:`linear-gradient(90deg,${T.navy},${T.gold},${T.navy})` }} />

      {/* Zentrierte Login-Card */}
      <div style={{ position:"relative", width:"100%", maxWidth:440, padding:"1.5rem",
        opacity:ok?1:0, transform:ok?"none":"translateY(24px)",
        transition:"all 0.6s cubic-bezier(0.16,1,0.3,1)" }}>

        {/* Logo & Kanzleiname */}
        <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:12, marginBottom:"2rem" }}>
          {/* Blaues §-Logo */}
          <div style={{ width:72, height:72, background:T.navy, borderRadius:18,
            display:"flex", alignItems:"center", justifyContent:"center",
            boxShadow:`0 8px 24px ${T.navy}44` }}>
            <svg viewBox="0 0 40 40" fill="white" style={{width:44,height:44}}>
              <text x="20" y="30" textAnchor="middle"
                fontFamily="Georgia,'Times New Roman',serif"
                fontSize="30" fontWeight="bold">§</text>
            </svg>
          </div>
          {/* Kanzleiname groß + fett */}
          <div style={{ textAlign:"center" }}>
            <div style={{ fontFamily:"'Playfair Display',Georgia,serif",
              fontSize:"24px", fontWeight:700, color:T.navy,
              letterSpacing:"0.01em", lineHeight:1.2 }}>
              Koch, Schatz &amp; Kollegen
            </div>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem",
              color:T.textMuted, letterSpacing:"0.1em", textTransform:"uppercase",
              marginTop:4 }}>
              Rechtsanwälte · Offenbach am Main
            </div>
          </div>
        </div>

        {/* Card */}
        <div style={{ background:"#ffffff", borderRadius:16, padding:"2.4rem 2.6rem",
          boxShadow:"0 4px 32px rgba(0,0,0,0.08), 0 0 0 1.5px rgba(15,30,64,0.10)" }}>
          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"1.1rem",
            fontWeight:600, color:T.navy, marginBottom:"1.6rem",
            paddingBottom:"1rem", borderBottom:`1.5px solid ${T.border}` }}>
            Anmelden
          </div>
          {fehler && (
            <div style={{ background:T.redBg, border:`1px solid ${T.red}55`, borderRadius:8,
              padding:"10px 14px", marginBottom:"1.2rem",
              fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.955rem", color:T.red }}>
              {fehler}
            </div>
          )}
          <div style={{ marginBottom:"1.2rem" }}>
            <label style={{ display:"block", fontFamily:"'IBM Plex Sans',sans-serif",
              fontSize:"0.82rem", fontWeight:600, color:T.textMid,
              letterSpacing:"0.06em", textTransform:"uppercase", marginBottom:6 }}>
              E-Mail
            </label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)}
              onKeyDown={e => e.key==="Enter"&&submit()} style={inp}
              onFocus={e=>e.target.style.borderColor=T.navy}
              onBlur={e=>e.target.style.borderColor=T.border} />
          </div>
          <div style={{ marginBottom:"1.6rem" }}>
            <label style={{ display:"block", fontFamily:"'IBM Plex Sans',sans-serif",
              fontSize:"0.82rem", fontWeight:600, color:T.textMid,
              letterSpacing:"0.06em", textTransform:"uppercase", marginBottom:6 }}>
              Passwort
            </label>
            <input type="password" value={pw} onChange={e => setPw(e.target.value)}
              onKeyDown={e => e.key==="Enter"&&submit()} style={inp}
              onFocus={e=>e.target.style.borderColor=T.navy}
              onBlur={e=>e.target.style.borderColor=T.border} />
          </div>
          <button onClick={submit} disabled={loading} style={{
            width:"100%", padding:"13px", background:T.navy, color:T.white,
            border:"none", borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif",
            fontSize:"1rem", fontWeight:600, cursor:loading?"default":"pointer",
            position:"relative", overflow:"hidden",
            boxShadow:`0 4px 12px ${T.navy}44`,
            transition:"opacity 0.15s" }}>
            {loading ? "Anmelden …" : "Anmelden"}
            <div style={{ position:"absolute", bottom:0, left:0, right:0, height:3,
              background:`linear-gradient(90deg,${T.gold},${T.goldLight},${T.gold})` }} />
          </button>
        </div>

        {/* Footer */}
        <div style={{ textAlign:"center", marginTop:"1.5rem",
          fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem",
          color:T.textFaint }}>
          Unfallakten-Verwaltung · Intern
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   TOP NAV
══════════════════════════════════════════════════════════════ */
function TopNav({ user, onLogout, backendOnline }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ height:56, background:T.navy, borderBottom:`3px solid ${T.gold}`, display:"flex", alignItems:"center", padding:"0 1.5rem", gap:16, flexShrink:0, zIndex:50, position:"relative" }}>
      <div style={{ display:"flex", alignItems:"center", gap:10 }}>
        <div style={{ width:32, height:32, background:T.gold, borderRadius:6, display:"flex", alignItems:"center", justifyContent:"center", color:T.navy }}>{Ic.logo}</div>
        <div>
          <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.025rem", color:T.white }}>Koch, Schatz &amp; Kollegen</div>
          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.745rem", color:"rgba(255,255,255,0.45)", letterSpacing:"0.1em", textTransform:"uppercase" }}>Unfallakten-System v1.0</div>
        </div>
      </div>
      <div style={{ flex:1 }} />
      <BackendBadge online={backendOnline} />
      <div style={{ position:"relative" }}>
        <button onClick={() => setOpen(o => !o)} style={{ display:"flex", alignItems:"center", gap:8, background:"rgba(255,255,255,0.08)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:8, padding:"6px 12px", cursor:"pointer", color:T.white, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.955rem" }}>
          <div style={{ width:26, height:26, background:T.gold, borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", color:T.navy }}>{Ic.user}</div>
          <span style={{ maxWidth:120, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{user.name}</span>
          <span style={{ fontSize:"0.755rem", background:"rgba(200,168,75,0.2)", color:T.white, border:"1px solid rgba(200,168,75,0.3)", padding:"1px 7px", borderRadius:10 }}>Admin</span>
        </button>
        {open && (
          <div style={{ position:"absolute", top:"calc(100% + 8px)", right:0, background:T.white, border:`1px solid ${T.border}`, borderRadius:10, boxShadow:"0 8px 32px rgba(0,0,0,0.15)", minWidth:200, overflow:"hidden", zIndex:200 }}>
            <div style={{ padding:"12px 14px 8px", borderBottom:`1px solid ${T.border}` }}>
              <div style={{ fontSize:"0.945rem", fontWeight:600, color:T.text }}>{user.name}</div>
              <div style={{ fontSize:"0.855rem", color:T.textMuted }}>{user.email}</div>
            </div>
            <button onClick={() => { setOpen(false); onLogout(); }} style={{ width:"100%", display:"flex", alignItems:"center", gap:8, padding:"10px 14px", background:"none", border:"none", cursor:"pointer", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.955rem", color:T.red }}>
              {Ic.logout} Abmelden
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   TAB BAR
══════════════════════════════════════════════════════════════ */
function TabBar({ tabs, active, onActivate, onClose }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current?.querySelector('[data-active="true"]');
    el?.scrollIntoView({ behavior:"smooth", block:"nearest", inline:"nearest" });
  }, [active]);

  // Nur Aktentabs (id beginnt mit "akte-")
  const akteTabs = tabs.filter(t => t.id.startsWith("akte-"));

  if (akteTabs.length === 0) return (
    <div style={{ height:38, background:T.navyDark, borderBottom:"1px solid rgba(200,168,75,0.12)", display:"flex", alignItems:"center", padding:"0 1.2rem" }}>
      <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", color:"rgba(255,255,255,0.25)", fontStyle:"italic" }}>Keine Akten geöffnet</span>
    </div>
  );

  return (
    <div style={{ background:T.navyDark, borderBottom:"1px solid rgba(200,168,75,0.18)", display:"flex", alignItems:"stretch", flexShrink:0, height:38 }}>
      <div ref={ref} style={{ display:"flex", alignItems:"stretch", overflowX:"auto", flex:1, scrollbarWidth:"none" }}>
        {akteTabs.map(tab => {
          const isA = tab.id === active;
          return (
            <div key={tab.id} data-active={isA} onClick={() => onActivate(tab.id)}
              style={{ display:"flex", alignItems:"center", gap:7, padding:"0 12px", minWidth:140, maxWidth:210, cursor:"pointer", background:isA?"rgba(255,255,255,0.07)":"transparent", borderRight:"1px solid rgba(255,255,255,0.06)", borderBottom:isA?`2px solid ${T.gold}`:"2px solid transparent", transition:"background 0.15s", flexShrink:0, userSelect:"none" }}>
              <span style={{ color:isA?T.gold:"rgba(255,255,255,0.38)", flexShrink:0, fontSize:"0.85rem" }}>{Ic.akte}</span>
              <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.885rem", fontWeight:isA?600:400, color:isA?T.white:"rgba(255,255,255,0.52)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", flex:1 }}>{tab.label}</span>
              {tab.status && <span style={{ width:6, height:6, borderRadius:"50%", background:STATUS_MAP[tab.status]?.color||"#888", flexShrink:0 }} />}
              <span onClick={e => { e.stopPropagation(); onClose(tab.id); }}
                style={{ display:"flex", alignItems:"center", justifyContent:"center", width:16, height:16, borderRadius:3, color:"rgba(255,255,255,0.33)", transition:"all 0.12s", flexShrink:0 }}
                onMouseEnter={e => { e.currentTarget.style.background="rgba(239,68,68,0.16)"; e.currentTarget.style.color="#ef4444"; }}
                onMouseLeave={e => { e.currentTarget.style.background="transparent"; e.currentTarget.style.color="rgba(255,255,255,0.33)"; }}>
                {Ic.x}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   DASHBOARD
══════════════════════════════════════════════════════════════ */
/* ══════════════════════════════════════════════════════════════
   STATISTIKEN VIEW
══════════════════════════════════════════════════════════════ */
const MONATS = [
  {m:"Okt",a:6,r:42000},{m:"Nov",a:9,r:67000},{m:"Dez",a:11,r:89000},
  {m:"Jan",a:8,r:54000},{m:"Feb",a:14,r:103000},{m:"Mär",a:12,r:88000},
];

function StatistikenView() {
  const pie = [
    { name:"Offen",         value:8,  color:T.blue  },
    { name:"Regulierung",   value:14, color:T.amber },
    { name:"Abgeschlossen", value:22, color:T.green },
    { name:"Klage",         value:3,  color:T.red   },
  ];
  return (
    <div style={{ flex:1, overflowY:"auto", background:T.offWhite }}>
      <div style={{ maxWidth:1440, margin:"0 auto", padding:"1.75rem" }}>
        <div style={{ marginBottom:"1.5rem" }}>
          <h1 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"2.0rem", fontWeight:700, color:T.navy, margin:0 }}>Statistiken</h1>
          <p style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.955rem", color:T.textMuted, marginTop:4 }}>
            Übersicht · Entwicklung · Status
          </p>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 220px", gap:"1rem", marginBottom:"1.5rem" }}>
          <Card><div style={{ padding:"1rem 1.4rem 0.4rem" }}>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:"0.8rem" }}>Neue Akten · 6 Monate</div>
            <ResponsiveContainer width="100%" height={180}><BarChart data={MONATS} barSize={20}><XAxis dataKey="m" tick={{fontSize:11,fontFamily:"'IBM Plex Sans',sans-serif",fill:T.textMuted}} axisLine={false} tickLine={false}/><YAxis hide/><Tooltip contentStyle={{fontFamily:"'IBM Plex Sans',sans-serif",fontSize:12,borderRadius:8,border:`1px solid ${T.border}`}} cursor={{fill:`${T.navy}08`}}/><Bar dataKey="a" fill={T.navy} radius={[4,4,0,0]}/></BarChart></ResponsiveContainer>
          </div></Card>
          <Card><div style={{ padding:"1rem 1.4rem 0.4rem" }}>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:"0.8rem" }}>Regulierungen (€) · 6 Monate</div>
            <ResponsiveContainer width="100%" height={180}><LineChart data={MONATS}><XAxis dataKey="m" tick={{fontSize:11,fontFamily:"'IBM Plex Sans',sans-serif",fill:T.textMuted}} axisLine={false} tickLine={false}/><YAxis hide/><Tooltip formatter={v=>fmtEuro(v)} contentStyle={{fontFamily:"'IBM Plex Sans',sans-serif",fontSize:12,borderRadius:8,border:`1px solid ${T.border}`}} cursor={{stroke:`${T.gold}44`}}/><Line type="monotone" dataKey="r" stroke={T.gold} strokeWidth={2.5} dot={{fill:T.gold,r:3}} activeDot={{r:5}}/></LineChart></ResponsiveContainer>
          </div></Card>
          <Card style={{ padding:"1rem 1.25rem" }}>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:"0.8rem" }}>Status-Verteilung</div>
            <ResponsiveContainer width="100%" height={130}><PieChart><Pie data={pie} cx="50%" cy="50%" innerRadius={35} outerRadius={55} dataKey="value" paddingAngle={2}>{pie.map((d,i) => <Cell key={i} fill={d.color}/>)}</Pie></PieChart></ResponsiveContainer>
            <div style={{ display:"flex", flexDirection:"column", gap:5, marginTop:8 }}>
              {pie.map((d,i) => <div key={i} style={{ display:"flex", alignItems:"center", justifyContent:"space-between", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", color:T.textMid }}><span style={{ display:"flex", alignItems:"center", gap:6 }}><span style={{ width:8, height:8, borderRadius:2, background:d.color, flexShrink:0 }}/>{d.name}</span><strong>{d.value}</strong></div>)}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function DashboardView({ onOpenAkte, aktenState }) {
  const [suche, setSuche]   = useState("");
  const [filter, setFilter] = useState("alle");
  const [sortK, setSortK]   = useState("az");
  const [sortD, setSortD]   = useState("asc");
  const [apiError, setApiError]     = useState(null);
  const [liveAkten, setLiveAkten]   = useState(null);
  const [gesamt, setGesamt]         = useState(0);
  const [seite, setSeite]           = useState(1);
  const [seiten, setSeiten]         = useState(1);
  const [loadingAkten, setLoading]  = useState(true);
  const [ramicroAktiv, setRaAktiv]  = useState(true);

  const ladeDaten = React.useCallback((s = 1) => {
    setLoading(true); setApiError(null);
    ramicroListe.laden(s, 50)
      .then(data => {
        setLiveAkten(data.akten || []);
        setGesamt(data.gesamt  || 0);
        setSeite(data.seite    || 1);
        setSeiten(data.seiten  || 1);
        setRaAktiv(data.ramicro_aktiv !== false);
      })
      .catch(err => { setApiError(err); setLiveAkten([]); })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { ladeDaten(1); }, [ladeDaten]);

  // Akten mit lokalem Status-Override zusammenführen
  const akten = React.useMemo(() =>
    (liveAkten || []).map(a => ({
      ...a,
      id:     a.az,
      status: aktenState[a.az]?.status || "offen",
      brutto: 0,
      hq:     100,
    })),
    [liveAkten, aktenState]
  );

  const stats = React.useMemo(() => ({
    gesamt: gesamt,
    offen:  akten.filter(a => a.status==="offen").length,
    in_reg: akten.filter(a => a.status==="in_regulierung").length,
    abg:    akten.filter(a => a.status==="abgeschlossen").length,
    klage:  akten.filter(a => a.status==="klage").length,
  }), [akten, gesamt]);

  const pie = React.useMemo(() => [
    { name:"Offen",         value:stats.offen,  color:T.blue  },
    { name:"Regulierung",   value:stats.in_reg, color:T.amber },
    { name:"Abgeschlossen", value:stats.abg,    color:T.green },
    { name:"Klage",         value:stats.klage,  color:T.red   },
  ].filter(d => d.value > 0), [stats]);

  const gefiltert = React.useMemo(() => akten
    .filter(a => filter==="alle" || a.status===filter)
    .filter(a => {
      if (!suche) return true;
      const s = suche.toLowerCase();
      return [a.az, a.kurzbezeichnung, a.mandant, a.kennzeichen, a.sachbearbeiter]
        .some(f => f?.toLowerCase().includes(s));
    })
    .sort((a, b) => {
      const va = a[sortK]??"", vb = b[sortK]??"";
      return sortD==="asc" ? String(va).localeCompare(String(vb)) : String(vb).localeCompare(String(va));
    }),
  [akten, filter, suche, sortK, sortD]);

  const sortBy = k => { if (sortK===k) setSortD(d => d==="asc"?"desc":"asc"); else { setSortK(k); setSortD("asc"); } };
  const SortIc = ({ k }) => <span style={{ opacity:sortK===k?1:0.3, marginLeft:3, fontSize:"0.785rem" }}>{sortK===k ? (sortD==="asc"?"▲":"▼") : "▲"}</span>;

  return (
    <div style={{ flex:1, overflowY:"auto", background:T.offWhite }}>
      <div style={{ maxWidth:1440, margin:"0 auto", padding:"1.75rem" }}>

        <div style={{ marginBottom:"1.5rem" }}>
          <h1 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"2.0rem", fontWeight:700, color:T.navy, margin:0 }}>Dashboard</h1>
          <p style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.955rem", color:T.textMuted, marginTop:4 }}>
            {new Date().toLocaleDateString("de-DE",{weekday:"long",year:"numeric",month:"long",day:"numeric"})}
          </p>
        </div>

        {/* Fehler-Banner */}
        <ApiErrorBanner error={apiError} onRetry={() => ladeDaten(seite)} />

        {!ramicroAktiv && (
          <div style={{ background:T.amberBg, border:`1px solid ${T.amber}44`, borderRadius:8, padding:"10px 14px", marginBottom:"1rem", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.855rem", color:T.amber }}>
            ℹ RA-Micro nicht verbunden — keine Aktenliste verfügbar. Bitte RAMICRO_AKTIV=true in .env setzen.
          </div>
        )}

        {/* KPI row */}
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(155px,1fr))", gap:"1rem", marginBottom:"1.25rem" }}>
          {loadingAkten
            ? Array.from({length:5}).map((_,i) => (
                <div key={i} style={{ background:T.white, borderRadius:12, padding:"1rem 1.25rem", border:`1px solid ${T.border}`, borderTop:`3px solid ${T.border}` }}>
                  <Skeleton width="55%" height={10} style={{ marginBottom:10 }} />
                  <Skeleton width="35%" height={30} />
                </div>
              ))
            : [
            { label:"Gesamt",       v:stats.gesamt, c:T.navy,  f:"alle"          },
            { label:"Offen",        v:stats.offen,  c:T.blue,  f:"offen"         },
            { label:"Regulierung",  v:stats.in_reg, c:T.amber, f:"in_regulierung"},
            { label:"Abgeschlossen",v:stats.abg,    c:T.green, f:"abgeschlossen" },
            { label:"Klage",        v:stats.klage,  c:T.red,   f:"klage"         },
          ].map((k,i) => (
            <div key={i} onClick={() => setFilter(k.f)} style={{ background:T.white, borderRadius:12, padding:"1rem 1.25rem", border:`1px solid ${T.border}`, borderTop:`3px solid ${k.c}`, boxShadow:"0 2px 6px rgba(0,0,0,0.04)", cursor:"pointer", transition:"transform 0.15s,box-shadow 0.15s" }}
              onMouseEnter={e => { e.currentTarget.style.transform="translateY(-2px)"; e.currentTarget.style.boxShadow="0 6px 20px rgba(0,0,0,0.09)"; }}
              onMouseLeave={e => { e.currentTarget.style.transform=""; e.currentTarget.style.boxShadow="0 2px 6px rgba(0,0,0,0.04)"; }}>
              <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.805rem", fontWeight:600, letterSpacing:"0.08em", textTransform:"uppercase", color:T.textMuted, marginBottom:8 }}>{k.label}</div>
              <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"2.325rem", fontWeight:700, color:k.c, lineHeight:1 }}>{k.v}</div>
            </div>
          ))}
        </div>

        

        {/* Table */}
        <Card>
          <div style={{ display:"flex", alignItems:"center", gap:10, padding:"0.9rem 1.4rem", borderBottom:`1px solid ${T.border}`, flexWrap:"wrap" }}>
            <h2 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.35rem", fontWeight:700, color:T.navy, margin:0, flex:1 }}>Akten</h2>
            <div style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
              {[["alle","Alle"],["offen","Offen"],["in_regulierung","Regulierung"],["abgeschlossen","Abgeschlossen"],["klage","Klage"]].map(([s,l]) => {
                const cnt = s==="alle" ? akten.length : akten.filter(a=>a.status===s).length;
                const sm = STATUS_MAP[s];
                return (
                  <button key={s} onClick={() => setFilter(s)} style={{ padding:"4px 9px", borderRadius:20, border:`1px solid ${filter===s?(sm?.color||T.navy):T.border}`, background:filter===s?(sm?.bg||T.goldPale):"transparent", color:filter===s?(sm?.color||T.navy):T.textMuted, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600, cursor:"pointer" }}>
                    {l} ({cnt})
                  </button>
                );
              })}
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:7, background:T.surface, border:`1px solid ${T.border}`, borderRadius:8, padding:"5px 10px" }}>
              <span style={{ color:T.textFaint }}>{Ic.search}</span>
              <input placeholder="Az., Mandant, Ort …" value={suche} onChange={e => setSuche(e.target.value)}
                style={{ border:"none", background:"transparent", outline:"none", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.955rem", color:T.text, width:180 }} />
            </div>
          </div>
          <div style={{ overflowX:"auto" }}>
            <table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead>
                <tr style={{ background:T.surface }}>
                  {[{k:"az",l:"Aktenzeichen"},{k:"kurzbezeichnung",l:"Kurzbezeichnung"},{k:"mandant",l:"Mandant"},{k:"kennzeichen",l:"KFZ"},{k:"sachbearbeiter",l:"SB"},{k:"status",l:"Status"}].map(c => (
                    <th key={c.l} onClick={() => c.k && sortBy(c.k)} style={{ padding:"8px 14px", textAlign:"left", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.815rem", fontWeight:600, color:T.textMuted, letterSpacing:"0.06em", textTransform:"uppercase", borderBottom:`1px solid ${T.border}`, cursor:c.k?"pointer":"default", whiteSpace:"nowrap", userSelect:"none" }}>
                      {c.l}{c.k && <SortIc k={c.k}/>}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {gefiltert.map((a, i) => (
                  <tr key={a.az} onClick={() => onOpenAkte(a)} style={{ cursor:"pointer", borderBottom:`1px solid ${T.borderSoft}`, background:i%2===0?T.white:T.surface, transition:"background 0.1s" }}
                    onMouseEnter={e => e.currentTarget.style.background = T.goldPale}
                    onMouseLeave={e => e.currentTarget.style.background = i%2===0?T.white:T.surface}>
                    <td style={{ padding:"10px 14px" }}>
                      <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.955rem", fontWeight:600, color:T.navy }}>{a.az}</span>
                    </td>
                    <td style={{ padding:"10px 14px", maxWidth:220, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                      <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.9rem", fontWeight:600, color:T.textMid }}>{a.kurzbezeichnung || "–"}</div>
                      {a.bezeichnung && <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", color:T.textMuted, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{a.bezeichnung}</div>}
                    </td>
                    <td style={{ padding:"10px 14px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.9rem", color:T.textMid }}>{a.mandant || "–"}</td>
                    <td style={{ padding:"10px 14px" }}>
                      {a.kennzeichen
                        ? <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.84rem", fontWeight:700, color:T.blue }}>{a.kennzeichen}</span>
                        : <span style={{ color:T.textFaint }}>–</span>}
                    </td>
                    <td style={{ padding:"10px 14px" }}>
                      {a.sachbearbeiter && <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.84rem", background:T.goldPale, color:T.navy, border:`1px solid ${T.goldTrim}`, borderRadius:5, padding:"2px 7px", fontWeight:600 }}>{a.sachbearbeiter}</span>}
                    </td>
                    <td style={{ padding:"10px 14px" }}><StatusBadge status={aktenState[a.az]?.status || a.status}/></td>
                  </tr>
                ))}
                {gefiltert.length === 0 && !loadingAkten && (
                  <tr><td colSpan={6} style={{ padding:"2rem", textAlign:"center", color:T.textFaint, fontFamily:"'IBM Plex Sans',sans-serif" }}>Keine Akten gefunden.</td></tr>
                )}
              </tbody>
            </table>
          </div>
          {/* Paginierung */}
          <div style={{ padding:"8px 1.4rem", borderTop:`1px solid ${T.border}`, display:"flex", justifyContent:"space-between", alignItems:"center", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.845rem", color:T.textFaint }}>
            <span>{gefiltert.length} gefiltert · {gesamt} gesamt in RA-Micro</span>
            {seiten > 1 && (
              <div style={{ display:"flex", gap:4, alignItems:"center" }}>
                <Btn size="sm" variant="ghost" disabled={seite<=1} onClick={() => ladeDaten(seite-1)}>‹ Zurück</Btn>
                <span style={{ padding:"0 8px" }}>Seite {seite} / {seiten}</span>
                <Btn size="sm" variant="ghost" disabled={seite>=seiten} onClick={() => ladeDaten(seite+1)}>Weiter ›</Btn>
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   HILFSKONSTANTEN REGULIERUNG (werden in Übersicht + Regulierung gebraucht)
══════════════════════════════════════════════════════════════ */
const HAFTUNGSART_CFG = {
  vollhaftung: { label:"Vollhaftung",  color:T.green,  bg:T.greenBg  },
  mithaftung:  { label:"Mithaftung",   color:T.amber,  bg:T.amberBg  },
  quote:       { label:"Quote",        color:T.amber,  bg:T.amberBg  },
  ablehnung:   { label:"Abgelehnt",    color:T.red,    bg:T.redBg    },
};


/* ══════════════════════════════════════════════════════════════
   KOMBINIERTE AKTEN-TIMELINE (Regulierung + Tätigkeit)
══════════════════════════════════════════════════════════════ */
const TIMELINE_FILTER = [
  { id: "alle",         label: "Alles" },
  { id: "regulierung",  label: "Regulierung" },
  { id: "taetigkeit",   label: "Tätigkeit" },
];

const TIMELINE_TYPE_CFG = {
  abrechnung:  { dot: T.green,   badge: T.greenBg,  badgeText: T.green,  label: "Abrechnung"  },
  ablehnung:   { dot: T.red,     badge: T.redBg,    badgeText: T.red,    label: "Ablehnung"   },
  pruefbericht:{ dot: T.amber,   badge: T.amberBg,  badgeText: T.amber,  label: "Prüfbericht" },
  taetigkeit:  { dot: "#7c6bdb", badge: "#ede9fe",  badgeText: "#5b47c8",label: "Tätigkeit"   },
};

/* ── Forderungshistorie pro Schreiben ────────────────────────────────────── */
function ForderungshistorieKarte({ akteId }) {
  const [schreiben, setSchreiben] = React.useState([]);
  const [laden, setLaden]         = React.useState(true);
  const [offen, setOffen]         = React.useState({});   // { nr: bool }
  const [toast, setToast]         = React.useState("");

  React.useEffect(() => {
    if (!akteId || !String(akteId).includes("/")) { setLaden(false); return; }
    apiForderungen.nachSchreiben(akteId)
      .then(r => setSchreiben(r?.schreiben || []))
      .catch(() => {})
      .finally(() => setLaden(false));
  }, [akteId]);

  const toggleKlage = async (pos) => {
    const neuerFlag = !pos.fuer_klage;
    try {
      await apiForderungen.klageFlagSetzen(akteId, [pos.id], neuerFlag);
      setSchreiben(prev => prev.map(s => ({
        ...s,
        positionen: s.positionen.map(p =>
          p.id === pos.id ? { ...p, fuer_klage: neuerFlag } : p
        )
      })));
      setToast(neuerFlag ? "Für Klage vorgemerkt." : "Klage-Flag entfernt.");
    } catch { setToast("Fehler beim Speichern."); }
  };

  const setzeStatus = async (pos, status) => {
    try {
      const res = await apiForderungen.aktualisieren(akteId, pos.id, { status });
      setSchreiben(prev => prev.map(s => ({
        ...s,
        positionen: s.positionen.map(p =>
          p.id === pos.id ? { ...p, status: res?.position?.status || status } : p
        )
      })));
      setToast("Status aktualisiert.");
    } catch { setToast("Fehler beim Speichern."); }
  };

  const STATUS_STYLE = {
    gefordert:     { c: T.textMuted,   bg: T.surface,    label: "offen"         },
    teilreguliert: { c: T.amber,       bg: T.amberBg,    label: "teilreg."      },
    vollreguliert: { c: T.green,       bg: T.greenBg,    label: "✓ voll"        },
    gekuerzt:      { c: "#dc2626",     bg: "#fef2f2",    label: "gekürzt"       },
    abgelehnt:     { c: "#991b1b",     bg: "#fee2e2",    label: "abgelehnt"     },
  };

  if (laden) return (
    <Card style={{ padding: "1.2rem 1.4rem", color: T.textFaint, fontSize: "0.9rem" }}>
      Forderungshistorie wird geladen …
    </Card>
  );

  if (schreiben.length === 0) return (
    <Card style={{ padding: "1.2rem 1.4rem" }}>
      <CardHead title="Forderungshistorie" />
      <p style={{ color: T.textFaint, fontSize: "0.9rem", margin: 0 }}>
        Noch kein Forderungsschreiben der Höhe nach erstellt. Positionen werden
        automatisch beim Generieren erfasst.
      </p>
    </Card>
  );

  const gesamtKlage = schreiben.flatMap(s => s.positionen)
    .filter(p => p.fuer_klage)
    .reduce((sum, p) => sum + (p.betrag_gefordert - p.betrag_reguliert), 0);

  return (
    <Card>
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
      <CardHead title={`Forderungshistorie · ${schreiben.length} Schreiben`}
        action={gesamtKlage > 0
          ? <span style={{ fontSize:"0.82rem", color:"#dc2626", fontWeight:600 }}>
              🏛 Klagepotential: {fmtEuro(gesamtKlage)}
            </span>
          : null}
      />

      <div style={{ display: "flex", flexDirection: "column", gap: "1rem", padding: "0 1.4rem 1.4rem" }}>
        {schreiben.map(s => {
          const isOffen = offen[s.schreiben_nr] !== false; // default aufgeklappt
          const offenCount = s.positionen.filter(p => p.status === "gefordert").length;
          const klageCount = s.positionen.filter(p => p.fuer_klage).length;
          return (
            <div key={s.schreiben_nr} style={{ border: `1px solid ${T.border}`, borderRadius: 10, overflow: "hidden" }}>
              {/* Header */}
              <div
                onClick={() => setOffen(p => ({ ...p, [s.schreiben_nr]: !isOffen }))}
                style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px",
                  background: T.surface, cursor: "pointer", userSelect: "none" }}>
                <span style={{ fontSize: "0.8rem", color: T.textMuted }}>▶</span>
                <span style={{ fontFamily: "'IBM Plex Sans',sans-serif", fontWeight: 600,
                  color: T.navy, fontSize: "0.92rem" }}>
                  Forderungsschreiben Nr. {s.schreiben_nr}
                </span>
                <span style={{ fontFamily: "'IBM Plex Sans',sans-serif", fontSize: "0.82rem",
                  color: T.textFaint }}>
                  {s.datum || "–"}
                </span>
                <span style={{ marginLeft: "auto", fontFamily: "'IBM Plex Mono',monospace",
                  fontSize: "0.88rem", fontWeight: 600, color: T.navy }}>
                  {fmtEuro(s.gesamt_gefordert)}
                </span>
                {offenCount > 0 &&
                  <span style={{ fontSize: 11, padding: "2px 7px", borderRadius: 20,
                    background: T.surface, border: `1px solid ${T.border}`, color: T.textMuted }}>
                    {offenCount} offen
                  </span>}
                {klageCount > 0 &&
                  <span style={{ fontSize: 11, padding: "2px 7px", borderRadius: 20,
                    background: "#fef2f2", color: "#dc2626", fontWeight: 600 }}>
                    {klageCount} Klage
                  </span>}
              </div>

              {/* Positionstabelle */}
              {isOffen && (
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.855rem" }}>
                  <thead>
                    <tr style={{ background: "#f9fafb" }}>
                      {["Position", "Gefordert", "Reguliert", "Status", "Klage"].map((h, i) => (
                        <th key={h} style={{ padding: "7px 12px", textAlign: i === 0 ? "left" : "right",
                          fontSize: "0.74rem", fontWeight: 600, color: T.textMuted,
                          textTransform: "uppercase", letterSpacing: "0.05em",
                          borderTop: `1px solid ${T.border}` }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {s.positionen.map(pos => {
                      const st2 = STATUS_STYLE[pos.status] || STATUS_STYLE.gefordert;
                      return (
                        <tr key={pos.id} style={{ borderTop: `1px solid ${T.border}`,
                          background: pos.fuer_klage ? "#fff5f5" : "white" }}>
                          <td style={{ padding: "8px 12px", color: T.text, fontWeight: 500 }}>
                            {pos.position_label}
                            {pos.position_key === "restwert" &&
                              <span style={{ fontSize: 11, color: T.textFaint, marginLeft: 4 }}>(Abzug)</span>}
                          </td>
                          <td style={{ padding: "8px 12px", textAlign: "right",
                            fontFamily: "'IBM Plex Mono',monospace", color: T.text }}>
                            {fmtEuro(pos.betrag_gefordert)}
                          </td>
                          <td style={{ padding: "8px 12px", textAlign: "right",
                            fontFamily: "'IBM Plex Mono',monospace",
                            color: pos.betrag_reguliert > 0 ? T.green : T.textFaint }}>
                            {pos.betrag_reguliert > 0 ? fmtEuro(pos.betrag_reguliert) : "—"}
                          </td>
                          <td style={{ padding: "8px 12px", textAlign: "right" }}>
                            <select
                              value={pos.status}
                              onChange={e => setzeStatus(pos, e.target.value)}
                              style={{ fontSize: 11, padding: "2px 6px", borderRadius: 12,
                                background: st2.bg, color: st2.c, border: `1px solid ${st2.c}44`,
                                fontWeight: 600, cursor: "pointer", outline: "none" }}>
                              {Object.entries(STATUS_STYLE).map(([val, { label }]) => (
                                <option key={val} value={val}>{label}</option>
                              ))}
                            </select>
                          </td>
                          <td style={{ padding: "8px 12px", textAlign: "right" }}>
                            <button
                              onClick={() => toggleKlage(pos)}
                              title={pos.fuer_klage ? "Klage-Flag entfernen" : "Für Klage vormerken"}
                              style={{ padding: "3px 8px", borderRadius: 8, border: "none",
                                background: pos.fuer_klage ? "#fef2f2" : T.surface,
                                color: pos.fuer_klage ? "#dc2626" : T.textFaint,
                                cursor: "pointer", fontSize: 13, fontWeight: pos.fuer_klage ? 700 : 400 }}>
                              {pos.fuer_klage ? "🏛 Klage" : "○"}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr style={{ borderTop: `2px solid ${T.border}`, background: T.surface }}>
                      <td style={{ padding: "8px 12px", fontWeight: 700, color: T.navy,
                        fontSize: "0.85rem" }}>Summe</td>
                      <td style={{ padding: "8px 12px", textAlign: "right",
                        fontFamily: "'IBM Plex Mono',monospace", fontWeight: 700, color: T.navy }}>
                        {fmtEuro(s.gesamt_gefordert)}
                      </td>
                      <td style={{ padding: "8px 12px", textAlign: "right",
                        fontFamily: "'IBM Plex Mono',monospace", fontWeight: 700, color: T.green }}>
                        {s.gesamt_reguliert > 0 ? fmtEuro(s.gesamt_reguliert) : "—"}
                      </td>
                      <td colSpan={2} />
                    </tr>
                  </tfoot>
                </table>
              )}
            </div>
          );
        })}
      </div>
    </Card>
  );
}

function AktenTimeline({ abrechnungen, aktivitaeten, akteId, onAktivitaetenChange }) {
  const [filter, setFilter] = useState("alle");
  const [loeschend, setLoeschend] = useState(null); // id gerade gelöscht wird

  const loescheAktivitaet = async (id) => {
    setLoeschend(id);
    try {
      await apiAkten.aktivitaetLoeschen(akteId, id);
      if (onAktivitaetenChange) onAktivitaetenChange();
    } catch (e) {
      alert("Löschen fehlgeschlagen: " + (e?.message || e));
    } finally {
      setLoeschend(null);
    }
  };

  const regEntries = abrechnungen.map(ab => {
    const ha  = HAFTUNGSART_CFG[ab.haftungsart] || HAFTUNGSART_CFG.vollhaftung;
    const typ = ab.haftungsart === "ablehnung" ? "ablehnung" : "abrechnung";
    return {
      id: `ab-${ab.id}`, kategorie:"regulierung", typ,
      datum: ab.datum || "",
      titel: ab.versicherung || "Abrechnungsschreiben",
      zeile1: "Reguliert: " + fmtEuro(ab.gesamt_reguliert) +
              (ab.gesamt_kuerzung > 0 ? "  ·  Kürzung: −" + fmtEuro(ab.gesamt_kuerzung) : ""),
      zeile2: ab.referenz_nr || "",
      dotColor: ha.color,
    };
  });

  const aktEntries = aktivitaeten.map((a, i) => {
    // Backend liefert: zeitstempel, aktion (Kurzcode), beschreibung (Lesetext)
    // Lesbarer Titel je Aktionstyp
    const aktionLabels = {
      pdf_import_gutachten:            "📄 Gutachten geparst",
      pdf_import_abrechnungsschreiben: "📄 Abrechnungsschreiben geparst",
      pdf_import_pruefbericht:         "📄 Prüfbericht geparst",
      pdf_import_unbekannt:            "📄 PDF-Dokument geparst",
      dokument_hochgeladen:            "📎 Dokument hochgeladen",
      login:                           "🔐 Anmeldung",
      akte_erstellt:                   "📁 Akte angelegt",
      beteiligter_angelegt:            "👤 Beteiligter angelegt",
      beteiligter_geaendert:           "👤 Beteiligter geändert",
      schaden_gespeichert:             "💶 Schaden gespeichert",
      schaden_aktualisiert:            "💶 Schaden aktualisiert",
      status_geaendert:                "🔄 Status geändert",
      notizen_geaendert:               "📝 Notizen geändert",
      haftungsquote_geaendert:         "⚖️ Haftungsquote geändert",
      wiedervorlage_erstellt:          "📅 Wiedervorlage erstellt",
      email_importiert:                "✉ E-Mail importiert",
    };
    const aktionCode = a.aktion || "";
    const titel = aktionLabels[aktionCode] || aktionCode.replace(/_/g, " ");
    // Datum: zeitstempel aus DB — SQLite: "2026-03-15 18:25:19", ISO: "2026-03-15T18:25:19"
    let datum = a.zeitstempel || a.zeit || "";
    let datumAnzeige = datum;
    let uhrzeitAnzeige = "";
    try {
      // SQLite-Format: Leerzeichen durch T ersetzen damit Date() es parst
      const d = new Date(datum.replace(" ", "T"));
      if (!isNaN(d)) {
        datumAnzeige  = d.toLocaleDateString("de-DE", { day:"2-digit", month:"2-digit", year:"numeric" });
        uhrzeitAnzeige = d.toLocaleTimeString("de-DE", { hour:"2-digit", minute:"2-digit" });
        datum = datumAnzeige + " " + uhrzeitAnzeige;
      }
    } catch { /* Originalformat behalten */ }
    return {
      id: "ak-" + (a.id ?? i), kategorie:"taetigkeit", typ:"taetigkeit",
      datum,
      datumAnzeige,
      uhrzeitAnzeige,
      titel,
      zeile1: a.beschreibung || a.aktion || "",
      zeile2: "",
      dotColor: TIMELINE_TYPE_CFG.taetigkeit.dot,
    };
  });

  const alle = [...regEntries, ...aktEntries].sort((a, b) => {
    const toSort = s => s.includes(".") ? s.split(".").reverse().join("-") : s;
    return toSort(b.datum).localeCompare(toSort(a.datum));
  });

  const sichtbar = filter === "alle" ? alle :
                   alle.filter(e => e.kategorie === filter);

  return (
    <Card>
      <div style={{ padding:"1rem 1.4rem 0", display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:8 }}>
        <div style={{ fontSize:"0.825rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.08em" }}>
          {"Akten-Chronik"}
          <span style={{ fontWeight:400, fontSize:"0.8rem", marginLeft:8, color:T.textFaint }}>{sichtbar.length} Einträge</span>
        </div>
        <div style={{ display:"flex", gap:4 }}>
          {TIMELINE_FILTER.map(f => (
            <button key={f.id} onClick={() => setFilter(f.id)}
              style={{ padding:"4px 12px", borderRadius:20, fontSize:"0.83rem", cursor:"pointer",
                fontFamily:"'IBM Plex Sans',sans-serif", fontWeight: filter===f.id ? 600 : 400,
                border:"1.5px solid " + (filter===f.id ? T.gold : T.border),
                background: filter===f.id ? T.goldPale : "transparent",
                color: filter===f.id ? T.navy : T.textMuted, transition:"all 0.12s" }}>
              {f.label}
            </button>
          ))}
        </div>
      </div>
      <div style={{ padding:"0.75rem 1.4rem 1rem" }}>
        {sichtbar.length === 0 ? (
          <div style={{ padding:"2rem 0", textAlign:"center", color:T.textFaint, fontSize:"0.9rem" }}>
            {filter === "alle" ? "Noch keine Einträge." : "Keine Einträge für diesen Filter."}
          </div>
        ) : (
          <div style={{ position:"relative" }}>
            <div style={{ position:"absolute", left:11, top:8, bottom:8, width:1, background:T.border, zIndex:0 }} />
            <div style={{ display:"flex", flexDirection:"column", gap:0 }}>
              {sichtbar.map((e, idx) => {
                const cfg = TIMELINE_TYPE_CFG[e.typ] || TIMELINE_TYPE_CFG.taetigkeit;
                const isLast = idx === sichtbar.length - 1;
                const istAktivitaet = e.kategorie === "taetigkeit";
                const aktId = istAktivitaet ? parseInt(e.id.replace("ak-","")) : null;
                return (
                  <div key={e.id} style={{ display:"flex", gap:14, paddingBottom: isLast ? 0 : 16, position:"relative", zIndex:1 }}>
                    <div style={{ flexShrink:0, width:24, display:"flex", justifyContent:"center", paddingTop:3 }}>
                      <div style={{ width:10, height:10, borderRadius:"50%", background:e.dotColor, border:"2px solid " + T.offWhite, flexShrink:0 }} />
                    </div>
                    <div style={{ flex:1, minWidth:0, paddingBottom: isLast ? 0 : 4 }}>
                      <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", gap:8, flexWrap:"wrap", marginBottom:2 }}>
                        <div style={{ display:"flex", alignItems:"center", gap:7, flexWrap:"wrap" }}>
                          <span style={{ fontSize:"0.88rem", fontWeight:600, color:T.text }}>{e.titel}</span>
                          <span style={{ fontSize:"0.72rem", fontWeight:600, padding:"1px 7px", borderRadius:20,
                            background:cfg.badge, color:cfg.badgeText }}>{cfg.label}</span>
                        </div>
                        <div style={{ display:"flex", alignItems:"center", gap:8, flexShrink:0 }}>
                          <div style={{ textAlign:"right" }}>
                            <div style={{ fontSize:"0.8rem", color:T.textMuted, fontFamily:"monospace", fontWeight:500 }}>
                              {e.datumAnzeige || e.datum}
                            </div>
                            {e.uhrzeitAnzeige && (
                              <div style={{ fontSize:"0.75rem", color:T.textFaint, fontFamily:"monospace" }}>
                                {e.uhrzeitAnzeige} Uhr
                              </div>
                            )}
                          </div>
                          {istAktivitaet && aktId && (
                            <button
                              onClick={() => loescheAktivitaet(aktId)}
                              disabled={loeschend === aktId}
                              title="Eintrag löschen"
                              style={{
                                background: "none", border: "none", cursor: loeschend === aktId ? "wait" : "pointer",
                                padding: "2px 4px", borderRadius: 4, color: T.textFaint,
                                fontSize: "0.85rem", lineHeight:1,
                                transition: "color 0.15s",
                                opacity: loeschend === aktId ? 0.4 : 1,
                              }}
                              onMouseEnter={e2 => e2.currentTarget.style.color = "#c0392b"}
                              onMouseLeave={e2 => e2.currentTarget.style.color = T.textFaint}
                            >
                              🗑
                            </button>
                          )}
                        </div>
                      </div>
                      {e.zeile1 && <div style={{ fontSize:"0.845rem", color:T.textMuted, marginBottom:1 }}>{e.zeile1}</div>}
                      {e.zeile2 && <div style={{ fontSize:"0.8rem", color:T.textFaint }}>{e.zeile2}</div>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}

/* ══════════════════════════════════════════════════════════════
   SECTION: ÜBERSICHT
══════════════════════════════════════════════════════════════ */
/* ══════════════════════════════════════════════════════════════
   RA-MICRO AKTE-ÜBERSICHT (lesend aus SQL)
══════════════════════════════════════════════════════════════ */

function InfoZeile({ label, value, mono=false, bold=false }) {
  if (!value) return null;
  return (
    <div style={{ display:"flex", gap:8, padding:"4px 0", borderBottom:`1px solid ${T.borderSoft}` }}>
      <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", color:T.textFaint, width:110, flexShrink:0, paddingTop:1 }}>{label}</span>
      <span style={{ fontFamily: mono?"'IBM Plex Mono',monospace":"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:T.text, fontWeight: bold?600:400 }}>{value}</span>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────
   RECHTSSCHUTZ-KLAPPKACHEL (eingeklappt, aufklappbar)
────────────────────────────────────────────────────────────── */
function RechtsschutzKlappkachel({ beteiligte }) {
  const [offen, setOffen] = React.useState(false);
  if (!beteiligte || !beteiligte.length) return null;
  return (
    <div style={{ marginTop:6 }}>
      {/* Toggle-Zeile */}
      <button
        onClick={() => setOffen(o => !o)}
        style={{
          width:"100%", display:"flex", alignItems:"center", justifyContent:"space-between",
          background: offen ? T.greenPale : T.surface,
          border:`1px solid ${offen ? T.green+"55" : T.border}`,
          borderRadius: offen ? "8px 8px 0 0" : 8,
          padding:"6px 12px", cursor:"pointer", transition:"all 0.18s",
        }}>
        <span style={{
          fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", fontWeight:600,
          color: offen ? T.green : T.textMuted,
          textTransform:"uppercase", letterSpacing:"0.08em",
        }}>
          Rechtsschutzversicherung
        </span>
        <span style={{
          fontSize:"1rem", color: offen ? T.green : T.textMuted,
          transform: offen ? "rotate(180deg)" : "none",
          transition:"transform 0.2s",
          lineHeight:1,
        }}>⌄⌄</span>
      </button>
      {/* Ausgeklappter Inhalt */}
      {offen && (
        <div style={{
          border:`1px solid ${T.green}55`, borderTop:"none",
          borderRadius:"0 0 8px 8px",
          background: T.greenPale,
          padding:"10px 12px",
          animation:"fadeIn 0.15s ease",
        }}>
          <BeteiligterKachel
            titel="" farbe={T.green}
            beteiligte={beteiligte}
            zeigeBetreff zeigeAktenzeichen
          />
        </div>
      )}
    </div>
  );
}

function BeteiligterKachel({ titel, farbe, beteiligte, zeigeFirma=false, zeigeBetreff=false, zeigeAktenzeichen=false, nurEiner=false, akteId=null }) {
  const liste = nurEiner ? beteiligte.slice(0,1) : beteiligte;
  if (!liste.length) return null;

  // IBAN-Check: nur für Mandantenkachel
  const [ibanCheck, setIbanCheck] = useState(null); // null=lädt, {iban_vorhanden, mandant_email, ...}
  React.useEffect(() => {
    if (titel !== "Mandant" || !akteId || !akteId.includes("/")) return;
    request(`/ramicro/akte/mandant-checks?az=${encodeURIComponent(akteId)}`)
      .then(d => setIbanCheck(d))
      .catch(() => setIbanCheck({ iban_vorhanden: null }));
  }, [akteId, titel]);

  const ibanMailtoLink = () => {
    const mandant = liste[0];
    const email   = ibanCheck?.mandant_email || mandant?.email || "";
    const name    = ibanCheck?.mandant_name  || mandant?.name  || "Mandant";
    const anrede  = ["Herr","Herrn","Hr."].includes((mandant?.anrede||"").trim())
      ? `Sehr geehrter Herr ${name.split(" ").pop()},`
      : ["Frau","Fr."].includes((mandant?.anrede||"").trim())
        ? `Sehr geehrte Frau ${name.split(" ").pop()},`
        : `Sehr geehrte/r ${name},`;
    const betreff = encodeURIComponent("Bankverbindung für Ihre Akte");
    const body    = encodeURIComponent(
      `${anrede}\n\nfür die Geltendmachung Ihrer Schadensersatzansprüche benötigen wir noch Ihre Bankverbindung (IBAN).\n\nBitte teilen Sie uns Ihre IBAN baldmöglichst mit, damit wir eingegangene Zahlungen umgehend an Sie weiterleiten können.\n\nMit freundlichen Grüßen\nRechtsanwälte Koch, Schatz & Kollegen`
    );
    return `mailto:${email}?subject=${betreff}&body=${body}`;
  };

  const vollmachtMailtoLink = () => {
    const mandant = liste[0];
    const email   = ibanCheck?.mandant_email || mandant?.email || "";
    const name    = ibanCheck?.mandant_name  || mandant?.name  || "Mandant";
    const anrede  = ["Herr","Herrn","Hr."].includes((mandant?.anrede||"").trim())
      ? `Sehr geehrter Herr ${name.split(" ").pop()},`
      : ["Frau","Fr."].includes((mandant?.anrede||"").trim())
        ? `Sehr geehrte Frau ${name.split(" ").pop()},`
        : `Sehr geehrte/r ${name},`;
    const betreff = encodeURIComponent("Vollmacht – Bitte unterzeichnen und zurücksenden");
    const body    = encodeURIComponent(
      `${anrede}\n\nim Anhang erhalten Sie die Vollmacht für die Bearbeitung Ihrer Schadenssache.\n\nBitte unterzeichnen Sie diese und senden Sie uns die Vollmacht baldmöglichst zurück – per E-Mail, Post oder Fax.\n\nFür Rückfragen stehen wir Ihnen gerne zur Verfügung.\n\nMit freundlichen Grüßen\nRechtsanwälte Koch, Schatz & Kollegen`
    );
    return `mailto:${email}?subject=${betreff}&body=${body}`;
  };

  const mailtoLink = (b) => {
    if (!b.email) return null;
    const betreffs = [b.betreff1, b.betreff2, b.betreff3].filter(Boolean).join(" – ");
    return `mailto:${b.email}${betreffs ? `?subject=${encodeURIComponent(betreffs)}` : ""}`;
  };

  return (
    <div style={{ background:T.white, border: titel ? `1px solid ${T.border}` : "none", borderRadius: titel ? 10 : 0, overflow:"hidden", boxShadow: titel ? "0 1px 4px rgba(0,0,0,0.04)" : "none" }}>
      {/* Kachel-Header – wird ausgeblendet wenn kein Titel (z.B. in RechtsschutzKlappkachel) */}
      {titel && <div style={{ background: farbe + "18", borderBottom:`1px solid ${farbe}33`, padding:"8px 14px", display:"flex", alignItems:"center", gap:8 }}>
        <div style={{ width:8, height:8, borderRadius:"50%", background: farbe, flexShrink:0 }} />
        <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", fontWeight:600, color: farbe, textTransform:"uppercase", letterSpacing:"0.08em" }}>{titel}</span>
        {liste.length > 1 && <span style={{ marginLeft:"auto", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", color:T.textFaint }}>{liste.length} Einträge</span>}
      </div>}

      {/* Einträge */}
      {liste.map((b, i) => (
        <div key={i} style={{ padding:"10px 14px", borderBottom: i < liste.length-1 ? `1px solid ${T.borderSoft}` : "none" }}>
          {/* Name / Firma */}
          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.925rem", fontWeight:600, color:T.navy, marginBottom:3 }}>
            {zeigeFirma && b.name ? b.name : b.name || "–"}
            {b.kennzeichen && <span style={{ marginLeft:8, fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.75rem", background:T.goldPale, color:T.navy, border:`1px solid ${T.goldTrim}`, borderRadius:4, padding:"1px 5px" }}>{b.kennzeichen}</span>}
          </div>

          {/* Betreffzeilen (fett) */}
          {zeigeBetreff && (b.betreff1 || b.betreff2 || b.betreff3) && (
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.855rem", fontWeight:600, color:T.textMid, marginBottom:4 }}>
              {[b.betreff1, b.betreff2, b.betreff3].filter(Boolean).join(" · ")}
            </div>
          )}

          {/* Aktenzeichen (fett, für Behörden) */}
          {zeigeAktenzeichen && b.betreff1 && (
            <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.855rem", fontWeight:700, color:T.navy, marginBottom:4 }}>
              {b.betreff1}
            </div>
          )}

          {/* Adressdetails */}
          <div style={{ display:"flex", flexDirection:"column", gap:2 }}>
            {b.strasse && <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", color:T.textMuted }}>{b.strasse}{b.plz || b.ort ? `, ${b.plz} ${b.ort}`.trim() : ""}</span>}
            {b.telefon  && <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", color:T.textMuted }}>☎ {b.telefon}</span>}
            {b.telefon2 && <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", color:T.textMuted }}>☎ {b.telefon2}</span>}
            {b.mobil    && <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", color:T.textMuted }}>📱 {b.mobil}</span>}
            {b.fax      && <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", color:T.textMuted }}>📠 {b.fax}</span>}
            {b.email && (
              <a href={mailtoLink(b)} style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", color:T.blue, textDecoration:"none" }}
                 onMouseEnter={e => e.target.style.textDecoration="underline"}
                 onMouseLeave={e => e.target.style.textDecoration="none"}>
                ✉ {b.email}
              </a>
            )}
            {/* IBAN-Check nur bei Mandanten */}
            {titel === "Mandant" && (
              <div style={{ marginTop:4, display:"flex", alignItems:"center", gap:6, flexWrap:"wrap" }}>
                {ibanCheck === null ? (
                  <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", color:T.textFaint }}>
                    ⟳ IBAN wird geprüft…
                  </span>
                ) : ibanCheck.iban_vorhanden ? (
                  <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem",
                    color:"#16a34a", display:"flex", alignItems:"center", gap:4 }}>
                    <span style={{ fontSize:"0.9rem" }}>✅</span>
                    IBAN erfasst
                    {ibanCheck.geldinstitut && (
                      <span style={{ color:T.textFaint, fontSize:"0.77rem" }}>({ibanCheck.geldinstitut})</span>
                    )}
                  </span>
                ) : ibanCheck.iban_vorhanden === false ? (
                  <span style={{ display:"flex", alignItems:"center", gap:6, flexWrap:"wrap" }}>
                    <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem",
                      color:T.red, display:"flex", alignItems:"center", gap:4 }}>
                      <span style={{ fontSize:"0.9rem" }}>❌</span>
                      IBAN nicht erfasst
                    </span>
                    {(ibanCheck.mandant_email || b.email) && (
                      <a href={ibanMailtoLink()}
                        style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.77rem",
                          padding:"2px 8px", background:T.blueBg,
                          border:`1px solid ${T.blue}55`, borderRadius:5,
                          color:T.navy, textDecoration:"none", whiteSpace:"nowrap",
                          cursor:"pointer", fontWeight:600 }}>
                        ✉ IBAN anfordern
                      </a>
                    )}
                  </span>
                ) : (
                  <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", color:T.textFaint }}>
                    ○ IBAN: keine RA-Micro-Verbindung
                  </span>
                )}
              </div>
            )}
            {/* Vollmacht-Check */}
            {titel === "Mandant" && (
              <div style={{ marginTop:4, display:"flex", alignItems:"center", gap:6, flexWrap:"wrap" }}>
                {ibanCheck === null ? (
                  <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", color:T.textFaint }}>
                    ⟳ Vollmacht wird geprüft…
                  </span>
                ) : ibanCheck.vollmacht_vorhanden ? (
                  <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem",
                    color:"#16a34a", display:"flex", alignItems:"center", gap:4 }}>
                    <span style={{ fontSize:"0.9rem" }}>✅</span>
                    Vollmacht liegt vor
                  </span>
                ) : ibanCheck.vollmacht_vorhanden === false ? (
                  <span style={{ display:"flex", alignItems:"center", gap:6, flexWrap:"wrap" }}>
                    <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem",
                      color:T.red, display:"flex", alignItems:"center", gap:4 }}>
                      <span style={{ fontSize:"0.9rem" }}>❌</span>
                      Vollmacht fehlt
                    </span>
                    {(ibanCheck.mandant_email || b.email) && (
                      <a href={vollmachtMailtoLink()}
                        style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.77rem",
                          padding:"2px 8px", background:"#fdf4ff",
                          border:"1px solid #d8b4fe", borderRadius:5,
                          color:"#6b21a8", textDecoration:"none", whiteSpace:"nowrap",
                          cursor:"pointer", fontWeight:600 }}>
                        ✉ Vollmacht anfordern
                      </a>
                    )}
                    {akteId && (
                      <button
                        onClick={async () => {
                          try {
                            const token = tokenStore.getAccess();
                            const base = (typeof import.meta !== "undefined" && import.meta.env?.VITE_API_URL) || "";
                            const res = await fetch(`${base}/ramicro/akte/vollmacht?az=${encodeURIComponent(akteId)}`, {
                              headers: { Authorization: `Bearer ${token}` }
                            });
                            if (!res.ok) {
                              const err = await res.json().catch(() => ({}));
                              alert(`Fehler: ${err.fehler || err.typ || res.status}\n${err.pfad ? "Pfad: " + err.pfad : ""}`);
                              return;
                            }
                            const blob = await res.blob();
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement("a");
                            a.href = url;
                            a.download = `Vollmacht_${(akteId||"").replace("/","_")}.pdf`;
                            document.body.appendChild(a);
                            a.click();
                            document.body.removeChild(a);
                            setTimeout(() => URL.revokeObjectURL(url), 5000);
                          } catch(e) {
                            alert(`Vollmacht-Fehler: ${e.message}`);
                          }
                        }}
                        style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.77rem",
                          padding:"2px 8px", background:"#f0fdf4",
                          border:"1px solid #86efac", borderRadius:5,
                          color:"#15803d", cursor:"pointer", fontWeight:600,
                          whiteSpace:"nowrap", outline:"none" }}>
                        ↓ Vollmacht generieren
                      </button>
                    )}
                  </span>
                ) : null}
              </div>
            )}
            {/* Vorsteuerabzug nur bei Mandanten anzeigen */}
            {titel === "Mandant" && (
              <span style={{
                fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem",
                color: ["Y","J","JA","1"].includes((b.vorsteuer||"").toUpperCase()) ? T.amber : T.textFaint,
                marginTop:2, display:"flex", alignItems:"center", gap:4,
              }}>
                <span style={{ fontSize:"0.7rem" }}>
                  {["Y","J","JA","1"].includes((b.vorsteuer||"").toUpperCase()) ? "⚡" : "○"}
                </span>
                Vorsteuerabzug: <strong>{["Y","J","JA","1"].includes((b.vorsteuer||"").toUpperCase()) ? "Ja" : "Nein"}</strong>
              </span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

function EigeneVersicherungMini({ beteiligte }) {
  if (!beteiligte.length) return null;
  return (
    <div style={{ marginTop:8, background: T.surface, border:`1px solid ${T.border}`, borderRadius:7, padding:"7px 12px" }}>
      <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.75rem", fontWeight:600, color:T.textFaint, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:5 }}>
        Eigene Versicherung
      </div>
      {beteiligte.map((b, i) => (
        <div key={i} style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.855rem", color:T.textMid, marginBottom: i < beteiligte.length-1 ? 3 : 0 }}>
          <span style={{ fontWeight:600 }}>{b.name || b.firma}</span>
          {b.kennzeichen && <span style={{ marginLeft:6, fontSize:"0.78rem", color:T.textFaint }}>[{b.kennzeichen}]</span>}
          {b.telefon && <span style={{ marginLeft:8, color:T.textFaint, fontSize:"0.8rem" }}>☎ {b.telefon}</span>}
        </div>
      ))}
    </div>
  );
}

function RaMicroAkteUebersicht({ azRoh }) {
  const [daten, setDaten]   = useState(null);
  const [laden, setLaden]   = useState(true);
  const [fehler, setFehler] = useState("");

  useEffect(() => {
    setLaden(true); setFehler("");
    apiRaMicroAkte.laden(azRoh)
      .then(d => { setDaten(d); })
      .catch(e => setFehler(e?.message || "Fehler beim Laden der RA-Micro-Daten."))
      .finally(() => setLaden(false));
  }, [azRoh]);

  if (laden) return (
    <div style={{ display:"flex", alignItems:"center", gap:10, padding:"2rem", color:T.textFaint, fontFamily:"'IBM Plex Sans',sans-serif" }}>
      <div style={{ width:18, height:18, border:`2px solid ${T.gold}`, borderTopColor:"transparent", borderRadius:"50%", animation:"spin 0.8s linear infinite" }} />
      Lade RA-Micro Daten …
    </div>
  );

  if (fehler) return (
    <Card>
      <div style={{ padding:"1rem 1.4rem", display:"flex", alignItems:"center", justifyContent:"space-between", flexWrap:"wrap", gap:10 }}>
        <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:T.amber }}>
          ℹ RA-Micro Daten konnten nicht geladen werden — {fehler}
        </div>
        <Btn size="sm" variant="secondary" onClick={() => {
          setLaden(true); setFehler("");
          apiRaMicroAkte.laden(azRoh)
            .then(d => setDaten(d))
            .catch(e => setFehler(e?.message || "Fehler"))
            .finally(() => setLaden(false));
        }}>↻ Erneut laden</Btn>
      </div>
    </Card>
  );

  if (!daten) return null;

  const { stammdaten: s, beteiligte: b } = daten;

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"1.1rem" }}>

      {/* Stammdaten kompakt – zwei Zeilen, alle Felder nebeneinander */}
      <Card>
        <div style={{ padding:"0.7rem 1.4rem", display:"flex", flexWrap:"wrap", gap:"0.4rem 2rem", alignItems:"baseline" }}>
          {[
            { l:"AZ",         v:s.az,            mono:true,  bold:true  },
            { l:"SB",         v:s.sachbearbeiter, mono:true              },
            { l:"Unfalltag",  v:s.unfalltag,     mono:true              },
            { l:"KFZ",        v:s.kfz_mandant,   mono:true, bold:true   },
            { l:"KFZ Gegner", v:s.kfz_gegner,    mono:true              },
            { l:"Mandant",    v:s.mandant                                },
            { l:"Gegner",     v:s.gegner                                 },
            { l:"Kurzbezeichnung", v:s.kurzbezeichnung                  },
          ].filter(f => f.v).map(f => (
            <div key={f.l} style={{ display:"flex", alignItems:"baseline", gap:5 }}>
              <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.75rem", color:T.textFaint, whiteSpace:"nowrap" }}>{f.l}</span>
              <span style={{ fontFamily: f.mono ? "'IBM Plex Mono',monospace" : "'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:T.text, fontWeight: f.bold ? 700 : 400, whiteSpace:"nowrap" }}>{f.v}</span>
            </div>
          ))}
        </div>
        {s.bezeichnung && (
          <div style={{ padding:"0 1.4rem 0.6rem", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", color:T.textMuted }}>{s.bezeichnung}</div>
        )}
      </Card>

      {/* Beteiligten-Kacheln */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(300px,1fr))", gap:"0.9rem" }}>

        {/* Mandant + Rechtsschutz nebeneinander + angedockte eigene Versicherung */}
        {(b.mandant.length > 0 || b.rechtsschutz.length > 0) && (
          <div style={{ display:"contents" }}>
            {b.mandant.length > 0 && (
              <div>
                <BeteiligterKachel
                  titel="Mandant" farbe={T.navy}
                  beteiligte={b.mandant} nurEiner
                  zeigeBetreff zeigeAktenzeichen={false}
                  akteId={azRoh}
                />
                <EigeneVersicherungMini beteiligte={b.eigene_versicherung} />
                {b.rechtsschutz.length > 0 && (
                  <RechtsschutzKlappkachel beteiligte={b.rechtsschutz} />
                )}
                {b.weitere.length > 0 && (
                  <div style={{ marginTop:6 }}>
                    <BeteiligterKachel
                      titel="Weitere Beteiligte" farbe={T.textMuted}
                      beteiligte={b.weitere}
                      zeigeFirma zeigeBetreff
                    />
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Gegner */}
        <BeteiligterKachel
          titel="Gegner" farbe={T.red}
          beteiligte={b.gegner}
          zeigeBetreff zeigeAktenzeichen={false}
        />

        {/* Behörden / Gerichte */}
        <BeteiligterKachel
          titel="Behörden / Gerichte" farbe={T.amber}
          beteiligte={b.behoerde}
          zeigeAktenzeichen zeigeBetreff={false}
        />

      </div>
    </div>
  );
}

function UebersichtSection({ akte, st, dispatch }) {
  const [notizen, setNotizen] = useState(st.notizen || "");
  const [nChanged, setNC]     = useState(false);
  const [toast, setToast]     = useState("");

  // Aktivitäten beim ersten Rendern aus API laden
  useEffect(() => {
    apiAkten.aktivitaeten(akte.id)
      .then(data => {
        if (data?.aktivitaeten) {
          dispatch({ type: "SET_AKTIVITAETEN", akteId: akte.id, aktivitaeten: data.aktivitaeten });
        }
      })
      .catch(() => { /* Fehler ignorieren – Mock-Daten bleiben */ });
  }, [akte.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const mandant    = st.beteiligte?.find(b => b.rolle === "mandant");
  const gegner     = st.beteiligte?.find(b => b.rolle === "gegner");
  const schaden    = st.schaden || {};
  const abrechnungen = st.abrechnungen || [];
  // Brutto mit Totalschaden-Logik (WBW-Restwert wenn Totalschaden, nicht WBW+Rep)
  const _g  = k => parseFloat(schaden[k]) || 0;
  const _repN  = _g("rep_gutachten_netto") || _g("reparaturkosten");
  const _repRN = _g("rep_rechnung_netto");
  const _effRep = _repRN > 0 ? _repRN : _repN;
  const _wbw = _g("wiederbeschaffung"), _rst = _g("restwert");
  const _nettoFzg = _wbw - _rst;
  const _ist130a = _repRN > 0 && _wbw > 0 && _repRN > _nettoFzg && _repRN <= 1.3 * _wbw;
  const _fzg = _wbw > 0 ? (_ist130a || (_effRep > 0 && _effRep <= _nettoFzg) ? _effRep : _nettoFzg) : _effRep;
  const _kkExtras = (() => {
    if (schaden._extras && schaden._extras.length > 0) return schaden._extras;
    if (schaden.wdm_extras_json) {
      try { const p = JSON.parse(schaden.wdm_extras_json); if (Array.isArray(p)) return p; } catch {}
    }
    return [];
  })();
  const _berechneterBruttoKK = _fzg
    + _g("wertminderung") + _g("nutzungsausfall") + _g("mietwagenkosten")
    + _g("sv_kosten") + _g("abschleppkosten") + _g("standkosten")
    + _g("anabmeldekosten") + _g("schmerzensgeld") + _g("sonstiges")
    + _g("verdienstausfall") + _g("haushalt") + (_g("unkostenpauschale") || 0)
    + _g("kostennb") + _g("kostennb_ust")
    + _kkExtras.reduce((s, e) => s + (parseFloat(e.betrag) || 0), 0);
  const brutto = _berechneterBruttoKK > 0 ? _berechneterBruttoKK
    : (schaden.gesamt_brutto || 0);
  const netto      = brutto * ((akte.hq || 100) / 100);

  // Alle Positionen aus allen Abrechnungen aggregieren (letzte regulierte Werte je Position)
  const posMap = {};
  abrechnungen.slice().reverse().forEach(ab => {
    (ab.positionen || []).forEach(p => {
      const key = p.position_key || p.art || "sonstiges";
      if (!posMap[key]) posMap[key] = { gefordert: 0, reguliert: 0, kuerungenBetrag: 0, fuerKlage: false };
      posMap[key].gefordert = Math.max(posMap[key].gefordert, parseFloat(p.betrag_gefordert) || 0);
      posMap[key].reguliert = parseFloat(p.betrag_reguliert) || 0;
      posMap[key].kuerungenBetrag = positionKuerzungBetrag(p);
      if (p.fuer_klage_vorgemerkt) posMap[key].fuerKlage = true;
    });
  });

  // Schadenpositionen aus st.schaden als Forderungs-Basis (wenn noch keine Abrechnungen)
  const SCHADEN_POS_MAP = {
    rep_gutachten_netto:  "Reparaturkosten lt. Gutachten (netto)",
    rep_rechnung_netto:   "Reparaturkosten lt. Rechnung (netto)",
    rep_rechnung_brutto:  "Reparaturkosten lt. Rechnung (brutto)",
    reparaturkosten:      "Reparaturkosten",
    wiederbeschaffung:    "Wiederbeschaffungswert",
    restwert:             "Restwert (−)",
    wertminderung:        "Wertminderung",
    nutzungsausfall:      "Nutzungsausfallschaden",
    mietwagenkosten:      "Mietwagenkosten",
    sv_kosten:            "SV-/Gutachterkosten",
    abschleppkosten:      "Abschleppkosten",
    standkosten:          "Standkosten",
    anabmeldekosten:      "An-/Abmeldekosten",
    schmerzensgeld:       "Schmerzensgeld",
    verdienstausfall:     "Verdienstausfall",
    haushalt:             "Haushaltsführungsschaden",
    unkostenpauschale:    "Unkostenpauschale",
    sonstiges:            "Sonstiges",
  };
  const ABZUG_FELDER = new Set(["restwert"]);

  // Fahrzeug-Schlüssel je Abrechnungsart bestimmen (identische Logik wie positionenVorlage)
  const _art   = schaden?.abrechnungsart || null;
  const _pvRepN  = parseFloat(schaden?.rep_gutachten_netto || schaden?.reparaturkosten || 0);
  const _pvRepRN = parseFloat(schaden?.rep_rechnung_netto || 0);
  const _pvEffR  = _pvRepRN > 0 ? _pvRepRN : _pvRepN;
  const _wbw2  = parseFloat(schaden?.wiederbeschaffung || 0);
  const _rst2  = parseFloat(schaden?.restwert || 0);
  const _nFzg2 = _wbw2 - _rst2;
  const _i130  = _pvRepRN > 0 && _wbw2 > 0 && _pvRepRN > _nFzg2 && _pvRepRN <= 1.3 * _wbw2;

  // Welche Fahrzeug-Keys sollen in der Tabelle erscheinen?
  let _fahrzeugKeysSet;
  if (_art === "totalschaden" || (_art == null && _wbw2 > 0 && (_pvEffR === 0 || (!_i130 && _pvEffR > _nFzg2)))) {
    _fahrzeugKeysSet = new Set(["wiederbeschaffung", "restwert"]);
  } else if (_art === "konkret" || (_art == null && _pvRepRN > 0)) {
    _fahrzeugKeysSet = new Set(["rep_rechnung_netto"]);
  } else if (_art === "fiktiv" || (_art == null && _pvRepN > 0)) {
    _fahrzeugKeysSet = new Set(["rep_gutachten_netto"]);
  } else if (_wbw2 > 0) {
    _fahrzeugKeysSet = new Set(["wiederbeschaffung", "restwert"]);
  } else {
    _fahrzeugKeysSet = new Set(["rep_gutachten_netto"]); // Fallback
  }

  // Alle Fahrzeug-Keys die wir NICHT anzeigen wollen (unterdrücken)
  const _ALLE_FAHRZEUG_KEYS = new Set([
    "wiederbeschaffung","restwert","rep_gutachten_netto","rep_rechnung_netto",
    "rep_rechnung_brutto","reparaturkosten"
  ]);

  // Betrag für Fahrzeugschaden-Keys korrekt ermitteln
  const _getFahrzeugBetrag = (key) => {
    if (key === "rep_rechnung_netto")  return _pvRepRN;
    if (key === "rep_gutachten_netto") return _pvRepN;
    if (key === "wiederbeschaffung")   return _wbw2;
    if (key === "restwert")            return _rst2;
    return parseFloat(schaden?.[key]) || 0;
  };

  // Alle Positions-Keys: Fahrzeug-Keys gefiltert + alle anderen > 0 + posMap-Keys
  const _nichtFahrzeugKeys = Object.keys(SCHADEN_POS_MAP).filter(k =>
    !_ALLE_FAHRZEUG_KEYS.has(k) && (schaden[k] || 0) > 0
  );
  const _posMapNichtFahrzeug = Object.keys(posMap).filter(k => !_ALLE_FAHRZEUG_KEYS.has(k));

  const alleKeys = new Set([
    ...[..._fahrzeugKeysSet].filter(k => _getFahrzeugBetrag(k) > 0),
    ..._nichtFahrzeugKeys,
    ..._posMapNichtFahrzeug,
    // Aus posMap auch Fahrzeug-Keys übernehmen wenn reguliert (für Regulierungshistorie)
    ...Object.keys(posMap).filter(k => _fahrzeugKeysSet.has(k)),
  ]);

  const posTableRows = [...alleKeys].map(key => {
    const istAbzug  = ABZUG_FELDER.has(key);
    const betrag    = _ALLE_FAHRZEUG_KEYS.has(key)
      ? _getFahrzeugBetrag(key)
      : (parseFloat(schaden[key]) || posMap[key]?.gefordert || 0);
    const forderung = istAbzug ? -betrag : betrag;
    const reguliert = posMap[key]?.reguliert ?? null;
    const kuerzung  = reguliert != null ? Math.max(0, Math.abs(forderung) - (reguliert ?? 0)) : null;
    const label     = POSITION_LABELS_FE[key] || SCHADEN_POS_MAP[key] || key;
    const fuerKlage = posMap[key]?.fuerKlage || false;
    return { key, label, forderung, betrag, istAbzug, reguliert, kuerzung, fuerKlage };
  }).filter(r => r.betrag > 0 || (r.reguliert != null && r.reguliert > 0));

  // Extras aus schaden._extras ebenfalls anzeigen
  // Extras: aus _extras (Store) oder wdm_extras_json (nach DB-Reload)
  const _rawExtras = (() => {
    if (schaden._extras && schaden._extras.length > 0) return schaden._extras;
    if (schaden.wdm_extras_json) {
      try { const p = JSON.parse(schaden.wdm_extras_json); if (Array.isArray(p)) return p; } catch {}
    }
    return [];
  })();
  const extraRows = _rawExtras.filter(e => (e.betrag||0) > 0).map(e => ({
    key: `extra_${e.id}`, label: e.label || "Sonstiger Schaden",
    forderung: e.betrag, betrag: e.betrag, istAbzug: false,
    reguliert: null, kuerzung: null, fuerKlage: false,
  }));
  const alleRows = [...posTableRows, ...extraRows];

  const gesamtForderung = alleRows.reduce((s, r) => s + r.forderung, 0);
  const gesamtReguliert = alleRows.reduce((s, r) => s + (r.reguliert ?? 0), 0);
  const gesamtKuerzung  = alleRows.reduce((s, r) => s + (r.kuerzung ?? 0), 0);
  const klageSumme      = alleRows.filter(r => r.fuerKlage).reduce((s, r) => s + (r.kuerzung || 0), 0);
  const regGrad         = netto > 0 ? Math.min(100, Math.round(gesamtReguliert / netto * 100)) : 0;
  const hatRegulierung  = abrechnungen.length > 0;

  const InfoRow = ({ label, value }) => value ? (
    <div style={{ borderBottom:`1px solid ${T.borderSoft}`, padding:"6px 0", display:"flex", gap:12 }}>
      <span style={{ fontSize:"0.84rem", color:T.textFaint, width:110, flexShrink:0 }}>{label}</span>
      <span style={{ fontSize:"0.93rem", color:T.text }}>{value}</span>
    </div>
  ) : null;

  return (
    <>
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
      <div style={{ display:"flex", flexDirection:"column", gap:"1.25rem" }}>

        {/* ── RA-Micro Live-Daten (nur bei gültigem AZ-Format ZAHL/JJ) ── */}
        {(() => { const az = akte.az_roh || akte.az || ""; return az.includes("/") && az.length >= 4; })() && (
          <RaMicroAkteUebersicht azRoh={akte.az_roh || akte.az} />
        )}

        {/* ── Zeile 2: Status + Notizen (kompakt, halbe Höhe) ── */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"0.75rem" }}>
          <Card style={{ padding:"0.6rem 1rem" }}>
            <div style={{ fontSize:"0.75rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:6 }}>Akten-Status</div>
            <div style={{ display:"flex", gap:5, flexWrap:"wrap" }}>
              {["offen","in_regulierung","abgeschlossen","klage"].map(s => {
                const isA = (st.status||akte.status) === s, sm = STATUS_MAP[s];
                return <button key={s} onClick={async () => {
                  dispatch({ type:"SET_STATUS", akteId:akte.id, status:s });
                  setToast(`Status → ${sm.label}`);
                  try { await apiAkten.aktualisieren(akte.id, { status: s }); } catch {}
                }} style={{ padding:"3px 10px", borderRadius:20, border:`1.5px solid ${isA?sm.color:T.border}`, background:isA?sm.bg:"transparent", color:isA?sm.color:T.textMuted, fontSize:"0.82rem", fontWeight:isA?600:400, cursor:"pointer" }}>{sm.label}</button>;
              })}
            </div>
          </Card>
          <Card style={{ padding:"0.6rem 1rem", display:"flex", flexDirection:"column", gap:5 }}>
            <div style={{ fontSize:"0.75rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.08em" }}>Notizen</div>
            <textarea value={notizen} onChange={e => { setNotizen(e.target.value); setNC(true); }} rows={2}
              placeholder="Interne Notizen …"
              style={{ padding:"5px 8px", border:`1.5px solid ${T.border}`, borderRadius:6, fontSize:"0.875rem", color:T.text, background:T.surface, outline:"none", resize:"none" }}
              onFocus={e => e.target.style.borderColor=T.gold} onBlur={e => e.target.style.borderColor=T.border} />
            {nChanged && <Btn variant="gold" size="sm" onClick={async () => { dispatch({ type:"SET_NOTIZEN", akteId:akte.id, notizen }); setNC(false); setToast("Notizen gespeichert."); try { await apiAkten.aktualisieren(akte.id, { notizen }); } catch {} }}>{Ic.check} Speichern</Btn>}
          </Card>
        </div>

        {/* ── Zeile 3: Positions-Gegenüberstellung ── */}
        <Card style={{ background:"rgba(84,136,212,0.06)", border:"1px solid rgba(84,136,212,0.25)" }}>
          <CardHead title="Forderung vs. Regulierung – Positionsübersicht" />
          <div style={{ overflowX:"auto" }}>
            <table style={{ width:"100%", borderCollapse:"collapse", fontSize:"0.875rem" }}>
              <thead>
                <tr style={{ background:T.surface }}>
                  {["Position","Forderung","Reguliert","Kürzung","Klage","Status"].map((h,i) => (
                    <th key={h} style={{ padding:"9px 12px", textAlign:i===0?"left":"right", fontSize:"0.77rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.06em", whiteSpace:"nowrap" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {alleRows.length === 0 ? (
                  <tr><td colSpan={6} style={{ padding:"2rem", textAlign:"center", color:T.textFaint }}>
                    Noch keine Schadenpositionen oder Abrechnungen erfasst.
                  </td></tr>
                ) : alleRows.map(r => {
                  const hatKuerzung = r.kuerzung != null && r.kuerzung > 0.005;
                  const vollReg     = r.reguliert != null && r.kuerzung != null && r.kuerzung <= 0.005;
                  const nochOffen   = r.reguliert == null;
                  return (
                    <tr key={r.key} style={{ borderTop:`1px solid ${T.border}`, background:r.fuerKlage ? "#2a1a001a" : "transparent" }}>
                      <td style={{ padding:"9px 12px", color: r.istAbzug ? T.red : T.text, fontWeight:500 }}>
                        {r.label}
                        {r.fuerKlage && <span style={{ marginLeft:6, fontSize:11, background:T.amberBg, color:T.amber, borderRadius:3, padding:"1px 5px", fontWeight:600 }}>KLAGE</span>}
                      </td>
                      <td style={{ padding:"9px 12px", textAlign:"right", fontFamily:"monospace", color: r.istAbzug ? T.red : T.text, fontWeight: r.istAbzug ? 600 : 400 }}>
                        {r.istAbzug ? `−${fmtEuro(r.betrag)}` : fmtEuro(r.forderung)}
                      </td>
                      <td style={{ padding:"9px 12px", textAlign:"right", fontFamily:"monospace", color:nochOffen ? T.textFaint : vollReg ? T.green : T.amber }}>
                        {nochOffen ? "—" : fmtEuro(r.reguliert)}
                      </td>
                      <td style={{ padding:"9px 12px", textAlign:"right", fontFamily:"monospace", fontWeight:hatKuerzung?700:400, color:hatKuerzung ? T.red : T.textFaint }}>
                        {hatKuerzung ? `−${fmtEuro(r.kuerzung)}` : nochOffen ? "—" : "—"}
                      </td>
                      <td style={{ padding:"9px 12px", textAlign:"right", fontFamily:"monospace", color:r.fuerKlage ? T.red : T.textFaint }}>
                        {r.fuerKlage && hatKuerzung ? fmtEuro(r.kuerzung) : "—"}
                      </td>
                      <td style={{ padding:"9px 12px", textAlign:"right" }}>
                        {nochOffen
                          ? <span style={{ fontSize:11, padding:"2px 7px", borderRadius:20, background:T.surface, color:T.textMuted, border:`1px solid ${T.border}` }}>offen</span>
                          : vollReg
                            ? <span style={{ fontSize:11, padding:"2px 7px", borderRadius:20, background:T.greenBg, color:T.green }}>✓ voll</span>
                            : <span style={{ fontSize:11, padding:"2px 7px", borderRadius:20, background:T.redBg, color:T.red }}>gekürzt</span>
                        }
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              {alleRows.length > 0 && (
                <tfoot>
                  <tr style={{ borderTop:`2px solid ${T.border}`, background:T.surface }}>
                    <td style={{ padding:"10px 12px", fontWeight:700, color:T.navy }}>Gesamt</td>
                    <td style={{ padding:"10px 12px", textAlign:"right", fontFamily:"monospace", fontWeight:700, color:T.navy }}>{fmtEuro(gesamtForderung)}</td>
                    <td style={{ padding:"10px 12px", textAlign:"right", fontFamily:"monospace", fontWeight:700, color:T.green }}>{hatRegulierung ? fmtEuro(gesamtReguliert) : "—"}</td>
                    <td style={{ padding:"10px 12px", textAlign:"right", fontFamily:"monospace", fontWeight:700, color:gesamtKuerzung > 0 ? T.red : T.textFaint }}>
                      {gesamtKuerzung > 0 ? `−${fmtEuro(gesamtKuerzung)}` : "—"}
                    </td>
                    <td style={{ padding:"10px 12px", textAlign:"right", fontFamily:"monospace", fontWeight:700, color:klageSumme > 0 ? T.red : T.textFaint }}>
                      {klageSumme > 0 ? fmtEuro(klageSumme) : "—"}
                    </td>
                    <td style={{ padding:"10px 12px", textAlign:"right" }}>
                      <span style={{ fontSize:12, fontWeight:700, color:regGrad>=100?T.green:T.navy }}>{regGrad} %</span>
                    </td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
          {/* Regulierungsgrad-Balken */}
          {hatRegulierung && (
            <div style={{ padding:"0.75rem 1.4rem 1rem" }}>
              <div style={{ height:8, background:T.border, borderRadius:4, overflow:"hidden" }}>
                <div style={{ height:"100%", width:`${regGrad}%`, background:regGrad>=100?`linear-gradient(90deg,${T.green},#34d399)`:`linear-gradient(90deg,${T.gold},${T.goldLight})`, borderRadius:4, transition:"width 0.8s" }} />
              </div>
              <div style={{ display:"flex", justifyContent:"space-between", marginTop:5, fontSize:"0.84rem", color:T.textMuted }}>
                <span>{regGrad} % reguliert · {abrechnungen.length} Schreiben</span>
                {klageSumme > 0 && <span style={{ color:T.red, fontWeight:600 }}>Klagepotential: {fmtEuro(klageSumme)}</span>}
              </div>
            </div>
          )}
        </Card>

        {/* ── Zeile 4: Forderungshistorie ── */}
        <ForderungshistorieKarte akteId={akte.id} />

        {/* ── Zeile 5: Kombinierte Verlaufs-Timeline ── */}
        <AktenTimeline
          abrechnungen={abrechnungen}
          aktivitaeten={st.aktivitaeten || []}
          akteId={akte.id}
          onAktivitaetenChange={async () => {
            const data = await apiAkten.aktivitaeten(akte.id);
            if (data?.aktivitaeten)
              dispatch({ type:"SET_AKTIVITAETEN", akteId: akte.id, aktivitaeten: data.aktivitaeten });
          }}
        />
      </div>
    </>
  );
}
const ROLLEN = [
  {value:"mandant",           label:"Mandant"},
  {value:"gegner",            label:"Gegner"},
  {value:"gericht",           label:"Gericht"},
  {value:"polizei",           label:"Polizei"},
  {value:"staatsanwaltschaft",label:"Staatsanwaltschaft"},
  {value:"sachverstaendiger", label:"Sachverständiger"},
  {value:"sonstiger",         label:"Sonstige Beteiligte"},
];
const ROLLEN_MIT_AZ = new Set(["gericht","polizei","staatsanwaltschaft"]);
const ROLLEN_C = {
  mandant:           {c:T.blue,   bg:T.blueBg},
  gegner:            {c:T.red,    bg:T.redBg},
  gericht:           {c:"#7c3aed",bg:"#ede9fe"},
  polizei:           {c:"#0369a1",bg:"#e0f2fe"},
  staatsanwaltschaft:{c:"#b45309",bg:"#fef3c7"},
  sachverstaendiger: {c:T.green,  bg:T.greenBg},
  sonstiger:         {c:T.textMuted,bg:T.surface},
};

function BeteiligteSection({ beteiligte, dispatch, akteId }) {
  const [panelOpen, setPOpen] = useState(false);
  const [editItem, setEdit]   = useState(null);
  const [form, setForm]       = useState({});
  const [toast, setToast]     = useState("");

  const empty = { rolle:"mandant", name:"", vorname:"", firma:"", email:"", telefon:"", anschrift:"", plz:"", ort:"", kfz:"", kfz_typ:"", versicherung:"", vers_nr:"", schaden_nr:"", iban:"", aktenzeichen:"", notizen:"" };
  const F = (k, l, t="text", ph="") => <FieldInput label={l} value={form[k]||""} onChange={v => setForm(p => ({...p,[k]:v}))} type={t} placeholder={ph} />;

  const [betSaving, setBetSaving] = useState(false);

  const save = async () => {
    if (!form.name) { alert("Name ist Pflichtfeld."); return; }
    setBetSaving(true);
    const betData = { ...form, id: editItem?.id || Date.now() };
    try {
      if (editItem?.id && typeof editItem.id === "number" && editItem.id < 1e12) {
        // Echter DB-Record → PATCH
        await apiBeteiligte.aktualisieren(akteId, editItem.id, form);
      } else {
        // Neuer Beteiligter → POST
        const created = await apiBeteiligte.erstellen(akteId, form);
        if (created?.id) betData.id = created.id;
      }
    } catch { /* Demo-Modus */ }
    dispatch({ type:"SAVE_BETEILIGTER", akteId, beteiligter: betData });
    setBetSaving(false);
    setPOpen(false);
    setToast(editItem ? "Beteiligter gespeichert." : "Beteiligter hinzugefügt.");
  };

  return (
    <>
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
      <Card>
        <CardHead title={`Beteiligte (${beteiligte.length})`} action={<Btn size="sm" onClick={() => { setEdit(null); setForm(empty); setPOpen(true); }}>{Ic.plus} Hinzufügen</Btn>} />
        {beteiligte.length === 0 ? (
          <div style={{ padding:"2rem", textAlign:"center", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.975rem", color:T.textFaint }}>Noch keine Beteiligten erfasst.</div>
        ) : (
          <div style={{ overflowX:"auto" }}>
            <table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead><tr style={{ background:T.surface }}>{["Rolle","Name / Firma","Kontakt","KFZ","Versicherung",""].map(h => <th key={h} style={{ padding:"8px 14px", textAlign:"left", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.815rem", fontWeight:600, color:T.textMuted, letterSpacing:"0.06em", textTransform:"uppercase", borderBottom:`1px solid ${T.border}` }}>{h}</th>)}</tr></thead>
              <tbody>
                {beteiligte.map((b, i) => {
                  const rc = ROLLEN_C[b.rolle] || ROLLEN_C.sonstiger;
                  return (
                    <tr key={b.id} style={{ borderBottom:`1px solid ${T.borderSoft}`, background:i%2===0?T.white:T.surface }}>
                      <td style={{ padding:"10px 14px" }}>
                        <span style={{ display:"inline-flex", alignItems:"center", gap:4, background:rc.bg, color:rc.c, border:`1px solid ${rc.c}33`, borderRadius:12, padding:"2px 8px", fontSize:"0.825rem", fontWeight:600 }}>
                          {ROLLEN.find(r => r.value===b.rolle)?.label || b.rolle}
                        </span>
                      </td>
                      <td style={{ padding:"10px 14px" }}>
                        <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.975rem", fontWeight:600, color:T.navy }}>{b.name}{b.vorname ? ` ${b.vorname}` : ""}</div>
                        {b.firma && <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:T.textMuted }}>{b.firma}</div>}
                        {(b.anschrift||b.ort) && <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.825rem", color:T.textFaint }}>{b.anschrift}{b.plz?` · ${b.plz}`:""}{b.ort?` ${b.ort}`:""}</div>}
                      </td>
                      <td style={{ padding:"10px 14px" }}>
                        {b.email && <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.925rem", color:T.textMid }}>{b.email}</div>}
                        {b.telefon && <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.895rem", color:T.textFaint }}>{b.telefon}</div>}
                      </td>
                      <td style={{ padding:"10px 14px" }}>
                        {b.kfz && <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.945rem", fontWeight:600, color:T.text }}>{b.kfz}</div>}
                        {b.kfz_typ && <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.865rem", color:T.textFaint }}>{b.kfz_typ}</div>}
                      </td>
                      <td style={{ padding:"10px 14px" }}>
                        {b.versicherung && <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.945rem", color:T.textMid }}>{b.versicherung}</div>}
                        {b.vers_nr && <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.845rem", color:T.textFaint }}>{b.vers_nr}</div>}
                        {b.schaden_nr && <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.845rem", color:T.textFaint }}>SN: {b.schaden_nr}</div>}
                      </td>
                      <td style={{ padding:"10px 14px" }}>
                        <div style={{ display:"flex", gap:4 }}>
                          <Btn size="sm" variant="secondary" onClick={() => { setEdit(b); setForm({...b}); setPOpen(true); }}>{Ic.edit}</Btn>
                          <Btn size="sm" variant="danger"    onClick={async () => { if (confirm("Beteiligten entfernen?")) {
                          try { await apiBeteiligte.loeschen(akteId, b.id); } catch { /* Demo */ }
                          dispatch({ type:"DELETE_BETEILIGTER", akteId, id:b.id });
                        }; }}>{Ic.trash}</Btn>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <SlidePanel open={panelOpen} onClose={() => setPOpen(false)} title={editItem ? "Beteiligten bearbeiten" : "Beteiligten hinzufügen"}>
        <div style={{ display:"flex", flexDirection:"column", gap:13 }}>
          <FieldSelect label="Rolle" value={form.rolle||"mandant"} onChange={v => setForm(p => ({...p,rolle:v}))} options={ROLLEN} />
          {ROLLEN_MIT_AZ.has(form.rolle) && (
            <div style={{ background:T.surface, border:`1.5px solid ${T.border}`, borderRadius:8, padding:"10px 12px", display:"flex", flexDirection:"column", gap:4 }}>
              {F("aktenzeichen","Aktenzeichen",undefined,"z.B. 123 Js 456/25")}
            </div>
          )}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>{F("name","Nachname *")} {F("vorname","Vorname")}</div>
          {F("firma","Firma / Organisation")}
          <hr style={{ border:"none", borderTop:`1px solid ${T.border}`, margin:"2px 0" }} />
          {F("anschrift","Anschrift")}
          <div style={{ display:"grid", gridTemplateColumns:"90px 1fr", gap:10 }}>{F("plz","PLZ")} {F("ort","Ort")}</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>{F("email","E-Mail","email")} {F("telefon","Telefon","tel")}</div>
          <hr style={{ border:"none", borderTop:`1px solid ${T.border}`, margin:"2px 0" }} />
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>{F("kfz","KFZ-Kennzeichen",undefined,"OF-AB 123")} {F("kfz_typ","Fahrzeugtyp",undefined,"VW Passat")}</div>
          {F("versicherung","Versicherung")}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>{F("vers_nr","Vers.-Nr.")} {F("schaden_nr","Schaden-Nr.")}</div>
          {F("iban","IBAN")}
          <hr style={{ border:"none", borderTop:`1px solid ${T.border}`, margin:"2px 0" }} />
          <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
            <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600, color:T.textMid, letterSpacing:"0.05em", textTransform:"uppercase" }}>Notizen</label>
            <textarea value={form.notizen||""} onChange={e => setForm(p => ({...p,notizen:e.target.value}))} rows={3} style={{ padding:"8px 10px", border:`1.5px solid ${T.border}`, borderRadius:7, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.975rem", color:T.text, background:T.surface, outline:"none", resize:"vertical" }} onFocus={e => e.target.style.borderColor=T.gold} onBlur={e => e.target.style.borderColor=T.border} />
          </div>
          <div style={{ display:"flex", gap:8, paddingTop:4 }}>
            <Btn variant="primary" onClick={save} disabled={betSaving} style={{ flex:1 }}>
              {betSaving ? <><div style={{ width:12, height:12, border:"2px solid rgba(255,255,255,0.3)", borderTopColor:"white", borderRadius:"50%", animation:"spin 0.7s linear infinite" }}/> Speichern …</> : <>{Ic.check} Speichern</>}
            </Btn>
            <Btn variant="secondary" onClick={() => setPOpen(false)}>Abbrechen</Btn>
          </div>
        </div>
      </SlidePanel>
    </>
  );
}

/* ══════════════════════════════════════════════════════════════
   SECTION: SCHADEN
══════════════════════════════════════════════════════════════ */
const SCHADEN_F = [
  {k:"rep_gutachten_netto",  l:"Reparaturkosten lt. Gutachten (netto)",   hint:"fiktiv, laut SV"},
  {k:"rep_rechnung_brutto",  l:"Reparaturkosten lt. Rechnung (brutto)",   hint:"konkret, inkl. MwSt"},
  {k:"wiederbeschaffung",    l:"Wiederbeschaffungswert (WBW)"},
  {k:"restwert",             l:"Restwert",                                abzug:true},
  {k:"wertminderung",        l:"Merkantile Wertminderung"},
  {k:"nutzungsausfall",      l:"Nutzungsausfallschaden"},
  {k:"mietwagenkosten",      l:"Mietwagenkosten (brutto)"},
  {k:"sv_kosten",            l:"SV-/Gutachterkosten (brutto)"},
  {k:"abschleppkosten",      l:"Abschleppkosten (brutto)"},
  {k:"standkosten",          l:"Standkosten (brutto)"},
  {k:"anabmeldekosten",      l:"An-/Abmeldekosten (brutto)"},
  {k:"schmerzensgeld",       l:"Schmerzensgeldvorschuss"},
  {k:"verdienstausfall",     l:"Verdienstausfall"},
  {k:"haushalt",             l:"Haushaltsführungsschaden"},
  {k:"unkostenpauschale",    l:"Unkostenpauschale (30 €)"},
  {k:"sonstiges",            l:"Sonstiges"},
];

/**
 * Ermittelt die Abrechnungsart automatisch aus den Schadendaten.
 * @param {object} schaden  - Schaden-State (form oder gespeicherter Schaden)
 * @param {boolean} vorsteuer - true wenn Mandant vorsteuerabzugsberechtigt
 * @returns {{ art: string, begruendung: string } | null}
 */
// ── Personenschaden API ────────────────────────────────────────────────────
const apiPS = {
  laden:   (az) => request(`/akten/${az}/personenschaden`),
  speichern: (az, daten) => request(`/akten/${az}/personenschaden`,
    {method:"PUT", body:JSON.stringify(daten)}),
  beteiligteLaden: (az) => request(`/akten/${az}/personenschaden/beteiligte`),
  beteiligterSpeichern: (az, daten) => request(`/akten/${az}/personenschaden/beteiligte`,
    {method:"POST", body:JSON.stringify(daten)}),
  beteiligterLoeschen: (az, id) => request(`/akten/${az}/personenschaden/beteiligte/${id}`,
    {method:"DELETE"}),
  beteiligterAktualisieren: (az, id, daten) => request(`/akten/${az}/personenschaden/beteiligte/${id}`,
    {method:"PATCH", body:JSON.stringify(daten)}),
  wdmLaden: (az) => request(`/akten/${az}/personenschaden/wdm`),
  adressSuche: (q) => request(`/ramicro/akte/adressen/suche?q=${encodeURIComponent(q)}&limit=10`),
};

const ROLLEN_LABEL = {
  arzt:"Behandelnder Arzt", krankenhaus:"Krankenhaus",
  physiotherapeut:"Physiotherapeut", arbeitgeber:"Arbeitgeber",
  krankenkasse:"Krankenkasse", bg:"Berufsgenossenschaft",
};
const ROLLEN_ICON = {
  arzt:"🩺", krankenhaus:"🏥", physiotherapeut:"🧘",
  arbeitgeber:"🏢", krankenkasse:"💊", bg:"🏭",
};

function ermittleAbrechnungsart(schaden, vorsteuer = false) {
  const g = k => parseFloat(schaden?.[k]) || 0;
  const repGutNetto  = g("rep_gutachten_netto") || g("reparaturkosten");
  const repRechNetto = g("rep_rechnung_netto");
  const repRechBrutto= g("rep_rechnung_brutto");
  const wbw          = g("wiederbeschaffung");
  const rst          = g("restwert");
  const nFzg         = wbw - rst;

  const hatGutachten = repGutNetto  > 0;
  const hatRechnung  = repRechNetto > 0;
  const hatWbw       = wbw > 0;

  // ── Fall 1: Rechnung + Gutachten vorhanden ────────────────────────────
  if (hatRechnung && hatGutachten) {
    // Vergleichswert auf Rechnungsseite je nach Vorsteuer
    const rechnungsVergleich = vorsteuer ? repRechNetto : repRechBrutto || (repRechNetto * 1.19);
    if (repGutNetto > rechnungsVergleich) {
      return {
        art: "fiktiv",
        begruendung: vorsteuer
          ? `Gutachten (${fmtEuroHlp(repGutNetto)} netto) > Rechnung netto (${fmtEuroHlp(repRechNetto)}) → fiktive Abrechnung (VSt.-berechtigt)`
          : `Gutachten (${fmtEuroHlp(repGutNetto)} netto) > Rechnung brutto (${fmtEuroHlp(rechnungsVergleich)}) → fiktive Abrechnung`
      };
    }
    return {
      art: "konkret",
      begruendung: `Rechnung (${fmtEuroHlp(vorsteuer ? repRechNetto : rechnungsVergleich)}) günstiger als Gutachten → konkrete Abrechnung`
    };
  }

  // ── Fall 2: Nur Rechnung ──────────────────────────────────────────────
  if (hatRechnung && !hatGutachten) {
    if (!hatWbw) {
      return { art: "konkret", begruendung: `Reparaturrechnung vorhanden (${fmtEuroHlp(repRechNetto)} netto), kein WBW → konkrete Abrechnung` };
    }
    if (repRechNetto > 1.3 * wbw) {
      return { art: "totalschaden", begruendung: `Rechnung (${fmtEuroHlp(repRechNetto)}) > 130% WBW (${fmtEuroHlp(1.3*wbw)}) → wirtschaftlicher Totalschaden` };
    }
    if (repRechNetto > nFzg) {
      return { art: "konkret", begruendung: `Rechnung (${fmtEuroHlp(repRechNetto)}) > WBW−Restwert (${fmtEuroHlp(nFzg)}) aber ≤ 130% → konkrete Abrechnung (130%-Fall)` };
    }
    return { art: "konkret", begruendung: `Reparaturrechnung (${fmtEuroHlp(repRechNetto)} netto) ≤ WBW−Restwert → konkrete Abrechnung` };
  }

  // ── Fall 3: Nur Gutachten ─────────────────────────────────────────────
  if (hatGutachten && !hatRechnung) {
    if (!hatWbw) {
      return { art: "fiktiv", begruendung: `Nur Gutachten vorhanden (${fmtEuroHlp(repGutNetto)} netto), kein WBW → fiktive Abrechnung` };
    }
    if (repGutNetto > nFzg) {
      return { art: "totalschaden", begruendung: `Gutachten (${fmtEuroHlp(repGutNetto)}) > WBW−Restwert (${fmtEuroHlp(nFzg)}) → Totalschaden` };
    }
    return { art: "fiktiv", begruendung: `Gutachten (${fmtEuroHlp(repGutNetto)} netto) ≤ WBW−Restwert → fiktive Abrechnung` };
  }

  // ── Fall 4: Nur WBW, keine Reparaturkosten ───────────────────────────
  if (hatWbw && !hatGutachten && !hatRechnung) {
    return { art: "totalschaden", begruendung: `Nur WBW (${fmtEuroHlp(wbw)}) ohne Reparaturkosten → Totalschaden` };
  }

  return null; // Nicht genug Daten
}

function fmtEuroHlp(v) {
  return new Intl.NumberFormat("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(v || 0) + " €";
}

function SchadenSection({ schaden, hq, dispatch, akteId, vorsteuer = false }) {
  const [form, setForm]         = useState({ ...schaden });
  const [schadenTab, setSchadenTab] = useState("sachschaden");

  // Personenschaden-State
  const [psForm, setPsForm]   = useState({});
  const [psChg, setPsChg]     = useState(false);
  const [psSaving, setPsSave] = useState(false);
  const [psToast, setPsToast] = useState("");

  // Personenschaden laden
  React.useEffect(() => {
    if (!akteId) return;
    apiPS.laden(akteId)
      .then(d => { if (d?.personenschaden) setPsForm(d.personenschaden); })
      .catch(() => {});
  }, [akteId]);

  const savePsForm = async () => {
    setPsSave(true);
    try {
      await apiPS.speichern(akteId, psForm);
      setPsToast("✓ Personenschaden gespeichert."); setPsChg(false);
    } catch(e) {
      setPsToast("⚠ Speichern fehlgeschlagen.");
    } finally { setPsSave(false); }
  };
  const psUpd = (k, v) => { setPsForm(p => ({...p, [k]: v})); setPsChg(true); };

  // formInitialisiert: verhindert dass nach Speichern der Store die form überschreibt
  const [formInitialisiert, setFormInitialisiert] = useState(false);

  // Wenn die Schaden-Prop nachgeladen wird (nach DB-Fetch), form aktualisieren
  // Aber NUR wenn noch nicht initialisiert (= erste Ladung oder Akte wechsel)
  useEffect(() => {
    if (formInitialisiert) return; // Bereits initialisiert → nicht überschreiben
    if (schaden && Object.keys(schaden).some(k => (schaden[k] || 0) > 0)) {
      setForm({ ...schaden });
      setFormInitialisiert(true);
      // Vorschlag berechnen wenn abrechnungsart noch nicht gesetzt
      if (!schaden.abrechnungsart) setArtVorschlag(ermittleAbrechnungsart(schaden, vorsteuer));
      // _extras aus _extras (Store nach WDM-Übernahme) oder wdm_extras_json (nach DB-Reload)
      if (schaden._extras && schaden._extras.length > 0) {
        setExtras(schaden._extras);
      } else if (schaden.wdm_extras_json) {
        try {
          const p = JSON.parse(schaden.wdm_extras_json);
          if (Array.isArray(p) && p.length > 0) setExtras(p);
        } catch {}
      }
    }
  }, [schaden, formInitialisiert]); // eslint-disable-line react-hooks/exhaustive-deps

  // Bei Akte-Wechsel: Initialisierung zurücksetzen
  useEffect(() => {
    setFormInitialisiert(false);
    setChg(false);
  }, [akteId]); // eslint-disable-line react-hooks/exhaustive-deps
  const [changed, setChg]       = useState(false);
  const [saving, setSaving]     = useState(false);
  const [toast, setToast]       = useState("");
  // _extras: entweder direkt (nach WDM-Übernahme im Store) oder aus wdm_extras_json parsen
  const _initExtras = (() => {
    if (schaden._extras && schaden._extras.length > 0) return schaden._extras;
    if (schaden.wdm_extras_json) {
      try { const p = JSON.parse(schaden.wdm_extras_json); if (Array.isArray(p)) return p; } catch {}
    }
    return [];
  })();
  const [extras, setExtras]     = useState(_initExtras);
  const [showAdd, setShowAdd]   = useState(false);
  const [newLabel, setNewLabel] = useState("");
  const [newBetrag, setNewBetrag] = useState("");
  const [newMwst, setNewMwst]   = useState("");

  // ── WDM-Discovery ────────────────────────────────────────────────────────
  const [wdmLaden, setWdmLaden]         = useState(false);
  const [wdmSchadenDaten, setWdmSchaden]= useState(null);
  const [autoWdmGesucht, setAutoWdmGesucht] = useState(false);
  // true wenn User explizit "WDM neu laden" geklickt hat → Panel immer anzeigen
  const [wdmExplizit, setWdmExplizit]   = useState(false);
  // Automatisch erkannte Abrechnungsart (Vorschlag)
  const [artVorschlag, setArtVorschlag] = useState(null);

  // Prüfen ob lokale DB Schadendaten hat
  const hatLokaleWerte = React.useMemo(() => {
    const felder = ["rep_gutachten_netto","rep_rechnung_brutto","wiederbeschaffung",
                    "wertminderung","nutzungsausfall","mietwagenkosten","sv_kosten",
                    "mietwagenkosten_netto","sv_kosten_netto","abschleppkosten_netto",
                    "standkosten_netto","anabmeldekosten_netto",
                    "schmerzensgeld","abschleppkosten","standkosten","anabmeldekosten",
                    "verdienstausfall","haushalt","unkostenpauschale","sonstiges"];
    return felder.some(k => (schaden[k] || 0) > 0) || (schaden._extras?.length > 0);
  }, [schaden]);

  // Auto-Load: Wenn keine lokalen Daten → WDM automatisch abfragen
  React.useEffect(() => {
    if (autoWdmGesucht) return;
    if (hatLokaleWerte) return;
    if (!akteId || !akteId.includes("/")) return;
    setAutoWdmGesucht(true);
    setWdmLaden(true);
    ramicroWdm.schaden(akteId)
      .then(schdn => {
        setWdmSchaden(schdn);
        if ((schdn?.felder_gefunden || 0) > 0 || (schdn?.extras_gefunden || 0) > 0) {
          
        }
      }).catch(() => {})
      .finally(() => setWdmLaden(false));
  }, [akteId, hatLokaleWerte, autoWdmGesucht]);


  const uebernehmeWdmSchaden = async () => {
    if (!wdmSchadenDaten?.schaden) return;
    const neu = { ...form };
    // Alle Schaden-Felder übernehmen (inkl. neuer netto/ust-Felder aus Migration 14)
    Object.entries(wdmSchadenDaten.schaden).forEach(([k, v]) => {
      if (v > 0) neu[k] = v;
    });
    neu.quelle = "wdm_ramicro";

    // Extras (sonstige Schäden 1-6) mit netto/mwst/brutto übernehmen
    const wdmExtras = (wdmSchadenDaten.extras || []).filter(e => (e.betrag||0) > 0);
    const mergedExtras = wdmExtras.length > 0
      ? [...extras.filter(e => !String(e.id).startsWith("wdm_ss")), ...wdmExtras]
      : extras;

    if (wdmExtras.length > 0) {
      setExtras(mergedExtras);
      neu._extras = mergedExtras;
    }

    // Abrechnungsart-Vorschlag aus WDM-Daten berechnen
    const wdmArtVorschlag = ermittleAbrechnungsart(neu, vorsteuer);
    if (wdmArtVorschlag && !neu.abrechnungsart) {
      neu.abrechnungsart = wdmArtVorschlag.art;
    }
    setArtVorschlag(wdmArtVorschlag);
    setForm(neu);
    setFormInitialisiert(true); // WDM-Daten sind jetzt die Basis → nicht durch Store überschreiben
    setChg(false);
    setWdmExplizit(false); // Panel nach Übernahme schließen

    // Direkt in SQLite speichern — nicht auf manuelles Speichern warten
    setSaving(true);
    const schadenBrutto = calcBrutto(neu, mergedExtras);

    const schadenData = { ...neu, gesamt_brutto: schadenBrutto, _extras: mergedExtras };
    try {
      const res = await apiSchaden.speichern(akteId, schadenData);
      const serverSchaden = res?.schaden || schadenData;
      dispatch({ type:"SAVE_SCHADEN", akteId, schaden: { ...schadenData, gesamt_brutto: serverSchaden.gesamt_brutto ?? schadenBrutto } });
      const n = Object.values(wdmSchadenDaten.schaden).filter(v => v > 0).length;
      const x = wdmExtras.length;
      setToast(`✓ ${n} Schadenpositionen${x>0?` + ${x} sonstige Schäden`:""} aus RA-Micro übernommen und gespeichert.`);
    } catch(err) {
      const msg = err?.message || String(err);
      dispatch({ type:"SAVE_SCHADEN", akteId, schaden: schadenData });
      setToast(`⚠ Speichern fehlgeschlagen: ${msg.slice(0,120)}`);
    } finally {
      setSaving(false);
    }
  };

  const upd = (k, v) => {
    setForm(p => {
      const neu = {...p, [k]: typeof v === "number" ? v : (parseFloat(v)||0)};
      // Vorschlag sofort neu berechnen wenn relevantes Feld geändert
      const relevant = ["rep_gutachten_netto","rep_rechnung_netto","rep_rechnung_brutto",
                        "reparaturkosten","wiederbeschaffung","restwert"];
      if (relevant.includes(k)) setArtVorschlag(ermittleAbrechnungsart(neu, vorsteuer));
      return neu;
    });
    setChg(true);
  };

  // Schadensumme — einheitliche Fahrzeugschaden-Logik
  const calcBrutto = (f, ex) => {
    const g   = k => parseFloat(f[k]) || 0;
    const repN  = g("rep_gutachten_netto") || g("reparaturkosten");
    const repRN = g("rep_rechnung_netto");
    // Konkrete Abrechnung: Rechnung hat immer Vorrang (unabh. ob höher/niedriger)
    const effRep = repRN > 0 ? repRN : repN;
    const wbw  = g("wiederbeschaffung");
    const rst  = g("restwert");
    const nettoFzg  = wbw - rst;
    // 130%-Fall: Rechnung > WBW−Restwert aber ≤ 130% WBW → Reparatur, kein Totalschaden
    const ist130Fall = repRN > 0 && wbw > 0 && repRN > nettoFzg && repRN <= 1.3 * wbw;
    const fahrzeug  = wbw > 0
      ? (ist130Fall || (effRep > 0 && effRep <= nettoFzg) ? effRep : nettoFzg)
      : effRep;
    return fahrzeug
      + g("wertminderung") + g("nutzungsausfall") + g("mietwagenkosten")
      + g("sv_kosten") + g("abschleppkosten") + g("standkosten")
      + g("anabmeldekosten") + g("schmerzensgeld") + g("sonstiges")
      + g("verdienstausfall") + g("haushalt") + g("unkostenpauschale")
      + g("kostennb") + g("kostennb_ust")
      + (ex || []).reduce((s, e) => s + (parseFloat(e.betrag) || 0), 0);
  };

  const brutto = calcBrutto(form, extras);
  const netto  = brutto * (hq / 100);

  const save = async () => {
    setSaving(true);
    // Abrechnungsart automatisch setzen wenn noch leer
    const autoArt = !form.abrechnungsart ? ermittleAbrechnungsart(form, vorsteuer) : null;
    const schadenData = {
      ...form,
      gesamt_brutto: brutto,
      _extras: extras,
      ...(autoArt ? { abrechnungsart: autoArt.art } : {}),
    };
    if (autoArt) { setForm(p => ({...p, abrechnungsart: autoArt.art})); setArtVorschlag(autoArt); }
    try {
      const res = await apiSchaden.speichern(akteId, schadenData);
      // Backend liefert korrektes gesamt_brutto zurück — diesen Wert nutzen
      const serverSchaden = res?.schaden || schadenData;
      dispatch({ type:"SAVE_SCHADEN", akteId, schaden: { ...schadenData, gesamt_brutto: serverSchaden.gesamt_brutto ?? brutto } });
      setSaving(false); setChg(false); setToast("✓ Schaden gespeichert.");
    } catch(err) {
      const msg = err?.message || String(err);
      setSaving(false);
      setToast(`⚠ Speichern fehlgeschlagen: ${msg.slice(0,120)}`);
    }
  };

  const quelleLabels = { manuell:"Manuell", gutachten_pdf:"Gutachten (PDF)", abrechnung_pdf:"Abrechnung (PDF)", korrektur:"Korrektur", wdm_ramicro:"RA-Micro (WDM)" };
  const quelleColors = { manuell:{c:T.textMuted,bg:T.surface}, gutachten_pdf:{c:T.blue,bg:T.blueBg}, abrechnung_pdf:{c:T.green,bg:T.greenBg}, korrektur:{c:T.amber,bg:T.amberBg}, wdm_ramicro:{c:"#6b21a8",bg:"#f5f3ff"} };
  const qc = quelleColors[form.quelle] || quelleColors.manuell;

  // Gutachten-PDF-Import
  const [showGutImport, setShowGutImport] = useState(false);
  const [gutFile, setGutFile]     = useState(null);
  const [gutLoading, setGutLoad]  = useState(false);
  const [gutErgebnis, setGutErg]  = useState(null);
  const [gutError, setGutError]   = useState("");

  const handleGutDatei = async (file) => {
    if (!file) return;
    setGutFile(file);
    setGutLoad(true);
    setGutError("");
    setGutErg(null);
    try {
      const res = await apiParsePdf.parse(akteId, file);
      if (res?.ergebnis?.dokumenttyp === "gutachten") {
        setGutErg(res.ergebnis);
        // Chronik sofort aktualisieren – Backend hat bereits logge_aktivitaet geschrieben
        try {
          const aktData = await apiAkten.aktivitaeten(akteId);
          if (aktData?.aktivitaeten) {
            dispatch({ type: "SET_AKTIVITAETEN", akteId, aktivitaeten: aktData.aktivitaeten });
          }
        } catch { /* Chronik-Refresh nicht kritisch */ }
      } else if (res?.ergebnis) {
        setGutError(`Dokument wurde als „${res.ergebnis.dokumenttyp}" erkannt, nicht als Gutachten. Bitte richtiges Dokument wählen.`);
      } else {
        setGutError("Dokument konnte nicht verarbeitet werden.");
      }
    } catch(e) {
      setGutError("Fehler beim Parsen: " + (e?.message || String(e)));
    } finally {
      setGutLoad(false);
    }
  };

  const handleGutachtenUebernehmen = () => {
    if (!gutErgebnis?.schadenpositionen) return;
    const pos = gutErgebnis.schadenpositionen;
    const updates = {};
    if (pos.reparaturkosten)   updates.reparaturkosten   = pos.reparaturkosten;
    if (pos.wiederbeschaffung) updates.wiederbeschaffung = pos.wiederbeschaffung;
    if (pos.restwert)          updates.restwert          = pos.restwert;
    if (pos.wertminderung)     updates.wertminderung     = pos.wertminderung;
    if (pos.nutzungsausfall)   updates.nutzungsausfall   = pos.nutzungsausfall;
    if (pos.sv_kosten)         updates.sv_kosten         = pos.sv_kosten;
    setForm(prev => {
      const neu = { ...prev, ...updates, quelle: "gutachten_pdf" };
      const gutVorschlag = ermittleAbrechnungsart(neu, vorsteuer);
      setArtVorschlag(gutVorschlag);
      return neu;
    });
    setChg(true);
    setShowGutImport(false);
    setGutErg(null);
    setGutFile(null);
    setToast("Gutachten-Werte übernommen – bitte prüfen und speichern.");
  };

  const [focusedField, setFocusedField] = useState(null);
  const [editValue, setEditValue]       = useState("");
  const fmtField = (v) => v ? new Intl.NumberFormat("de-DE", { minimumFractionDigits:2, maximumFractionDigits:2 }).format(v) : "";

  const rowStyle   = { display:"grid", gridTemplateColumns:"220px 1fr", alignItems:"center", gap:"0.75rem", padding:"0.55rem 0", borderBottom:`1px solid ${T.borderSoft}` };
  const labelStyle = { fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.895rem", fontWeight:600, color:T.textMid, letterSpacing:"0.02em" };

  const renderEuroInput = (fieldKey, { abzug=false, extraValue, onExtraChange } = {}) => {
    const isExtra = extraValue !== undefined;
    const storedVal = isExtra ? extraValue : (form[fieldKey]||0);
    const isFoc   = focusedField === fieldKey;
    return (
      <div style={{ display:"flex", border:`1.5px solid ${isFoc ? T.gold : T.border}`, borderRadius:7, overflow:"hidden", background:T.surface, maxWidth:280, transition:"border-color 0.15s" }}>
        <span style={{ padding:"7px 9px", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.905rem", color:abzug?T.red:T.textFaint, background:T.offWhite, borderRight:`1px solid ${T.border}`, flexShrink:0 }}>{abzug?"−€":"€"}</span>
        <input
          type="text"
          inputMode="decimal"
          value={isFoc ? editValue : fmtField(storedVal)}
          onChange={e => {
            // Nur Ziffern, Komma und Punkt erlauben
            const cleaned = e.target.value.replace(/[^\d,.]/g, "");
            setEditValue(cleaned);
          }}
          onFocus={() => {
            setFocusedField(fieldKey);
            // Beim Fokussieren: gespeicherten Wert als Rohstring anzeigen (0 → leer)
            setEditValue(storedVal ? String(storedVal).replace(".", ",") : "");
          }}
          onBlur={() => {
            // Beim Verlassen: String in Zahl umwandeln und speichern
            const raw = editValue.replace(",", ".");
            const num = parseFloat(raw) || 0;
            if (isExtra) onExtraChange(num);
            else upd(fieldKey, num);
            setFocusedField(null);
            setEditValue("");
          }}
          placeholder="0,00"
          style={{ flex:1, minWidth:0, padding:"7px 10px 7px 6px", border:"none", background:"transparent", outline:"none", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.985rem", color:T.text, textAlign:"right" }}
        />
      </div>
    );
  };

  // 130%-Fall-Erkennung für Hinweis-Banner
  const _cb = k => parseFloat(form[k]) || 0;
  const _cbRepRN = _cb("rep_rechnung_netto");
  const _cbWbw   = _cb("wiederbeschaffung");
  const _cbRst   = _cb("restwert");
  const zeige130Hinweis = _cbRepRN > 0 && _cbWbw > 0
    && _cbRepRN > (_cbWbw - _cbRst) && _cbRepRN <= 1.3 * _cbWbw;

  return (
    <>
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
      {psToast && <Toast msg={psToast} onDone={() => setPsToast("")} />}

      {/* ── Tab-Navigation ──────────────────────────────────────────────── */}
      <div style={{ display:"flex", borderBottom:`2px solid ${T.border}`, marginBottom:"1.25rem" }}>
        {[
          { id:"sachschaden",     label:"🚗 Sachschaden"     },
          { id:"personenschaden", label:"🏥 Personenschaden" },
        ].map(tab => (
          <button key={tab.id} onClick={() => setSchadenTab(tab.id)} style={{
            padding:"9px 22px", border:"none", background:"none", cursor:"pointer",
            fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.935rem",
            fontWeight: schadenTab===tab.id ? 700 : 500,
            color:      schadenTab===tab.id ? T.navy : T.textMuted,
            borderBottom: schadenTab===tab.id ? `3px solid ${T.navy}` : "3px solid transparent",
            marginBottom:"-2px", transition:"all 0.15s",
          }}>{tab.label}</button>
        ))}
      </div>

      {/* ══════════════════════════════════════════════════════════════════
          TAB: SACHSCHADEN
      ══════════════════════════════════════════════════════════════════ */}
      {schadenTab === "sachschaden" && <>

      {/* ── 130%-Hinweis-Banner ─────────────────────────────────────────── */}
      {zeige130Hinweis && (
        <div style={{ background:"#fffbeb", border:"1.5px solid #f59e0b", borderRadius:9,
          padding:"0.75rem 1.1rem", marginBottom:"1rem", display:"flex", gap:10, alignItems:"flex-start",
          fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:"#92400e" }}>
          <span style={{ fontSize:"1.1rem", flexShrink:0 }}>⚠️</span>
          <div>
            <strong>Möglicher 130%-Fall:</strong> Die Reparaturrechnung ({new Intl.NumberFormat("de-DE",{style:"currency",currency:"EUR"}).format(_cbRepRN)})
            übersteigt den Fahrzeugschaden (WBW − Restwert), liegt aber noch im 130%-Rahmen.
            Im Forderungsschreiben wird die konkrete Reparatur geltend gemacht.
            Bitte Abrechnungsart auf <strong>„konkret"</strong> setzen.
          </div>
        </div>
      )}

      {/* ── Auto-WDM Ladeindikator ──────────────────────────────────────── */}
      {wdmLaden && (
        <Card>
          <div style={{ padding:"0.8rem 1.4rem", display:"flex", alignItems:"center", gap:10, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:"#6b21a8" }}>
            <span style={{ animation:"spin 0.8s linear infinite", display:"inline-block" }}>⟳</span>
            Schadenpositionen aus RA-Micro werden geladen…
          </div>
        </Card>
      )}

      {/* ── WDM-Ergebnis-Panel ──────────────────────────────────────────── */}
      {wdmSchadenDaten && ((wdmSchadenDaten.felder_gefunden||0) > 0 || (wdmSchadenDaten.extras_gefunden||0) > 0) && (!hatLokaleWerte || wdmExplizit) && (
        <Card>
          <div style={{ padding:"1rem 1.4rem" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"0.75rem" }}>
              <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.9rem", fontWeight:700, color:"#6b21a8" }}>
                📊 {wdmSchadenDaten.felder_gefunden} Schadenpositionen aus RA-Micro
                {(wdmSchadenDaten.extras_gefunden||0) > 0 && ` + ${wdmSchadenDaten.extras_gefunden} sonstige Schäden`}
              </div>
              <Btn size="sm" variant="ghost" onClick={() => setWdmSchaden(null)}>✕</Btn>
            </div>
            <div style={{ display:"flex", flexWrap:"wrap", gap:"0.4rem 1.5rem", marginBottom:10 }}>
              {Object.entries(wdmSchadenDaten.schaden).filter(([,v]) => v > 0).map(([k, v]) => (
                <div key={k} style={{ fontSize:"0.82rem" }}>
                  <span style={{ color:T.textMuted, fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.75rem" }}>{wdmSchadenDaten.quellen[k]}</span>
                  <span style={{ color:T.textMuted }}> → </span>
                  <span style={{ color:"#6b21a8", fontWeight:600 }}>{SCHADEN_F.find(f=>f.k===k)?.l || k}: </span>
                  <span style={{ color:T.navy, fontWeight:700 }}>{fmtEuro(v)}</span>
                </div>
              ))}
            </div>
            {(wdmSchadenDaten.extras||[]).filter(e=>e.betrag>0).map(e => (
              <div key={e.id} style={{ fontSize:"0.82rem", fontFamily:"'IBM Plex Mono',monospace", marginBottom:2 }}>
                <span style={{ color:T.textMuted, fontSize:"0.75rem" }}>{e.wdm_var}</span>
                <span style={{ color:T.textMuted }}> → </span>
                <span style={{ color:"#6b21a8", fontWeight:600 }}>{e.label}: </span>
                <span style={{ color:T.navy, fontWeight:700 }}>{fmtEuro(e.betrag)}</span>
                <span style={{ color:T.textMuted, fontSize:"0.75rem" }}> (netto {fmtEuro(e.netto)} + MwSt {fmtEuro(e.mwst)})</span>
              </div>
            ))}
            {Object.keys(wdmSchadenDaten.info||{}).length > 0 && (
              <div style={{ marginTop:8, display:"flex", gap:"1rem", flexWrap:"wrap" }}>
                {wdmSchadenDaten.info.fahrzeugklasse_na && <span style={{ fontSize:"0.8rem", color:T.textMuted }}>🚗 NA-Klasse {wdmSchadenDaten.info.fahrzeugklasse_na}</span>}
                {wdmSchadenDaten.info.na_tagessatz > 0 && <span style={{ fontSize:"0.8rem", color:T.textMuted }}>📅 Tagessatz {fmtEuro(wdmSchadenDaten.info.na_tagessatz)}</span>}
                {wdmSchadenDaten.info.reparaturdauer > 0 && <span style={{ fontSize:"0.8rem", color:T.textMuted }}>🔧 Reparaturdauer {wdmSchadenDaten.info.reparaturdauer} Tage</span>}
              </div>
            )}
            <Btn variant="gold" size="sm" onClick={uebernehmeWdmSchaden} style={{ marginTop:12 }}>
              ↓ Alle Werte übernehmen
            </Btn>
          </div>
        </Card>
      )}

      <Card>
        <CardHead
          title="Schadenpositionen"
          action={
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <span style={{ display:"inline-flex", alignItems:"center", gap:5, background:qc.bg, color:qc.c, border:`1px solid ${qc.c}33`, borderRadius:12, padding:"2px 8px", fontSize:"0.825rem", fontWeight:600 }}>
                {quelleLabels[form.quelle]||form.quelle}
              </span>
              {akteId?.includes("/") && (
                <Btn size="sm" variant="secondary" onClick={() => {
                  setWdmLaden(true); setWdmExplizit(true);
                  ramicroWdm.schaden(akteId).then(s => { setWdmSchaden(s); }).catch(()=>{}).finally(()=>setWdmLaden(false));
                }} disabled={wdmLaden}>
                  {wdmLaden ? "…" : hatLokaleWerte ? "🔍 WDM neu laden" : "🔍 RA-Micro WDM"}
                </Btn>
              )}
              <Btn size="sm" variant="secondary" onClick={() => { setShowGutImport(o=>!o); setGutErg(null); setGutError(""); }}>
                📄 Aus Gutachten
              </Btn>
              {changed && <Btn variant="gold" onClick={save} disabled={saving}>{saving?"…":Ic.check} Speichern</Btn>}
            </div>
          }
        />

        {/* Gutachten-Import-Panel */}
        {showGutImport && (
          <div style={{ margin:"0 1.4rem 1rem", padding:"1rem 1.2rem", background:T.blueBg, border:`1.5px solid ${T.blue}44`, borderRadius:9 }}>
            <div style={{ fontSize:"0.84rem", fontWeight:600, color:T.navy, marginBottom:8 }}>
              📄 Gutachten-PDF hochladen
            </div>
            {!gutErgebnis && !gutLoading && (
              <label style={{ display:"flex", alignItems:"center", gap:10, cursor:"pointer" }}>
                <input type="file" accept=".pdf" style={{ display:"none" }}
                  onChange={e => { const f=e.target.files[0]; if(f) handleGutDatei(f); }} />
                <div style={{ padding:"8px 16px", background:T.navy, color:T.white, borderRadius:7, fontSize:"0.875rem", fontWeight:600 }}>
                  PDF wählen
                </div>
                <span style={{ fontSize:"0.84rem", color:T.textMuted }}>
                  {gutFile ? gutFile.name : "Kein Gutachten gewählt"}
                </span>
              </label>
            )}
            {gutLoading && (
              <div style={{ display:"flex", alignItems:"center", gap:10, color:T.textMuted, fontSize:"0.875rem" }}>
                <div style={{ width:16, height:16, border:`2px solid ${T.border}`, borderTopColor:T.navy, borderRadius:"50%", animation:"spin 0.7s linear infinite" }} />
                Gutachten wird analysiert …
              </div>
            )}
            {gutError && (
              <div style={{ color:T.red, fontSize:"0.875rem", marginTop:4 }}>⚠ {gutError}</div>
            )}
            {gutErgebnis && (
              <div>
                <div style={{ fontSize:"0.84rem", color:T.green, fontWeight:600, marginBottom:8 }}>
                  ✓ Erkannt: {gutErgebnis.sv_buero || "SV-Gutachten"} · {gutErgebnis.schadenart === "totalschaden" ? "🔴 Totalschaden" : "🟡 Reparaturschaden"}
                  {gutErgebnis.fahrzeug?.kennzeichen && ` · ${gutErgebnis.fahrzeug.kennzeichen}`}
                </div>
                <table style={{ width:"100%", borderCollapse:"collapse", fontSize:"0.855rem", marginBottom:10 }}>
                  <thead>
                    <tr style={{ background:"rgba(0,0,0,0.04)" }}>
                      {["Position","Betrag (Gutachten)"].map(h => (
                        <th key={h} style={{ padding:"5px 10px", textAlign:h==="Position"?"left":"right", color:T.textMuted, fontWeight:600, fontSize:"0.78rem", textTransform:"uppercase" }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ["Reparaturkosten", gutErgebnis.schadenpositionen?.reparaturkosten],
                      ["Wiederbeschaffungswert", gutErgebnis.schadenpositionen?.wiederbeschaffung],
                      ["Restwert (Abzug)", gutErgebnis.schadenpositionen?.restwert],
                      ["Wertminderung", gutErgebnis.schadenpositionen?.wertminderung],
                      ["Nutzungsausfall", gutErgebnis.schadenpositionen?.nutzungsausfall],
                      ["SV-Kosten", gutErgebnis.schadenpositionen?.sv_kosten],
                    ].filter(([,v]) => v != null && v > 0).map(([label, value]) => (
                      <tr key={label} style={{ borderTop:`1px solid ${T.border}` }}>
                        <td style={{ padding:"5px 10px", color:T.text }}>{label}</td>
                        <td style={{ padding:"5px 10px", textAlign:"right", fontFamily:"monospace", fontWeight:600, color:T.navy }}>{fmtEuro(value)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {(gutErgebnis.warnungen||[]).length > 0 && (
                  <div style={{ fontSize:"0.8rem", color:T.amber, marginBottom:8 }}>
                    ⚠ {gutErgebnis.warnungen.join(" · ")}
                  </div>
                )}
                <div style={{ display:"flex", gap:8 }}>
                  <Btn variant="gold" onClick={handleGutachtenUebernehmen}>✓ Werte übernehmen</Btn>
                  <Btn variant="secondary" onClick={() => { setGutErg(null); setGutFile(null); }}>Andere Datei</Btn>
                  <Btn variant="ghost" onClick={() => setShowGutImport(false)} style={{ marginLeft:"auto" }}>Abbrechen</Btn>
                </div>
              </div>
            )}
          </div>
        )}
        <div style={{ padding:"0.5rem 1.4rem 1.25rem" }}>

          {/* Feste Positionen – 2-Spalten-Layout */}
          <div style={{ marginBottom:"0.5rem" }}>
            {SCHADEN_F.map(f => (
              <div key={f.k} style={rowStyle}>
                <label style={{ ...labelStyle, color: f.abzug ? T.red : T.textMid }}>
                  {f.l}
                </label>
                <div>
                  {renderEuroInput(f.k, { abzug: f.abzug })}
                  {f.k==="sonstiges" && (
                    <input placeholder="Beschreibung" value={form.sonstiges_beschr||""} onChange={e => { setForm(p => ({...p,sonstiges_beschr:e.target.value})); setChg(true); }} style={{ marginTop:4, width:"100%", maxWidth:220, padding:"5px 8px", border:`1px solid ${T.border}`, borderRadius:6, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.895rem", color:T.textMid, background:T.surface, outline:"none", boxSizing:"border-box" }} />
                  )}
                </div>
              </div>
            ))}

            {/* Sonstige Schäden – Tabelle mit Bezeichnung, Netto, MwSt */}
            {(extras.length > 0 || showAdd) && (
              <div style={{ marginTop:"1rem" }}>
                <div style={{ fontSize:"0.8rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:6 }}>
                  Sonstige Schäden
                </div>
                <table style={{ width:"100%", borderCollapse:"collapse", fontSize:"0.875rem" }}>
                  <thead>
                    <tr style={{ background:T.surface }}>
                      {["Bezeichnung","Netto (€)","MwSt (€)","Brutto (€)",""].map((h,i) => (
                        <th key={h} style={{ padding:"5px 8px", textAlign:i===0?"left":"right", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.77rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.05em", borderBottom:`1px solid ${T.border}` }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {extras.map((e, i) => (
                      <tr key={e.id} style={{ background:i%2===0?T.white:T.surface }}>
                        <td style={{ padding:"5px 8px" }}>
                          <input
                            value={e.label||""}
                            onChange={ev => { const upd = extras.map(x => x.id===e.id ? {...x,label:ev.target.value} : x); setExtras(upd); setForm(p=>({...p,_extras:upd})); setChg(true); }}
                            style={{ width:"100%", border:"none", background:"transparent", outline:"none", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:T.text }}
                          />
                        </td>
                        <td style={{ padding:"5px 8px", textAlign:"right" }}>
                          <input
                            value={focusedField===`${e.id}_n` ? editValue : fmtField(e.netto||0)}
                            onChange={ev => setEditValue(ev.target.value)}
                            onFocus={() => { setFocusedField(`${e.id}_n`); setEditValue(String(e.netto||0).replace(".",",")); }}
                            onBlur={ev => {
                              const v = parseFloat(ev.target.value.replace(",",".")) || 0;
                              const brutto = v + (e.mwst||0);
                              const upd = extras.map(x => x.id===e.id ? {...x,netto:v,betrag:brutto} : x);
                              setExtras(upd); setForm(p=>({...p,_extras:upd})); setChg(true); setFocusedField(null);
                            }}
                            style={{ width:90, border:"none", background:"transparent", outline:"none", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.875rem", color:T.text, textAlign:"right" }}
                          />
                        </td>
                        <td style={{ padding:"5px 8px", textAlign:"right" }}>
                          <input
                            value={focusedField===`${e.id}_m` ? editValue : fmtField(e.mwst||0)}
                            onChange={ev => setEditValue(ev.target.value)}
                            onFocus={() => { setFocusedField(`${e.id}_m`); setEditValue(String(e.mwst||0).replace(".",",")); }}
                            onBlur={ev => {
                              const v = parseFloat(ev.target.value.replace(",",".")) || 0;
                              const brutto = (e.netto||0) + v;
                              const upd = extras.map(x => x.id===e.id ? {...x,mwst:v,betrag:brutto} : x);
                              setExtras(upd); setForm(p=>({...p,_extras:upd})); setChg(true); setFocusedField(null);
                            }}
                            style={{ width:90, border:"none", background:"transparent", outline:"none", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.875rem", color:T.text, textAlign:"right" }}
                          />
                        </td>
                        <td style={{ padding:"5px 8px", textAlign:"right", fontFamily:"'IBM Plex Mono',monospace", fontWeight:600, color:T.navy }}>
                          {fmtEuro((e.netto||0)+(e.mwst||0))}
                        </td>
                        <td style={{ padding:"5px 4px", textAlign:"center" }}>
                          <button onClick={() => { const upd = extras.filter(x=>x.id!==e.id); setExtras(upd); setForm(p=>({...p,_extras:upd})); setChg(true); }}
                            style={{ background:"none", border:"none", cursor:"pointer", color:T.red, padding:2, borderRadius:4, lineHeight:1 }}
                            onMouseEnter={ev=>ev.currentTarget.style.background=T.redBg}
                            onMouseLeave={ev=>ev.currentTarget.style.background="none"}>
                            {Ic.trash}
                          </button>
                        </td>
                      </tr>
                    ))}
                    {/* Neue Zeile */}
                    {showAdd && (
                      <tr style={{ background:T.goldPale }}>
                        <td style={{ padding:"5px 8px" }}>
                          <input autoFocus value={newLabel} onChange={e=>setNewLabel(e.target.value)}
                            placeholder="Bezeichnung"
                            style={{ width:"100%", border:`1px solid ${T.gold}`, borderRadius:4, padding:"3px 6px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", outline:"none" }} />
                        </td>
                        <td style={{ padding:"5px 8px" }}>
                          <input value={newBetrag} onChange={e=>setNewBetrag(e.target.value)} placeholder="0,00"
                            style={{ width:90, border:`1px solid ${T.gold}`, borderRadius:4, padding:"3px 6px", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.875rem", textAlign:"right", outline:"none" }} />
                        </td>
                        <td style={{ padding:"5px 8px" }}>
                          <input value={newMwst} onChange={e=>setNewMwst(e.target.value)} placeholder="0,00"
                            style={{ width:90, border:`1px solid ${T.gold}`, borderRadius:4, padding:"3px 6px", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.875rem", textAlign:"right", outline:"none" }} />
                        </td>
                        <td style={{ padding:"5px 8px", textAlign:"right", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.875rem", color:T.textMuted }}>
                          {fmtEuro((parseFloat(newBetrag.replace(",","."))||0)+(parseFloat(newMwst.replace(",","."))||0))}
                        </td>
                        <td style={{ padding:"5px 4px", display:"flex", gap:4 }}>
                          <button onClick={() => {
                            if (!newLabel.trim()) return;
                            const netto = parseFloat(newBetrag.replace(",",".")) || 0;
                            const mwst  = parseFloat(newMwst.replace(",",".")) || 0;
                            const entry = { id:Date.now(), label:newLabel.trim(), netto, mwst, betrag:netto+mwst };
                            const upd = [...extras, entry];
                            setExtras(upd); setForm(p=>({...p,_extras:upd})); setChg(true);
                            setNewLabel(""); setNewBetrag(""); setNewMwst(""); setShowAdd(false);
                          }} style={{ background:T.gold, border:"none", borderRadius:4, color:"#fff", cursor:"pointer", padding:"2px 7px", fontSize:"0.8rem", fontWeight:600 }}>✓</button>
                          <button onClick={()=>{setShowAdd(false);setNewLabel("");setNewBetrag("");setNewMwst("");}}
                            style={{ background:T.redBg, border:"none", borderRadius:4, color:T.red, cursor:"pointer", padding:"2px 6px", fontSize:"0.8rem" }}>✕</button>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Button: Sonstigen Schaden hinzufügen – Eingabe läuft jetzt inline in der Tabelle oben */}
          {!showAdd && (
            <button onClick={() => setShowAdd(true)}
              style={{ display:"flex", alignItems:"center", gap:6, padding:"7px 12px", background:"none", border:`1.5px dashed ${T.border}`, borderRadius:8, cursor:"pointer", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.895rem", color:T.textMuted, marginTop:"0.5rem", transition:"all 0.15s" }}
              onMouseEnter={ev => { ev.currentTarget.style.borderColor=T.navy; ev.currentTarget.style.color=T.navy; }}
              onMouseLeave={ev => { ev.currentTarget.style.borderColor=T.border; ev.currentTarget.style.color=T.textMuted; }}>
              {Ic.plus} Sonstigen Schaden hinzufügen
            </button>
          )}

          {/* Summe */}
          <div style={{ borderTop:`2px solid ${T.border}`, paddingTop:"1rem", marginTop:"1.25rem", display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:"1rem" }}>
            {[
              { l:"Gesamtschaden (Brutto)",   v:fmtEuro(brutto), c:T.navy,  bg:T.surface   },
              { l:`Netto (Haftung ${hq} %)`, v:fmtEuro(netto),  c:T.navy,  bg:T.goldPale  },
              { l:"Quelle",                   v:null,             c:T.text,  bg:T.surface   },
            ].map((s, i) => (
              <div key={i} style={{ background:s.bg, borderRadius:10, padding:"0.85rem 1rem", border:`1px solid ${T.border}` }}>
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.815rem", color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:6 }}>{s.l}</div>
                {i < 2 ? (
                  <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.625rem", fontWeight:700, color:s.c }}>{s.v}</div>
                ) : (
                  <select value={form.quelle||"manuell"} onChange={e => { setForm(p => ({...p,quelle:e.target.value})); setChg(true); }} style={{ padding:"5px 8px", border:`1px solid ${T.border}`, borderRadius:6, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.955rem", color:T.text, background:T.white, cursor:"pointer", outline:"none" }}>
                    <option value="manuell">Manuell</option>
                    <option value="gutachten_pdf">Gutachten (PDF)</option>
                    <option value="abrechnung_pdf">Abrechnung (PDF)</option>
                    <option value="korrektur">Korrektur</option>
                  </select>
                )}
              </div>
            ))}
          </div>
          {/* Abrechnungsart: Vorschlag-Banner + Dropdown */}
          {artVorschlag && artVorschlag.art !== form.abrechnungsart && (
            <div style={{ marginTop:"1rem", padding:"0.7rem 1rem",
              background:"#f0f9ff", border:"1.5px solid #38bdf8", borderRadius:9,
              display:"flex", alignItems:"flex-start", gap:10,
              fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:"#0369a1" }}>
              <span style={{ flexShrink:0, fontSize:"1rem" }}>🔍</span>
              <div style={{ flex:1 }}>
                <strong>Vorschlag: {
                  artVorschlag.art === "fiktiv" ? "Fiktive Abrechnung" :
                  artVorschlag.art === "konkret" ? "Konkrete Abrechnung" : "Totalschaden"
                }</strong>
                <div style={{ fontSize:"0.82rem", color:"#0284c7", marginTop:2 }}>{artVorschlag.begruendung}</div>
              </div>
              <button onClick={() => { setForm(p=>({...p,abrechnungsart:artVorschlag.art})); setChg(true); setArtVorschlag(null); }}
                style={{ flexShrink:0, padding:"5px 12px", background:"#0369a1", color:"#fff",
                  border:"none", borderRadius:6, fontSize:"0.82rem", fontWeight:600, cursor:"pointer",
                  whiteSpace:"nowrap" }}>
                ↓ Übernehmen
              </button>
            </div>
          )}
          <div style={{ marginTop:"1rem", display:"flex", alignItems:"center", gap:12,
            padding:"0.75rem 1rem", background:T.surface, borderRadius:9, border:`1px solid ${T.border}` }}>
            <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem",
              fontWeight:600, color:T.textMid, minWidth:130 }}>Abrechnungsart</span>
            <select value={form.abrechnungsart||""} onChange={e => { setForm(p=>({...p,abrechnungsart:e.target.value})); setChg(true); setArtVorschlag(null); }}
              style={{ padding:"6px 10px", border:`1.5px solid ${T.border}`, borderRadius:7,
                fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.895rem", color:T.text,
                background:T.white, cursor:"pointer", outline:"none", minWidth:180 }}>
              <option value="">— nicht gesetzt —</option>
              <option value="fiktiv">Fiktive Abrechnung (Gutachten, netto)</option>
              <option value="konkret">Konkrete Abrechnung (Rechnung, netto)</option>
              <option value="totalschaden">Totalschaden (WBW − Restwert)</option>
            </select>
            {form.abrechnungsart === "konkret" && zeige130Hinweis && (
              <span style={{ fontSize:"0.82rem", color:"#92400e", background:"#fffbeb",
                border:"1px solid #f59e0b", borderRadius:6, padding:"3px 8px" }}>
                ⚠ 130%-Fall prüfen
              </span>
            )}
          </div>
        </div>
      </Card>
      </>}{/* Ende Sachschaden-Tab */}

      {/* ══════════════════════════════════════════════════════════════════
          TAB: PERSONENSCHADEN
      ══════════════════════════════════════════════════════════════════ */}
      {schadenTab === "personenschaden" && (
        <PersonenschadenTab akteId={akteId} psForm={psForm} setPsForm={setPsForm}
          psChg={psChg} setPsChg={setPsChg} psSaving={psSaving} setPsSaving={setPsSave}
          setPsToast={setPsToast} savePsForm={savePsForm} psUpd={psUpd} />
      )}
    </>
  );
}

/* ══════════════════════════════════════════════════════════════
   PERSONENSCHADEN TAB KOMPONENTE
══════════════════════════════════════════════════════════════ */
function PersonenschadenTab({ akteId, psForm, setPsForm, psChg, setPsChg,
  psSaving, setPsSaving, setPsToast, savePsForm, psUpd }) {

  const [beteiligte, setBeteiligte]     = useState([]);
  const [betLaden, setBetLaden]         = useState(false);
  const [betQuelle, setBetQuelle]       = useState("leer");
  const [wdmGespeichert, setWdmGespeichert] = useState(false);

  // Suchfeld-State: welche Rolle wird gerade gesucht (null = kein Such-Panel)
  const [sucheRolle, setSucheRolle]     = useState(null);
  const [sucheQ, setSucheQ]             = useState("");
  const [sucheErg, setSucheErg]         = useState([]);
  const [sucheLaden, setSucheLaden]     = useState(false);
  const [gewaehlt, setGewaehlt]         = useState(null);
  const [neueNotizen, setNeueNotizen]   = useState("");

  const [wdmPsLaden, setWdmPsLaden] = useState(false);
  const [wdmPsDaten, setWdmPsDaten] = useState(null);

  // Beteiligte + WDM-Daten laden
  React.useEffect(() => {
    if (!akteId) return;
    // Beteiligte laden
    setBetLaden(true);
    apiPS.beteiligteLaden(akteId)
      .then(d => {
        setBeteiligte(d.beteiligte || []);
        setBetQuelle(d.quelle || "leer");
      })
      .catch(() => {})
      .finally(() => setBetLaden(false));

    // WDM-Textfelder laden (nur wenn AZ-Format korrekt)
    if (!akteId.includes("/")) return;
    setWdmPsLaden(true);
    apiPS.wdmLaden(akteId)
      .then(d => {
        if (!d || (d.felder_gefunden === 0 && d.adressen_gefunden === 0)) return;

        // Prüfen ob bereits manuelle SQLite-Daten vorliegen
        // psForm kommt als Prop von außen – wenn leer → auto-übernehmen
        const hatManuelleWerte = Object.keys(psForm).some(k => {
          const v = psForm[k];
          return v !== null && v !== undefined && v !== "" && v !== 0;
        });

        if (!hatManuelleWerte) {
          // Keine manuellen Daten → WDM direkt und still übernehmen
          // Textfelder sofort in Form setzen
          Object.entries(d.textfelder || {}).forEach(([k, v]) => {
            if (v !== undefined && v !== null && v !== "") setPsForm(p => ({...p, [k]: v}));
          });
          // Beteiligte speichern wenn vorhanden
          if ((d.adressen || []).length > 0) {
            const batch = d.adressen.map((a, i) => ({
              adressnr: a.adressnr, rolle: a.rolle,
              quelle: "wdm", notizen: a.notizen || "", sortierung: i,
            }));
            apiPS.beteiligterSpeichern(akteId, { batch })
              .then(res => {
                if (res.beteiligte) setBeteiligte(res.beteiligte);
              })
              .catch(() => {});
          }
          // Automatisch in SQLite speichern
          apiPS.speichern(akteId, {...psForm, ...d.textfelder})
            .catch(() => {});
        } else {
          // Manuelle Daten vorhanden → nur Banner anzeigen für optionale Ergänzung
          setWdmPsDaten(d);
        }
      })
      .catch(() => {})
      .finally(() => setWdmPsLaden(false));
  }, [akteId]); // eslint-disable-line react-hooks/exhaustive-deps

  // WDM-Einträge einmalig in SQLite speichern
  React.useEffect(() => {
    if (betQuelle !== "wdm" || !beteiligte.length || wdmGespeichert) return;
    const batch = beteiligte.map((b, i) => ({
      adressnr: b.adressnr, rolle: b.rolle,
      quelle: "wdm", notizen: b.notizen || "", sortierung: i,
    }));
    apiPS.beteiligterSpeichern(akteId, { batch })
      .then(res => {
        if (res.beteiligte) { setBeteiligte(res.beteiligte); setBetQuelle("sqlite"); }
        setWdmGespeichert(true);
      })
      .catch(e => console.error("WDM-Speichern:", e));
  }, [betQuelle, beteiligte, wdmGespeichert]);

  // WDM-Felder übernehmen (Textfelder + Beteiligte)
  const uebernehmeWdmPs = async () => {
    if (!wdmPsDaten) return;
    // Textfelder in psForm übernehmen (nur wenn noch leer)
    const updates = {};
    Object.entries(wdmPsDaten.textfelder || {}).forEach(([k, v]) => {
      if (!psForm[k] && v !== undefined) updates[k] = v;
    });
    if (Object.keys(updates).length > 0) {
      Object.entries(updates).forEach(([k,v]) => psUpd(k, v));
      setPsChg(true);
    }
    // Adress-Beteiligte speichern
    const neueBet = (wdmPsDaten.adressen || []).filter(a =>
      !beteiligte.find(b => b.adressnr === a.adressnr && b.rolle === a.rolle)
    );
    if (neueBet.length > 0) {
      try {
        const batch = neueBet.map((a, i) => ({
          adressnr: a.adressnr, rolle: a.rolle,
          quelle: "wdm", notizen: a.notizen || "",
          sortierung: beteiligte.length + i,
        }));
        const res = await apiPS.beteiligterSpeichern(akteId, { batch });
        if (res.beteiligte) {
          setBeteiligte(prev => {
            const ids = new Set(res.beteiligte.map(b => b.id));
            return [...prev.filter(b => !ids.has(b.id)), ...res.beteiligte];
          });
        }
      } catch(e) { setPsToast("⚠ WDM-Beteiligte konnten nicht gespeichert werden."); }
    }
    setWdmPsDaten(null);
  };

  // Suche starten (nur auf Enter oder Button-Klick)
  const suchStarten = () => {
    if (sucheQ.trim().length < 2) return;
    setSucheLaden(true);
    setSucheErg([]);
    apiPS.adressSuche(sucheQ.trim())
      .then(d => setSucheErg(d.ergebnisse || []))
      .catch(() => setSucheErg([]))
      .finally(() => setSucheLaden(false));
  };

  // Such-Panel öffnen für eine bestimmte Rolle
  const oeffneSuche = (rolle) => {
    setSucheRolle(rolle);
    setSucheQ(""); setSucheErg([]); setGewaehlt(null); setNeueNotizen("");
  };

  const schliesseSuche = () => {
    setSucheRolle(null); setSucheQ(""); setSucheErg([]);
    setGewaehlt(null); setNeueNotizen("");
  };

  const beteiligterHinzufuegen = async () => {
    if (!gewaehlt || !sucheRolle) return;
    try {
      const res = await apiPS.beteiligterSpeichern(akteId, {
        adressnr: gewaehlt.adressnr, rolle: sucheRolle,
        quelle: "manuell", notizen: neueNotizen,
        sortierung: beteiligte.filter(b => b.rolle===sucheRolle).length,
      });
      if (res.beteiligte?.length) {
        setBeteiligte(prev => {
          const neu = res.beteiligte;
          const ids = new Set(neu.map(b => b.id));
          return [...prev.filter(b => !ids.has(b.id)), ...neu];
        });
      }
    } catch { setPsToast("⚠ Fehler beim Speichern."); }
    schliesseSuche();
  };

  const beteiligterLoeschen = async (b) => {
    if (b.id == null) return;
    try {
      await apiPS.beteiligterLoeschen(akteId, b.id);
      setBeteiligte(prev => prev.filter(x => x.id !== b.id));
    } catch { setPsToast("⚠ Löschen fehlgeschlagen."); }
  };

  const notizAktualisieren = async (b, notizen) => {
    if (b.id == null) return;
    try {
      await apiPS.beteiligterAktualisieren(akteId, b.id, { notizen, quelle:"manuell" });
      setBeteiligte(prev => prev.map(x => x.id===b.id ? {...x,notizen,quelle:"manuell"} : x));
    } catch {}
  };

  // Such-Panel JSX (wird inline in Klapp-Kacheln gerendert)
  const SuchPanel = ({ rolle }) => (
    <div style={{ gridColumn:"1/-1", marginTop:"0.5rem", padding:"0.9rem 1rem",
      background:T.blueBg, border:`1.5px solid ${T.blue}44`, borderRadius:8 }}>
      <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", fontWeight:700,
        color:T.navy, marginBottom:"0.6rem" }}>
        🔍 {ROLLEN_LABEL[rolle]} aus RA-Micro suchen
      </div>
      <div style={{ display:"flex", gap:"0.5rem", marginBottom:"0.6rem" }}>
        <input value={sucheQ} onChange={e=>setSucheQ(e.target.value)}
          onKeyDown={e=>{ if(e.key==="Enter") suchStarten(); }}
          placeholder="Name oder Adressnummer, dann Enter…" autoFocus
          style={{ flex:1, padding:"7px 10px", border:`1.5px solid ${T.border}`,
            borderRadius:7, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem",
            background:T.white, outline:"none" }} />
        <Btn size="sm" variant="secondary" onClick={suchStarten} disabled={sucheLaden}>
          {sucheLaden ? "⟳" : "Suchen"}
        </Btn>
        <Btn size="sm" variant="ghost" onClick={schliesseSuche}>✕</Btn>
      </div>

      {sucheErg.length > 0 && (
        <div style={{ border:`1px solid ${T.border}`, borderRadius:7, overflow:"hidden",
          background:T.white, maxHeight:200, overflowY:"auto", marginBottom:"0.6rem" }}>
          {sucheErg.map(e => (
            <div key={e.adressnr} onClick={() => setGewaehlt(e)}
              style={{ padding:"7px 12px", cursor:"pointer",
                borderBottom:`1px solid ${T.borderSoft}`,
                background: gewaehlt?.adressnr===e.adressnr ? T.blueBg : "transparent",
                display:"flex", justifyContent:"space-between", alignItems:"center" }}>
              <div>
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem",
                  fontWeight:600, color:T.text }}>{e.name}</div>
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem",
                  color:T.textMuted }}>
                  {[e.strasse, e.plz&&e.ort ? `${e.plz} ${e.ort}` : e.ort].filter(Boolean).join(" · ")}
                </div>
              </div>
              <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.75rem",
                color:T.textFaint, flexShrink:0, marginLeft:8 }}>#{e.adressnr}</span>
            </div>
          ))}
        </div>
      )}
      {sucheQ.length >= 2 && !sucheLaden && sucheErg.length === 0 && (
        <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem",
          color:T.textMuted, marginBottom:"0.5rem" }}>Keine Treffer in RA-Micro.</div>
      )}

      {gewaehlt && (
        <div style={{ padding:"0.6rem 0.8rem", background:T.surface, borderRadius:7,
          border:`1.5px solid ${T.blue}55`, marginBottom:"0.6rem" }}>
          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem",
            fontWeight:700, color:T.navy }}>
            ✓ {gewaehlt.name}
            <span style={{ fontWeight:400, color:T.textFaint, marginLeft:6 }}>#{gewaehlt.adressnr}</span>
          </div>
          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", color:T.textMuted }}>
            {[gewaehlt.strasse, gewaehlt.plz&&gewaehlt.ort ? `${gewaehlt.plz} ${gewaehlt.ort}` : gewaehlt.ort, gewaehlt.telefon ? `☎ ${gewaehlt.telefon}` : ""].filter(Boolean).join(" · ")}
          </div>
          <input value={neueNotizen} onChange={e=>setNeueNotizen(e.target.value)}
            placeholder="Notiz (z.B. '10 Sitzungen', 'Hausarzt')"
            style={{ marginTop:5, width:"100%", padding:"4px 7px",
              border:`1px solid ${T.border}`, borderRadius:5,
              fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.84rem",
              background:T.white, outline:"none", boxSizing:"border-box" }} />
        </div>
      )}
      <Btn variant="gold" onClick={beteiligterHinzufuegen} disabled={!gewaehlt}>
        ↓ Als {ROLLEN_LABEL[rolle]} übernehmen
      </Btn>
    </div>
  );

  // Beteiligte-Karte für eine Rolle (mini, wie Mandantenkachel)
  const BeteiligtenListe = ({ rolle }) => {
    const liste = beteiligte.filter(b => b.rolle === rolle);
    if (!liste.length) return null;
    return (
      <div style={{ gridColumn:"1/-1", display:"flex", flexDirection:"column", gap:"0.4rem", marginTop:"0.25rem" }}>
        {liste.map((b, i) => (
          <div key={b.id ?? `b_${i}`} style={{ display:"flex", alignItems:"flex-start",
            gap:"0.6rem", padding:"0.55rem 0.8rem",
            background:T.white, border:`1px solid ${T.border}`, borderRadius:7 }}>
            <span style={{ fontSize:"1rem", flexShrink:0, marginTop:1 }}>{ROLLEN_ICON[rolle]}</span>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem",
                fontWeight:600, color:T.text, display:"flex", alignItems:"center", gap:6, flexWrap:"wrap" }}>
                {b.name || <em style={{color:T.textFaint,fontWeight:400}}>Keine Adresse</em>}
                <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.72rem",
                  color:T.textFaint }}>#{b.adressnr}</span>
                <span style={{ fontSize:"0.68rem", padding:"1px 5px", borderRadius:8,
                  background: b.quelle==="wdm" ? "#f0fdf4" : "#f0f9ff",
                  color: b.quelle==="wdm" ? "#16a34a" : "#0369a1",
                  border:`1px solid ${b.quelle==="wdm" ? "#86efac" : "#bae6fd"}`,
                  fontFamily:"'IBM Plex Sans',sans-serif", fontWeight:600 }}>
                  {b.quelle?.toUpperCase()}
                </span>
              </div>
              {(b.strasse||b.ort) && (
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.79rem",
                  color:T.textMuted, marginTop:1 }}>
                  {[b.strasse, b.plz&&b.ort ? `${b.plz} ${b.ort}` : b.ort, b.telefon ? `☎ ${b.telefon}` : ""].filter(Boolean).join(" · ")}
                </div>
              )}
              <input value={b.notizen||""} placeholder="Notiz…"
                onChange={e => setBeteiligte(prev => prev.map(x => x.id===b.id ? {...x,notizen:e.target.value} : x))}
                onBlur={e => notizAktualisieren(b, e.target.value)}
                style={{ marginTop:3, width:"100%", border:"none",
                  borderBottom:`1px dashed ${T.border}`, background:"transparent", outline:"none",
                  fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.79rem",
                  color:T.textMuted, padding:"1px 0" }} />
            </div>
            <button onClick={() => beteiligterLoeschen(b)} title="Entfernen"
              style={{ background:"none", border:"none", cursor:"pointer",
                color:T.red, fontSize:"1rem", padding:"2px 4px", borderRadius:4,
                flexShrink:0, lineHeight:1 }}
              onMouseEnter={e=>e.currentTarget.style.background=T.redBg}
              onMouseLeave={e=>e.currentTarget.style.background="none"}>
              🗑
            </button>
          </div>
        ))}
      </div>
    );
  };

  return (
    <>
      {betLaden && (
        <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem",
          color:"#6b21a8", padding:"0.5rem 0", display:"flex", alignItems:"center", gap:8 }}>
          <span style={{ animation:"spin 0.8s linear infinite", display:"inline-block" }}>⟳</span>
          Lade Beteiligte aus RA-Micro…
        </div>
      )}

      {/* WDM-Daten-Banner */}
      {wdmPsDaten && (wdmPsDaten.felder_gefunden > 0 || wdmPsDaten.adressen_gefunden > 0) && (
        <div style={{ background:"#f5f3ff", border:"1.5px solid #a78bfa", borderRadius:9,
          padding:"0.85rem 1.1rem", display:"flex", alignItems:"flex-start", gap:10 }}>
          <span style={{ fontSize:"1.1rem", flexShrink:0 }}>📋</span>
          <div style={{ flex:1 }}>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem",
              fontWeight:700, color:"#6b21a8", marginBottom:4 }}>
              RA-Micro WDM: {wdmPsDaten.felder_gefunden} Felder
              {wdmPsDaten.adressen_gefunden > 0 && ` + ${wdmPsDaten.adressen_gefunden} Beteiligte`} gefunden
            </div>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem",
              color:"#7c3aed", display:"flex", flexWrap:"wrap", gap:"0.3rem 1rem" }}>
              {Object.entries(wdmPsDaten.textfelder || {}).map(([k,v]) => (
                <span key={k}>
                  <strong>{k}:</strong> {typeof v === "number" ? (v ? "Ja" : "Nein") : String(v)}
                </span>
              ))}
              {(wdmPsDaten.adressen || []).map((a,i) => (
                <span key={i}>
                  <strong>{ROLLEN_LABEL[a.rolle]}:</strong> {a.name || `#${a.adressnr}`}
                </span>
              ))}
            </div>
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:6, flexShrink:0 }}>
            <button onClick={uebernehmeWdmPs}
              style={{ padding:"5px 12px", background:"#7c3aed", color:"#fff",
                border:"none", borderRadius:6, fontFamily:"'IBM Plex Sans',sans-serif",
                fontSize:"0.82rem", fontWeight:600, cursor:"pointer", whiteSpace:"nowrap" }}>
              ↓ Alle übernehmen
            </button>
            <button onClick={() => setWdmPsDaten(null)}
              style={{ padding:"4px 12px", background:"transparent", color:"#6b21a8",
                border:"1px solid #a78bfa", borderRadius:6, fontFamily:"'IBM Plex Sans',sans-serif",
                fontSize:"0.82rem", cursor:"pointer" }}>
              Verwerfen
            </button>
          </div>
        </div>
      )}

      {/* ── Verletzungen & Heilbehandlung ────────────────────────── */}
      <Card>
        <CardHead title="Verletzungen & Heilbehandlung"
          action={
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              {akteId?.includes("/") && (
                <Btn size="sm" variant="secondary"
                  disabled={wdmPsLaden}
                  onClick={() => {
                    setWdmPsLaden(true);
                    apiPS.wdmLaden(akteId)
                      .then(d => {
                        if (d.felder_gefunden > 0 || d.adressen_gefunden > 0) {
                          setWdmPsDaten(d); // manueller Klick → immer Banner
                        } else {
                          setPsToast("RA-Micro: keine Personenschaden-Daten in WDM gefunden.");
                        }
                      })
                      .catch(() => setPsToast("⚠ WDM konnte nicht geladen werden."))
                      .finally(() => setWdmPsLaden(false));
                  }}>
                  {wdmPsLaden ? "…" : wdmPsDaten ? "🔍 WDM neu laden" : "🔍 RA-Micro WDM"}
                </Btn>
              )}
              {psChg && (
                <Btn variant="gold" onClick={savePsForm} disabled={psSaving}>
                  {psSaving ? "…" : "✓ Speichern"}
                </Btn>
              )}
            </div>
          }
        />
        <div style={{ padding:"0.5rem 1.4rem 1.4rem" }}>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"0 2rem" }}>

            <div style={{ gridColumn:"1/-1", marginBottom:"0.9rem" }}>
              <PsLabel>Art und Umfang der Verletzungen</PsLabel>
              <textarea value={psForm.verletzungen_text||""} onChange={e=>psUpd("verletzungen_text",e.target.value)} rows={3}
                style={{ width:"100%", padding:"7px 10px", border:`1.5px solid ${T.border}`, borderRadius:7,
                  fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.895rem", color:T.text,
                  background:T.surface, outline:"none", resize:"vertical", boxSizing:"border-box" }} />
            </div>

            {/* Krankenhaus */}
            <PsKlappSection label="🏥 Stationärer Krankenhausaufenthalt" field="krankenhaus_aufenthalt" form={psForm} upd={psUpd}
              addLabel="+ Krankenhaus" onAdd={() => oeffneSuche("krankenhaus")}>
              <PsRow label="Aufnahme (von)" field="krankenhaus_von" form={psForm} upd={psUpd} type="date" placeholder="TT.MM.JJJJ" />
              <PsRow label="Entlassung (bis, voraussichtl.)" field="krankenhaus_bis" form={psForm} upd={psUpd} type="date" placeholder="TT.MM.JJJJ" />
              <BeteiligtenListe rolle="krankenhaus" />
              {sucheRolle === "krankenhaus" && <SuchPanel rolle="krankenhaus" />}
            </PsKlappSection>

            {/* Krankschreibung */}
            <PsKlappSection label="📋 Krankgeschrieben" field="krankgeschrieben" form={psForm} upd={psUpd}>
              <PsRow label="Krank von" field="krank_von" form={psForm} upd={psUpd} type="date" placeholder="TT.MM.JJJJ" />
              <PsRow label="Krank bis (voraussichtl.)" field="krank_bis" form={psForm} upd={psUpd} type="date" placeholder="TT.MM.JJJJ" />
            </PsKlappSection>

            {/* Ärzte */}
            <div style={{ gridColumn:"1/-1", marginBottom:"1rem" }}>
              <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", fontWeight:700,
                color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.07em",
                marginBottom:"0.5rem", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                <span>🩺 Behandelnde Ärzte</span>
                <button onClick={() => oeffneSuche("arzt")}
                  style={{ background:T.goldPale, border:`1px solid ${T.gold}`, borderRadius:6,
                    padding:"3px 10px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem",
                    fontWeight:600, color:T.navy, cursor:"pointer" }}>
                  + Arzt
                </button>
              </div>
              <BeteiligtenListe rolle="arzt" />
              {sucheRolle === "arzt" && <SuchPanel rolle="arzt" />}
              {beteiligte.filter(b=>b.rolle==="arzt").length === 0 && sucheRolle !== "arzt" && (
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem",
                  color:T.textFaint, padding:"0.4rem 0" }}>
                  Noch keine Ärzte erfasst.
                </div>
              )}
            </div>

            {/* Physiotherapie */}
            <PsKlappSection label="🧘 Physiotherapie erforderlich" field="physiotherapie" form={psForm} upd={psUpd}
              addLabel="+ Physiotherapeut" onAdd={() => oeffneSuche("physiotherapeut")}>
              <PsRow label="Anzahl Sitzungen" field="physiotherapie_anzahl" form={psForm} upd={psUpd} type="number" />
              <BeteiligtenListe rolle="physiotherapeut" />
              {sucheRolle === "physiotherapeut" && <SuchPanel rolle="physiotherapeut" />}
            </PsKlappSection>

            {/* Heilbehandlung + Dauerfolgen */}
            <PsSection label="⚕️ Heilbehandlung">
              <PsCheckRow label="Heilbehandlung abgeschlossen" field="heilbehandlung_abgeschlossen" form={psForm} upd={psUpd} />
              {psForm.heilbehandlung_abgeschlossen ? (
                <PsRow label="Ende der Heilbehandlung" field="heilbehandlung_ende" form={psForm} upd={psUpd} type="date" placeholder="TT.MM.JJJJ" />
              ) : null}
              <PsCheckRow label="Schweigepflicht-Entbindung" field="schweigepflicht_entbindung" form={psForm} upd={psUpd} />
            </PsSection>

            <PsKlappSection label="⚠️ Dauerfolgen / Dauerschäden" field="dauerfolgen" form={psForm} upd={psUpd}>
              <div style={{ gridColumn:"1/-1" }}>
                <PsLabel>Beschreibung der Dauerfolgen</PsLabel>
                <textarea value={psForm.dauerfolgen_text||""} onChange={e=>psUpd("dauerfolgen_text",e.target.value)} rows={3}
                  style={{ width:"100%", padding:"6px 9px", border:`1.5px solid ${T.border}`, borderRadius:6,
                    fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:T.text,
                    background:T.surface, outline:"none", resize:"vertical", boxSizing:"border-box" }} />
              </div>
            </PsKlappSection>

            {/* Arbeitgeber */}
            <div style={{ gridColumn:"1/-1", marginBottom:"1rem" }}>
              <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", fontWeight:700,
                color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.07em",
                marginBottom:"0.5rem", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                <span>🏢 Arbeitgeber</span>
                <button onClick={() => oeffneSuche("arbeitgeber")}
                  style={{ background:T.goldPale, border:`1px solid ${T.gold}`, borderRadius:6,
                    padding:"3px 10px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem",
                    fontWeight:600, color:T.navy, cursor:"pointer" }}>
                  + Arbeitgeber
                </button>
              </div>
              <BeteiligtenListe rolle="arbeitgeber" />
              {sucheRolle === "arbeitgeber" && <SuchPanel rolle="arbeitgeber" />}
              <PsCheckRow label="Selbstständig (kein Arbeitgeber)" field="selbststaendig" form={psForm} upd={psUpd} />
              {!psForm.selbststaendig && (
                <PsRow label="Monatl. Nettoeinkommen (€)" field="nettoeinkommen_monatlich" form={psForm} upd={psUpd} type="number" />
              )}
            </div>

            {/* Krankenkasse */}
            <div style={{ gridColumn:"1/-1", marginBottom:"1rem" }}>
              <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", fontWeight:700,
                color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.07em",
                marginBottom:"0.5rem", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                <span>💊 Krankenkasse</span>
                <button onClick={() => oeffneSuche("krankenkasse")}
                  style={{ background:T.goldPale, border:`1px solid ${T.gold}`, borderRadius:6,
                    padding:"3px 10px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem",
                    fontWeight:600, color:T.navy, cursor:"pointer" }}>
                  + Krankenkasse
                </button>
              </div>
              <BeteiligtenListe rolle="krankenkasse" />
              {sucheRolle === "krankenkasse" && <SuchPanel rolle="krankenkasse" />}
            </div>

            {/* Berufsgenossenschaft */}
            <PsKlappSection label="🏭 Berufsunfall / Wegeunfall" field="berufsunfall" form={psForm} upd={psUpd}
              addLabel="+ Berufsgenossenschaft" onAdd={() => oeffneSuche("bg")}>
              <BeteiligtenListe rolle="bg" />
              {sucheRolle === "bg" && <SuchPanel rolle="bg" />}
              <PsRow label="BG Name (falls nicht in RA-Micro)" field="bg_name" form={psForm} upd={psUpd} />
              <PsCheckRow label="Gesetzlich rentenversichert" field="rentenversichert" form={psForm} upd={psUpd} />
              <PsRow label="Rentenversicherung (Anstalt)" field="rentenversicherung_name" form={psForm} upd={psUpd} />
            </PsKlappSection>

            {/* Persönliche Daten */}
            <PsSection label="👤 Persönliche Daten">
              <PsRow label="Familienstand" field="familienstand" form={psForm} upd={psUpd} />
              <PsRow label="Kinder (Anzahl)" field="kinder_anzahl" form={psForm} upd={psUpd} type="number" />
              <PsRow label="Kinder Alter (z.B. 11, 10, 6)" field="kinder_alter_text" form={psForm} upd={psUpd} />
              <PsRow label="Geburtsdatum" field="geburtsdatum" form={psForm} upd={psUpd} type="date" placeholder="TT.MM.JJJJ" />
              <PsRow label="Beruf" field="beruf" form={psForm} upd={psUpd} />
            </PsSection>

            <div style={{ gridColumn:"1/-1", marginTop:"0.5rem" }}>
              <PsLabel>Interne Notizen</PsLabel>
              <textarea value={psForm.notizen||""} onChange={e=>psUpd("notizen",e.target.value)} rows={3}
                style={{ width:"100%", padding:"7px 10px", border:`1.5px solid ${T.border}`, borderRadius:7,
                  fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.895rem", color:T.text,
                  background:T.surface, outline:"none", resize:"vertical", boxSizing:"border-box" }} />
            </div>
          </div>
        </div>
      </Card>
    </>
  );
}

/* Hilfkomponenten für Personenschaden-Tab */
/**
 * DateInput – Datumseingabe mit nativem Browser-Datepicker.
 * Speichert intern als TT.MM.JJJJ (wie im Fragebogen),
 * konvertiert für den <input type="date"> nach YYYY-MM-DD.
 */
const DateInput = ({ value, onChange, placeholder = "TT.MM.JJJJ", style = {} }) => {
  // TT.MM.JJJJ → YYYY-MM-DD für input[type=date]
  const toISO = (v) => {
    if (!v) return "";
    const m = String(v).match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})$/);
    if (m) return `${m[3]}-${m[2].padStart(2,"0")}-${m[1].padStart(2,"0")}`;
    // Bereits ISO-Format?
    if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v;
    return "";
  };
  // YYYY-MM-DD → TT.MM.JJJJ
  const fromISO = (v) => {
    if (!v) return "";
    const m = v.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    return m ? `${m[3]}.${m[2]}.${m[1]}` : v;
  };

  return (
    <input
      type="date"
      value={toISO(value)}
      onChange={e => onChange(fromISO(e.target.value))}
      placeholder={placeholder}
      style={{
        width:"100%", padding:"6px 9px",
        border:`1.5px solid ${T.border}`, borderRadius:6,
        fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem",
        color: value ? T.text : T.textFaint,
        background:T.white, outline:"none", boxSizing:"border-box",
        cursor:"pointer",
        ...style
      }}
    />
  );
};

const PsLabel = ({children}) => (
  <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600,
    color:"#64748b", marginBottom:3, textTransform:"uppercase", letterSpacing:"0.05em" }}>
    {children}
  </div>
);
const PsSection = ({label, children}) => (
  <div style={{ marginBottom:"1.25rem" }}>
    <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", fontWeight:700,
      color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.07em",
      marginBottom:"0.6rem", paddingBottom:"4px", borderBottom:`1px solid ${T.borderSoft}` }}>
      {label}
    </div>
    <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"0.5rem 1.5rem" }}>{children}</div>
  </div>
);
const PsRow = ({label, field, form, upd, type="text", placeholder=""}) => (
  <div>
    <PsLabel>{label}</PsLabel>
    {type === "date" ? (
      <DateInput value={form[field]||""} onChange={v => upd(field, v)} placeholder={placeholder} />
    ) : (
      <input type={type} value={form[field]||""} onChange={e=>upd(field, type==="number" ? (parseFloat(e.target.value)||0) : e.target.value)}
        placeholder={placeholder}
        style={{ width:"100%", padding:"6px 9px", border:`1.5px solid ${T.border}`, borderRadius:6,
          fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:T.text,
          background:T.white, outline:"none", boxSizing:"border-box" }} />
    )}
  </div>
);
const PsCheckRow = ({label, field, form, upd}) => (
  <div style={{ display:"flex", alignItems:"center", gap:8, cursor:"pointer" }} onClick={()=>upd(field, form[field] ? 0 : 1)}>
    <div style={{ width:18, height:18, borderRadius:4, border:`2px solid ${form[field] ? T.navy : T.border}`,
      background: form[field] ? T.navy : "transparent", flexShrink:0, display:"flex", alignItems:"center", justifyContent:"center" }}>
      {form[field] ? <span style={{ color:"#fff", fontSize:11, lineHeight:1 }}>✓</span> : null}
    </div>
    <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:T.textMid }}>{label}</span>
  </div>
);

// Klapp-Kachel: zeigt Inhalt nur wenn aktiv (Boolean-Feld steuert es)
const PsKlappSection = ({label, field, form, upd, children, addLabel, onAdd}) => {
  const aktiv = !!form[field];
  return (
    <div style={{ gridColumn:"1/-1", marginBottom:"1rem" }}>
      {/* Header-Zeile mit Toggle */}
      <div
        onClick={() => upd(field, aktiv ? 0 : 1)}
        style={{ display:"flex", alignItems:"center", gap:10, cursor:"pointer",
          padding:"0.6rem 0.9rem", borderRadius:8,
          background: aktiv ? T.blueBg : T.surface,
          border:`1.5px solid ${aktiv ? T.blue+"55" : T.border}`,
          transition:"all 0.15s", userSelect:"none" }}>
        {/* Checkbox-ähnlicher Toggle */}
        <div style={{ width:20, height:20, borderRadius:5, flexShrink:0,
          border:`2px solid ${aktiv ? T.navy : T.border}`,
          background: aktiv ? T.navy : "transparent",
          display:"flex", alignItems:"center", justifyContent:"center" }}>
          {aktiv && <span style={{ color:"#fff", fontSize:12, lineHeight:1 }}>✓</span>}
        </div>
        <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.895rem",
          fontWeight:600, color: aktiv ? T.navy : T.textMid }}>
          {label}
        </span>
        <div style={{ marginLeft:"auto", display:"flex", alignItems:"center", gap:8 }}>
          {aktiv && onAdd && (
            <button onClick={e => { e.stopPropagation(); onAdd(); }}
              style={{ background:"#fefce8", border:"1px solid #fbbf24", borderRadius:6,
                padding:"2px 9px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem",
                fontWeight:600, color:"#92400e", cursor:"pointer" }}>
              {addLabel || "+ Beteiligter"}
            </button>
          )}
          <span style={{ color:T.textFaint, fontSize:"0.85rem" }}>
            {aktiv ? "▲" : "▼"}
          </span>
        </div>
      </div>
      {/* Inhalt – nur wenn aktiv */}
      {aktiv && (
        <div style={{ marginTop:"0.6rem", padding:"0.75rem 1rem",
          background:T.surface, border:`1px solid ${T.border}`,
          borderRadius:8, display:"grid",
          gridTemplateColumns:"1fr 1fr", gap:"0.5rem 1.5rem" }}>
          {children}
        </div>
      )}
    </div>
  );
};

/* ══════════════════════════════════════════════════════════════
   SECTION: REGULIERUNGEN
══════════════════════════════════════════════════════════════ */
/* ══════════════════════════════════════════════════════════════
   HILFSFUNKTIONEN REGULIERUNG
══════════════════════════════════════════════════════════════ */

const POSITION_LABELS_FE = {
  reparaturkosten: "Reparaturkosten", wiederbeschaffung: "Wiederbeschaffung",
  restwert: "Restwert", wertminderung: "Wertminderung",
  nutzungsausfall: "Nutzungsausfall", mietwagenkosten: "Mietwagenkosten",
  sv_kosten: "SV-Kosten", abschleppkosten: "Abschleppkosten",
  standkosten: "Standkosten", anabmeldekosten: "An-/Abmeldekosten",
  schmerzensgeld: "Schmerzensgeld", sonstiges: "Sonstiges",
  // PDF-Parser-Arten (werden via position_key gesetzt)
  reparatur_brutto: "Reparaturkosten (brutto)", reparatur_netto: "Reparaturkosten (netto)",
  wbw: "Wiederbeschaffungswert", wbw_netto: "WBW (netto)", wbw_brutto: "WBW (brutto)",
  fahrzeugschaden: "Fahrzeugschaden", kostenpauschale: "Kostenpauschale",
  ra_gebuehren: "RA-Gebühren", mwst_abzug: "Abzug MwSt.", pruefbericht_abzug: "Abzug Prüfbericht",
};

// Bug 5: Restwert ist ein Abzugsposten – höherer Wert der Versicherung = schlechter für Mandant
const POSITION_IST_ABZUG = { restwert: true };
const positionKuerzungBetrag = (pos) => {
  if (POSITION_IST_ABZUG[pos.position_key]) {
    // Versicherung setzt höheren Restwert an → Mehrbelastung für Mandant
    const reguliert = parseFloat(pos.betrag_reguliert) || 0;
    const gefordert = parseFloat(pos.betrag_gefordert) || 0;
    return Math.round((reguliert - gefordert) * 100) / 100; // positiv = Mehrbelastung
  }
  const gefordert = parseFloat(pos.betrag_gefordert) || 0;
  const reguliert = parseFloat(pos.betrag_reguliert) || 0;
  return Math.round((gefordert - reguliert) * 100) / 100;
};

const POSITION_KEYS_FE = Object.keys(POSITION_LABELS_FE);

/* Leere Positionen-Vorlage aus Schadenpositionen befüllen */
function positionenVorlage(schaden) {
  // Abrechnungsart bestimmt welche Fahrzeugschaden-Positionen relevant sind
  const art = schaden?.abrechnungsart || null;
  const repN  = parseFloat(schaden?.rep_gutachten_netto || schaden?.reparaturkosten || 0);
  const repRN = parseFloat(schaden?.rep_rechnung_netto || 0);
  const effRep = repRN > 0 ? repRN : repN;
  const wbw   = parseFloat(schaden?.wiederbeschaffung || 0);
  const rst   = parseFloat(schaden?.restwert || 0);
  const nettoFzg = wbw - rst;
  const ist130 = repRN > 0 && wbw > 0 && repRN > nettoFzg && repRN <= 1.3 * wbw;

  // Fahrzeugschaden-Positions-Logik (identisch zum Generator)
  let fahrzeugKeys = [];
  if (art === "totalschaden" || (art == null && wbw > 0 && (effRep === 0 || (!ist130 && effRep > nettoFzg)))) {
    // Totalschaden: WBW − Restwert
    fahrzeugKeys = ["wbw", "restwert"];
  } else if (art === "konkret" || (art == null && repRN > 0)) {
    // Konkrete Abrechnung (inkl. 130%-Fall): Rechnungsbetrag
    fahrzeugKeys = ["rep_rechnung_netto"];
    if (ist130) fahrzeugKeys.push("rep_rechnung_brutto"); // nur informativ
  } else if (art === "fiktiv" || (art == null && repN > 0)) {
    // Fiktive Abrechnung: Gutachtenbetrag netto
    fahrzeugKeys = ["rep_gutachten_netto"];
  } else if (wbw > 0) {
    // Fallback: WBW vorhanden, keine Reparaturkosten → Totalschaden
    fahrzeugKeys = ["wbw", "restwert"];
  }

  // Weitere Standard-Positionen (ohne Fahrzeugschaden-Positionen)
  const WEITERE_BASIS = ["sv_kosten","wertminderung","nutzungsausfall","kostenpauschale"];

  // Alle Positions-Keys die > 0 sind (außer Fahrzeug-Keys die wir schon haben)
  const fahrzeugKeySet = new Set(fahrzeugKeys);
  const allePositivenKeys = POSITION_KEYS_FE.filter(k =>
    !fahrzeugKeySet.has(k) && (schaden?.[k] || 0) > 0
  );

  const keys = [...new Set([...fahrzeugKeys, ...WEITERE_BASIS, ...allePositivenKeys])];

  // Betrag je Position: für rep_rechnung_netto → effRep, für wbw/restwert direkt
  const getBetrag = (k) => {
    if (k === "rep_rechnung_netto") return repRN;
    if (k === "rep_gutachten_netto") return repN;
    if (k === "restwert") return rst; // Abzugsposten – positiver Betrag, Abzug-Logik in PositionenTabelle
    return parseFloat(schaden?.[k]) || 0;
  };

  return keys.map(k => ({
    position_key:          k,
    betrag_gefordert:      getBetrag(k),
    betrag_reguliert:      getBetrag(k),
    kuerzungsart_id:       null,
    kuerzung_freitext:     "",
    fuer_klage_vorgemerkt: false,
  })).filter(p => p.betrag_gefordert > 0 || ["wbw","restwert","rep_gutachten_netto","rep_rechnung_netto"].includes(p.position_key));
}

/* ══════════════════════════════════════════════════════════════
   POSITIONS-TABELLE innerhalb einer Abrechnung
══════════════════════════════════════════════════════════════ */
function PositionenTabelle({ positionen, kuerzungsarten, akteId, abid, onUpdate, readOnly }) {
  const hatKuerzung = positionen.some(p => p.kuerzung_betrag > 0);

  const toggleKlage = async (pos) => {
    const neu = !pos.fuer_klage_vorgemerkt;
    try {
      await apiAbrechnungen.updatePos(akteId, abid, pos.id, { fuer_klage_vorgemerkt: neu });
    } catch { /* Demo */ }
    onUpdate(pos.id, { fuer_klage_vorgemerkt: neu });
  };

  const setKuerzungsart = async (pos, kid) => {
    try {
      await apiAbrechnungen.updatePos(akteId, abid, pos.id, { kuerzungsart_id: kid || null });
    } catch { /* Demo */ }
    const art = kid ? kuerzungsarten.find(k => k.id === parseInt(kid)) : null;
    onUpdate(pos.id, {
      kuerzungsart_id: kid ? parseInt(kid) : null,
      kuerzungsart_bezeichnung: art?.bezeichnung || null,
    });
  };

  if (!positionen.length) return (
    <div style={{ padding:"1rem", color:T.textFaint, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.9rem" }}>
      Keine Positionen erfasst.
    </div>
  );

  return (
    <div style={{ overflowX:"auto" }}>
      <table style={{ width:"100%", borderCollapse:"collapse", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem" }}>
        <thead>
          <tr style={{ background:T.surface, borderBottom:`1px solid ${T.border}` }}>
            {["Position","Gefordert","Reguliert","Kürzung","Kürzungsart","Klage"].map(h => (
              <th key={h} style={{ padding:"7px 12px", textAlign:h==="Position"?"left":"right", fontWeight:600, color:T.textMuted, fontSize:"0.78rem", textTransform:"uppercase", letterSpacing:"0.05em", whiteSpace:"nowrap" }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {positionen.map((pos, i) => {
            const kuerzung = positionKuerzungBetrag(pos);
            const istAbzug = POSITION_IST_ABZUG[pos.position_key];
            const isLast = i === positionen.length - 1;
            return (
              <tr key={pos.id ?? i} style={{ borderBottom:isLast?"none":`1px solid ${T.border}`, background:pos.fuer_klage_vorgemerkt?"rgba(200,168,75,0.06)":"transparent" }}>
                <td style={{ padding:"8px 12px", color:T.text, fontWeight:500 }}>
                  {POSITION_LABELS_FE[pos.position_key] || pos.position_key}
                  {pos.sv_stellungnahme_ausstehend && (
                    <span style={{ marginLeft:6, fontSize:"0.72rem", background:T.amberBg, color:T.amber, borderRadius:4, padding:"1px 5px" }}>SV ausstehend</span>
                  )}
                </td>
                <td style={{ padding:"8px 12px", textAlign:"right", fontFamily:"'IBM Plex Mono',monospace", color:T.textMid }}>
                  {fmtEuro(pos.betrag_gefordert)}
                </td>
                <td style={{ padding:"8px 12px", textAlign:"right", fontFamily:"'IBM Plex Mono',monospace", color:T.green, fontWeight:600 }}>
                  {fmtEuro(pos.betrag_reguliert)}
                </td>
                <td style={{ padding:"8px 12px", textAlign:"right", fontFamily:"'IBM Plex Mono',monospace", color:kuerzung>0?T.red:T.textFaint, fontWeight:kuerzung>0?600:400 }}>
                  {kuerzung > 0
                    ? `${istAbzug ? "+" : "−"}${fmtEuro(kuerzung)}`
                    : "—"}
                </td>
                <td style={{ padding:"8px 12px", minWidth:180 }}>
                  {kuerzung > 0 && !readOnly ? (
                    <select
                      value={pos.kuerzungsart_id || ""}
                      onChange={e => setKuerzungsart(pos, e.target.value)}
                      style={{ width:"100%", padding:"4px 6px", border:`1px solid ${T.border}`, borderRadius:5, fontSize:"0.82rem", background:T.surface, color:pos.kuerzungsart_id?T.text:T.textFaint, cursor:"pointer" }}
                    >
                      <option value="">— Kürzungsart wählen —</option>
                      {kuerzungsarten.map(k => (
                        <option key={k.id} value={k.id}>{k.bezeichnung}</option>
                      ))}
                    </select>
                  ) : pos.kuerzungsart_bezeichnung ? (
                    <span style={{ fontSize:"0.82rem", color:T.textMid }}>{pos.kuerzungsart_bezeichnung}</span>
                  ) : (
                    <span style={{ color:T.textFaint }}>—</span>
                  )}
                </td>
                <td style={{ padding:"8px 12px", textAlign:"right" }}>
                  {kuerzung > 0 && (
                    <button
                      onClick={() => !readOnly && toggleKlage(pos)}
                      title={pos.fuer_klage_vorgemerkt ? "Aus Klage entfernen" : "Für Klage vormerken"}
                      style={{ background:pos.fuer_klage_vorgemerkt?T.gold:"transparent", border:`1px solid ${pos.fuer_klage_vorgemerkt?T.gold:T.border}`, borderRadius:5, padding:"3px 8px", fontSize:"0.78rem", color:pos.fuer_klage_vorgemerkt?T.white:T.textMuted, cursor:readOnly?"default":"pointer", fontFamily:"'IBM Plex Sans',sans-serif", fontWeight:600, transition:"all 0.15s" }}
                    >
                      {pos.fuer_klage_vorgemerkt ? "✓ Klage" : "Klage"}
                    </button>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
        <tfoot>
          <tr style={{ background:T.surface, borderTop:`2px solid ${T.border}` }}>
            <td style={{ padding:"8px 12px", fontWeight:700, color:T.text, fontFamily:"'IBM Plex Sans',sans-serif" }}>Gesamt</td>
            <td style={{ padding:"8px 12px", textAlign:"right", fontFamily:"'IBM Plex Mono',monospace", fontWeight:700, color:T.text }}>
              {fmtEuro(positionen.reduce((s,p) => s + p.betrag_gefordert, 0))}
            </td>
            <td style={{ padding:"8px 12px", textAlign:"right", fontFamily:"'IBM Plex Mono',monospace", fontWeight:700, color:T.green }}>
              {fmtEuro(positionen.reduce((s,p) => s + p.betrag_reguliert, 0))}
            </td>
            <td style={{ padding:"8px 12px", textAlign:"right", fontFamily:"'IBM Plex Mono',monospace", fontWeight:700, color:T.red }}>
              {positionen.reduce((s,p) => s + positionKuerzungBetrag(p), 0) > 0
                ? `−${fmtEuro(positionen.reduce((s,p) => s + positionKuerzungBetrag(p), 0))}`
                : "—"}
            </td>
            <td colSpan={2} />
          </tr>
        </tfoot>
      </table>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   PDF-IMPORT: VERSICHERUNGS-PDF HOCHLADEN + VORSCHAU
══════════════════════════════════════════════════════════════ */
const ART_LABEL = {
  reparatur_brutto:   "Reparaturkosten (brutto)",
  reparatur_netto:    "Reparaturkosten (netto)",
  reparatur_fiktiv:   "Reparaturkosten (fiktiv)",
  sv_kosten:          "Sachverständigenkosten",
  wbw:                "Wiederbeschaffungswert",
  wbw_netto:          "Wiederbeschaffungswert (netto)",
  wbw_brutto:         "Wiederbeschaffungswert (brutto)",
  restwert:           "Restwert",
  fahrzeugschaden:    "Fahrzeugschaden",
  kostenpauschale:    "Kostenpauschale",
  wertminderung:      "Wertminderung",
  ra_gebuehren:       "Rechtsanwaltsgebühren",
  mwst_abzug:         "Abzug MwSt.",
  pruefbericht_abzug: "Abzug Prüfbericht",
};

const ABRECHNUNG_ART_LABEL = {
  reparatur_fiktiv:   "Reparatur fiktiv",
  reparatur_konkret:  "Reparatur konkret",
  totalschaden:       "Totalschaden",
  unbekannt:          "Unbekannt",
};

function PdfImportDialog({ akteId, kuerzungsarten, schaden, onImport, onSavePruefbericht, onCancel, dispatch }) {
  const [phase, setPhase]     = useState("upload");   // upload | loading | preview | error
  const [ergebnis, setErg]    = useState(null);
  const [fehler, setFehler]   = useState("");
  const [dateiname, setDn]    = useState("");
  const fileRef               = useRef();

  // Übernahme-State: welche Positionen soll das Formular vorab ausfüllen?
  const [selectedPos, setSelPos] = useState({});

  const handleDatei = async (datei) => {
    if (!datei) return;
    setDn(datei.name);
    setPhase("loading");
    setFehler("");
    try {
      const res = await apiParsePdf.parse(akteId, datei);
      setErg(res.ergebnis);
      // Alle Positionen standardmäßig ausgewählt
      const sel = {};
      (res.ergebnis?.positionen || []).forEach((p, i) => { sel[i] = true; });
      setSelPos(sel);
      setPhase("preview");
      // Chronik sofort aktualisieren – Backend hat bereits logge_aktivitaet geschrieben
      if (dispatch) {
        try {
          const aktData = await apiAkten.aktivitaeten(akteId);
          if (aktData?.aktivitaeten) {
            dispatch({ type: "SET_AKTIVITAETEN", akteId, aktivitaeten: aktData.aktivitaeten });
          }
        } catch { /* Chronik-Refresh nicht kritisch */ }
      }
    } catch (e) {
      setFehler(e.message || "Unbekannter Fehler");
      setPhase("error");
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const f = e.dataTransfer.files[0];
    if (f?.name.toLowerCase().endsWith(".pdf")) handleDatei(f);
  };

  // Aus dem Parse-Ergebnis ein Abrechnungs-Formular vorbelegen
  const handleUebernehmen = () => {
    if (!ergebnis) return;
    const rawPos = (ergebnis.positionen || []).filter((_, i) => selectedPos[i]);
    onImport({
      versicherung: ergebnis.versicherer      || "",
      referenz_nr:  ergebnis.schadennummer    || "",
      datum:        ergebnis.schreibdatum     || "",
      positionen:   rawPos,   // _mapPdfPos macht das Mapping im AbrechnungFormular
    });
  };

  // Mapping von Parser-Art → Formular-Art
  function artToFormArt(art) {
    const MAP = {
      reparatur_brutto:  "reparaturkosten",
      reparatur_netto:   "reparaturkosten",
      sv_kosten:         "sv_kosten",
      wbw:               "wiederbeschaffungswert",
      wbw_netto:         "wiederbeschaffungswert",
      wbw_brutto:        "wiederbeschaffungswert",
      restwert:          "restwert",
      fahrzeugschaden:   "fahrzeugschaden",
      kostenpauschale:   "kostenpauschale",
      wertminderung:     "wertminderung",
      ra_gebuehren:      "ra_gebuehren",
    };
    return MAP[art] || "sonstiges";
  }

  const konfidenzFarbe = (k) => k >= 0.8 ? T.green : k >= 0.5 ? T.amber : T.red;

  return (
    <div style={{
      background: T.surface, border: `1px solid ${T.border}`,
      borderRadius: 8, padding: 24, marginBottom: 16,
    }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20 }}>
        <h3 style={{ margin:0, color:T.gold, fontSize:16, fontWeight:600 }}>
          📄 Versicherungs-PDF importieren
        </h3>
        <Btn variant="ghost" size="sm" onClick={onCancel}>✕</Btn>
      </div>

      {/* ── Phase: Upload ── */}
      {phase === "upload" && (
        <div
          onDrop={handleDrop}
          onDragOver={e => e.preventDefault()}
          onClick={() => fileRef.current?.click()}
          style={{
            border: `2px dashed ${T.border}`, borderRadius: 8,
            padding: "40px 24px", textAlign: "center",
            cursor: "pointer", color: T.textMuted,
            transition: "border-color .2s",
          }}
          onMouseEnter={e => e.currentTarget.style.borderColor = T.gold}
          onMouseLeave={e => e.currentTarget.style.borderColor = T.border}
        >
          <div style={{ fontSize: 36, marginBottom: 12 }}>📂</div>
          <div style={{ fontWeight: 600, color: T.text, marginBottom: 6 }}>
            PDF hierher ziehen oder klicken
          </div>
          <div style={{ fontSize: 13 }}>
            Abrechnungsschreiben oder Prüfbericht (max. 20 MB)
          </div>
          <input
            ref={fileRef} type="file" accept=".pdf"
            style={{ display:"none" }}
            onChange={e => handleDatei(e.target.files[0])}
          />
        </div>
      )}

      {/* ── Phase: Laden ── */}
      {phase === "loading" && (
        <div style={{ textAlign:"center", padding:"40px 0", color:T.textMuted }}>
          <div style={{ fontSize:32, marginBottom:12 }}>⏳</div>
          <div style={{ fontWeight:600, color:T.text }}>{dateiname}</div>
          <div style={{ marginTop:8 }}>Analysiere PDF…</div>
        </div>
      )}

      {/* ── Phase: Fehler ── */}
      {phase === "error" && (
        <div style={{ padding:16, background:"#2a1515", borderRadius:6, color:T.red }}>
          <strong>Fehler:</strong> {fehler}
          <div style={{ marginTop:12 }}>
            <Btn size="sm" onClick={() => setPhase("upload")}>Erneut versuchen</Btn>
          </div>
        </div>
      )}

      {/* ── Phase: Vorschau ── */}
      {phase === "preview" && ergebnis && (
        <div>
          {/* Metadaten-Zeile */}
          <div style={{
            display:"flex", gap:12, flexWrap:"wrap", marginBottom:16,
            padding:"12px 16px", background:T.bg, borderRadius:6,
          }}>
            <span style={{ color:T.textMuted, fontSize:13 }}>
              <strong style={{ color:T.text }}>
                {ergebnis.versicherer || "Versicherer unbekannt"}
              </strong>
            </span>
            {ergebnis.schadennummer && (
              <span style={{ fontSize:13, color:T.textMuted }}>
                Schaden-Nr.: <strong style={{ color:T.text, fontFamily:"monospace" }}>
                  {ergebnis.schadennummer}
                </strong>
              </span>
            )}
            {ergebnis.schreibdatum && (
              <span style={{ fontSize:13, color:T.textMuted }}>
                Datum: <strong style={{ color:T.text }}>{ergebnis.schreibdatum}</strong>
              </span>
            )}
            {ergebnis.abrechnungsart && ergebnis.abrechnungsart !== "unbekannt" && (
              <span style={{
                fontSize:12, padding:"2px 8px", borderRadius:4,
                background:T.surface, border:`1px solid ${T.border}`,
                color:T.gold, fontWeight:600,
              }}>
                {ABRECHNUNG_ART_LABEL[ergebnis.abrechnungsart] || ergebnis.abrechnungsart}
              </span>
            )}
            <span style={{ marginLeft:"auto", fontSize:12, color:konfidenzFarbe(ergebnis.parse_konfidenz) }}>
              Konfidenz: {Math.round((ergebnis.parse_konfidenz || 0) * 100)}%
            </span>
          </div>

          {/* Warnungen */}
          {(ergebnis.warnungen || []).length > 0 && (
            <div style={{ background:"#2a2200", borderRadius:6, padding:"10px 14px", marginBottom:12, color:T.amber, fontSize:13 }}>
              {ergebnis.warnungen.map((w, i) => <div key={i}>⚠ {w}</div>)}
            </div>
          )}

          {/* Dokumenttyp-spezifische Ansicht */}
          {ergebnis.dokumenttyp === "abrechnungsschreiben" && (
            <AbrechnungVorschau
              ergebnis={ergebnis}
              selectedPos={selectedPos}
              setSelPos={setSelPos}
            />
          )}
          {ergebnis.dokumenttyp === "pruefbericht" && (
            <PruefberichtVorschau ergebnis={ergebnis} />
          )}
          {ergebnis.dokumenttyp === "unbekannt" && (
            <div style={{ color:T.textMuted, padding:16, textAlign:"center" }}>
              Dokumenttyp konnte nicht erkannt werden. Bitte manuell erfassen.
            </div>
          )}

          {/* Aktions-Leiste */}
          <div style={{ display:"flex", gap:8, marginTop:16, paddingTop:16, borderTop:`1px solid ${T.border}` }}>
            {ergebnis.dokumenttyp === "abrechnungsschreiben" && (
              <Btn onClick={handleUebernehmen}>
                ✓ Ausgewählte Positionen übernehmen
              </Btn>
            )}
            {ergebnis.dokumenttyp === "pruefbericht" && onSavePruefbericht && (
              <Btn onClick={() => {
                const rw = ergebnis.referenzwerkstatt;
                onSavePruefbericht({
                  pruefdienstleister:          ergebnis.pruefdienstleister || ergebnis.versicherer_kuerzel || "",
                  vorgangsnummer:              ergebnis.vorgangsnummer || "",
                  datum:                       ergebnis.schreibdatum || "",
                  schadennummer:               ergebnis.schadennummer || "",
                  reparaturkosten_vor_pruefung: ergebnis.reparaturkosten_netto_vor_pruefung,
                  abzug_technisch:             ergebnis.abzug_technisch,
                  abzug_werkstattalternative:  ergebnis.abzug_werkstattalternative,
                  abzug_gesamt:                ergebnis.abzug_gesamt,
                  reparaturkosten_nach_pruefung: ergebnis.reparaturkosten_nach_pruefung,
                  referenzwerkstatt_name:      rw?.name || "",
                  referenzwerkstatt_adresse:   rw?.adresse || "",
                  referenzwerkstatt_entfernung: rw?.entfernung_km,
                  ist_image_pdf:               ergebnis.ist_image_pdf || false,
                  fahrzeug_hersteller:         ergebnis.fahrzeug?.hersteller || "",
                  fahrzeug_typ:                ergebnis.fahrzeug?.typ || "",
                  fahrzeug_kennzeichen:        ergebnis.fahrzeug?.kennzeichen || "",
                });
                onCancel();
              }}>
                💾 Prüfbericht speichern
              </Btn>
            )}
            <Btn variant="secondary" onClick={() => { setPhase("upload"); setErg(null); }}>
              Andere Datei
            </Btn>
            <Btn variant="ghost" onClick={onCancel} style={{ marginLeft:"auto" }}>
              Abbrechen
            </Btn>
          </div>
        </div>
      )}
    </div>
  );
}

function AbrechnungVorschau({ ergebnis, selectedPos, setSelPos }) {
  const positionen = ergebnis.positionen || [];
  const zahlungen  = ergebnis.zahlungen  || [];

  return (
    <div>
      {/* Positionen */}
      {positionen.length > 0 ? (
        <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13, marginBottom:12 }}>
          <thead>
            <tr style={{ background:T.surface }}>
              <th style={{ padding:"8px 10px", textAlign:"left", color:T.textMuted, fontWeight:500, width:32 }}></th>
              <th style={{ padding:"8px 10px", textAlign:"left", color:T.textMuted, fontWeight:500 }}>Position</th>
              <th style={{ padding:"8px 10px", textAlign:"right", color:T.textMuted, fontWeight:500 }}>Brutto</th>
              <th style={{ padding:"8px 10px", textAlign:"right", color:T.textMuted, fontWeight:500 }}>Netto</th>
              <th style={{ padding:"8px 10px", textAlign:"left", color:T.textMuted, fontWeight:500 }}>Hinweis</th>
            </tr>
          </thead>
          <tbody>
            {positionen.map((p, i) => (
              <tr key={i} style={{ borderTop:`1px solid ${T.border}` }}>
                <td style={{ padding:"8px 10px" }}>
                  <input
                    type="checkbox"
                    checked={!!selectedPos[i]}
                    onChange={e => setSelPos(s => ({ ...s, [i]: e.target.checked }))}
                    style={{ accentColor: T.gold }}
                  />
                </td>
                <td style={{ padding:"8px 10px", color:T.text }}>
                  {ART_LABEL[p.art] || p.art}
                </td>
                <td style={{ padding:"8px 10px", textAlign:"right", fontFamily:"monospace", color:T.textMuted }}>
                  {p.betrag_brutto != null ? fmtEuro(p.betrag_brutto) : "—"}
                </td>
                <td style={{ padding:"8px 10px", textAlign:"right", fontFamily:"monospace", fontWeight:600, color:T.text }}>
                  {p.betrag_netto != null ? fmtEuro(p.betrag_netto) : "—"}
                </td>
                <td style={{ padding:"8px 10px", color:T.textMuted, fontSize:12 }}>
                  {p.hinweis || ""}
                  {p.pruefbericht_abzug ? ` (PB-Abzug: −${fmtEuro(p.pruefbericht_abzug)})` : ""}
                </td>
              </tr>
            ))}
          </tbody>
          {ergebnis.gesamtbetrag && (
            <tfoot>
              <tr style={{ borderTop:`2px solid ${T.border}` }}>
                <td colSpan={3} style={{ padding:"8px 10px", textAlign:"right", color:T.textMuted, fontWeight:600 }}>
                  Gesamtbetrag:
                </td>
                <td style={{ padding:"8px 10px", textAlign:"right", fontFamily:"monospace", fontWeight:700, color:T.gold, fontSize:15 }}>
                  {fmtEuro(ergebnis.gesamtbetrag)}
                </td>
                <td />
              </tr>
            </tfoot>
          )}
        </table>
      ) : (
        <div style={{ color:T.textMuted, padding:12, textAlign:"center", fontSize:13 }}>
          Keine Positionen erkannt
        </div>
      )}

      {/* Zahlungen */}
      {zahlungen.length > 0 && (
        <div style={{ background:T.bg, borderRadius:6, padding:"10px 14px", marginTop:8 }}>
          <div style={{ fontSize:12, color:T.textMuted, fontWeight:600, marginBottom:6 }}>
            ZAHLUNGEN
          </div>
          {zahlungen.map((z, i) => (
            <div key={i} style={{ display:"flex", justifyContent:"space-between", fontSize:13, padding:"3px 0" }}>
              <span style={{ color:T.text }}>
                {z.empfaenger === "kanzlei" ? "An Kanzlei" :
                 z.empfaenger === "sv_buero" ? "An SV-Büro" : z.empfaenger}
                {z.datum ? ` (${z.datum})` : ""}
              </span>
              <span style={{ fontFamily:"monospace", fontWeight:600, color:T.green }}>
                {fmtEuro(z.betrag)}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PruefberichtVorschau({ ergebnis }) {
  const fz = ergebnis.fahrzeug || {};
  const rw = ergebnis.referenzwerkstatt;

  return (
    <div style={{ fontSize:13 }}>
      {/* Fahrzeug */}
      {(fz.hersteller || fz.kennzeichen) && (
        <div style={{ display:"flex", gap:16, marginBottom:12, padding:"10px 14px", background:T.bg, borderRadius:6 }}>
          {fz.hersteller && <span><span style={{ color:T.textMuted }}>Fahrzeug: </span><strong>{fz.hersteller} {fz.typ}</strong></span>}
          {fz.kennzeichen && <span><span style={{ color:T.textMuted }}>KZ: </span><strong>{fz.kennzeichen}</strong></span>}
          {fz.erstzulassung && <span><span style={{ color:T.textMuted }}>EZ: </span>{fz.erstzulassung}</span>}
        </div>
      )}

      {/* Prüfergebnis-Tabelle */}
      <table style={{ width:"100%", borderCollapse:"collapse", marginBottom:12 }}>
        <tbody>
          {[
            ["Reparaturkosten vor Prüfung (netto)", ergebnis.reparaturkosten_netto_vor_pruefung],
            ["Abzug technische Prüfung", ergebnis.abzug_technisch ? -ergebnis.abzug_technisch : null],
            ["Abzug Werkstattalternative", ergebnis.abzug_werkstattalternative ? -ergebnis.abzug_werkstattalternative : null],
            ["Abzug gesamt", ergebnis.abzug_gesamt ? -ergebnis.abzug_gesamt : null],
            ["Reparaturkosten nach Prüfung", ergebnis.reparaturkosten_nach_pruefung],
          ].filter(([,v]) => v != null).map(([label, val], i) => (
            <tr key={i} style={{ borderTop:`1px solid ${T.border}` }}>
              <td style={{ padding:"7px 10px", color:T.textMuted }}>{label}</td>
              <td style={{
                padding:"7px 10px", textAlign:"right", fontFamily:"monospace",
                fontWeight: label.includes("nach") ? 700 : 400,
                color: val < 0 ? T.red : label.includes("nach") ? T.green : T.text,
              }}>
                {val < 0 ? `−${fmtEuro(Math.abs(val))}` : fmtEuro(val)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Referenzwerkstatt */}
      {rw && (
        <div style={{ padding:"10px 14px", background:T.bg, borderRadius:6 }}>
          <div style={{ fontWeight:600, color:T.text, marginBottom:4 }}>Referenzwerkstatt</div>
          <div style={{ color:T.textMuted }}>{rw.name}</div>
          {rw.entfernung_km && <div style={{ color:T.textMuted }}>Entfernung: {rw.entfernung_km} km</div>}
          {rw.lohn_mechanik && (
            <div style={{ marginTop:6, display:"flex", gap:16, fontSize:12, color:T.textMuted }}>
              <span>Mechanik: {fmtEuro(rw.lohn_mechanik)}/Std.</span>
              {rw.lohn_lack && <span>Lack: {fmtEuro(rw.lohn_lack)}/Std.</span>}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* PDF-Positionen → Formular-Format (position_key + saubere Floats) */
function _mapPdfPos(pdfPositionen) {
  return pdfPositionen.map(p => {
    const betrag = Number(
      ((p.betrag_netto ?? p.betrag_brutto ?? p.betrag_gefordert ?? 0)).toFixed(2)
    );
    return {
      position_key:          p.art || p.position_key || "sonstiges",
      betrag_gefordert:      betrag,
      betrag_reguliert:      betrag,
      kuerzungsart_id:       null,
      kuerzung_freitext:     "",
      fuer_klage_vorgemerkt: false,
    };
  });
}

/* ══════════════════════════════════════════════════════════════
   FORMULAR: NEUES ABRECHNUNGSSCHREIBEN
══════════════════════════════════════════════════════════════ */
function AbrechnungFormular({ schaden, kuerzungsarten, akteId, onSave, onCancel, prefill = null }) {
  const [form, setForm] = useState({
    datum: "", versicherung: "", referenz_nr: "",
    haftungsart: "vollhaftung", haftungsquote: 100,
    haftungsbegruendung: "", notizen: "",
  });
  const [positionen, setPositionen] = useState(() => positionenVorlage(schaden));
  const [saving, setSaving]         = useState(false);
  const [showPdfImport, setShowPdf] = useState(false);

  // prefill aus PDF-Import anwenden
  useEffect(() => {
    if (!prefill) return;
    setForm(prev => ({
      ...prev,
      versicherung: prefill.versicherung || prev.versicherung,
      referenz_nr:  prefill.referenz_nr  || prev.referenz_nr,
      datum:        prefill.datum        || prev.datum,
    }));
    if (prefill.positionen?.length > 0) {
      setPositionen(_mapPdfPos(prefill.positionen));
    }
  }, [prefill]);

  const F = (k) => (v) => setForm(p => ({ ...p, [k]: v }));

  // Wird von internem PdfImportDialog aufgerufen
  const handlePdfImport = (importData) => {
    setForm(prev => ({
      ...prev,
      versicherung: importData.versicherung || prev.versicherung,
      referenz_nr:  importData.referenz_nr  || prev.referenz_nr,
      datum:        importData.datum        || prev.datum,
    }));
    if (importData.positionen?.length > 0) {
      setPositionen(_mapPdfPos(importData.positionen));
    }
    setShowPdf(false);
  };

  const updatePos = (idx, k, v) => {
    setPositionen(prev => prev.map((p, i) => i === idx ? { ...p, [k]: v } : p));
  };

  const save = async () => {
    if (!form.datum) { alert("Datum ist erforderlich."); return; }
    setSaving(true);
    const payload = {
      ...form,
      haftungsquote: parseFloat(form.haftungsquote) || 100,
      positionen: positionen.map(p => ({
        ...p,
        betrag_gefordert: Math.round((parseFloat(p.betrag_gefordert) || 0) * 100) / 100,
        betrag_reguliert: Math.round((parseFloat(p.betrag_reguliert) || 0) * 100) / 100,
      })).filter(p => {
        const g = Math.round((parseFloat(p.betrag_gefordert) || 0) * 100) / 100;
        const r = Math.round((parseFloat(p.betrag_reguliert) || 0) * 100) / 100;
        return g > 0 || r > 0;  // mindestens ein Wert muss gesetzt sein
      }),
    };
    try {
      const res = await apiAbrechnungen.erstelle(akteId, payload);
      onSave(res.abrechnung);
    } catch {
      // Demo-Modus: lokal speichern
      const demo = {
        id: Date.now(), akte_id: akteId, ...payload,
        gesamt_gefordert: Math.round(payload.positionen.reduce((s,p) => s + p.betrag_gefordert, 0) * 100) / 100,
        gesamt_reguliert: Math.round(payload.positionen.reduce((s,p) => s + p.betrag_reguliert, 0) * 100) / 100,
        gesamt_kuerzung:  Math.round(payload.positionen.reduce((s,p) => s + (p.betrag_gefordert - p.betrag_reguliert), 0) * 100) / 100,
        erfasst_am: new Date().toLocaleDateString("de-DE"),
        positionen: payload.positionen.map((p,i) => ({ ...p, id: Date.now() + i, kuerzungsart_bezeichnung: null })),
      };
      onSave(demo);
    }
    setSaving(false);
  };

  return (
    <div style={{ background:T.goldPale, border:`1px solid ${T.goldTrim}`, borderRadius:10, padding:"1.25rem 1.4rem", marginBottom:"1rem" }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"1rem" }}>
        <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", fontWeight:600, color:T.navy, textTransform:"uppercase", letterSpacing:"0.07em" }}>
          Neues Abrechnungsschreiben
        </div>
        <Btn size="sm" variant="secondary" onClick={() => setShowPdf(o => !o)}>
          {showPdfImport ? "↑ PDF-Import schließen" : "📄 Aus PDF importieren"}
        </Btn>
      </div>

      {/* PDF-Import-Dialog */}
      {showPdfImport && (
        <PdfImportDialog
          akteId={akteId}
          kuerzungsarten={kuerzungsarten}
          schaden={schaden}
          onImport={handlePdfImport}
          onCancel={() => setShowPdf(false)}
          dispatch={dispatch}
        />
      )}

      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(170px,1fr))", gap:"0.9rem", marginBottom:"1rem" }}>
        <FieldInput label="Datum *" value={form.datum} onChange={F("datum")} type="date" />
        <FieldInput label="Versicherung" value={form.versicherung} onChange={F("versicherung")} placeholder="z.B. KRAVAG" />
        <FieldInput label="Referenz-Nr." value={form.referenz_nr} onChange={F("referenz_nr")} placeholder="VN-2025-001" />
        <FieldSelect label="Haftungsart" value={form.haftungsart} onChange={F("haftungsart")}
          options={[{value:"vollhaftung",label:"Vollhaftung 100%"},{value:"mithaftung",label:"Mithaftung"},{value:"quote",label:"Quote"},{value:"ablehnung",label:"Ablehnung"}]} />
        {(form.haftungsart === "mithaftung" || form.haftungsart === "quote") && (
          <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
            <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600, color:T.textMid, textTransform:"uppercase", letterSpacing:"0.05em" }}>Haftungsquote %</label>
            <input type="number" min={0} max={100} value={form.haftungsquote}
              onChange={e => setForm(p => ({...p,haftungsquote:e.target.value}))}
              style={{ padding:"8px 10px", border:`1.5px solid ${T.border}`, borderRadius:7, fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.985rem", color:T.text, background:T.surface, outline:"none" }}
              onFocus={e => e.target.style.borderColor=T.gold} onBlur={e => e.target.style.borderColor=T.border} />
          </div>
        )}
      </div>

      {/* Positionen */}
      <div style={{ marginBottom:"1rem" }}>
        <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:"0.6rem" }}>Regulierte Positionen</div>
        <div style={{ background:T.white, border:`1px solid ${T.border}`, borderRadius:8, overflow:"hidden" }}>
          <table style={{ width:"100%", borderCollapse:"collapse", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem" }}>
            <thead>
              <tr style={{ background:T.surface }}>
                {["Position","Gefordert (€)","Reguliert (€)","Kürzung"].map(h => (
                  <th key={h} style={{ padding:"6px 10px", textAlign:h==="Position"?"left":"right", fontWeight:600, color:T.textMuted, fontSize:"0.77rem", textTransform:"uppercase", letterSpacing:"0.05em" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {positionen.map((pos, idx) => {
                const kuerzung = POSITION_IST_ABZUG[pos.position_key]
                  ? (parseFloat(pos.betrag_reguliert)||0) - (parseFloat(pos.betrag_gefordert)||0)
                  : (parseFloat(pos.betrag_gefordert)||0) - (parseFloat(pos.betrag_reguliert)||0);
                return (
                  <tr key={pos.position_key} style={{ borderTop:`1px solid ${T.border}` }}>
                    <td style={{ padding:"6px 10px", color:T.text }}>{POSITION_LABELS_FE[pos.position_key]}</td>
                    <td style={{ padding:"6px 10px", textAlign:"right" }}>
                      <input type="number" step="0.01" min="0" value={pos.betrag_gefordert} onChange={e => updatePos(idx,"betrag_gefordert",e.target.value)}
                        style={{ width:100, padding:"4px 6px", border:`1px solid ${T.border}`, borderRadius:5, fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.875rem", textAlign:"right", background:T.surface, color:T.text }} />
                    </td>
                    <td style={{ padding:"6px 10px", textAlign:"right" }}>
                      <input type="number" step="0.01" min="0" value={pos.betrag_reguliert} onChange={e => updatePos(idx,"betrag_reguliert",e.target.value)}
                        style={{ width:100, padding:"4px 6px", border:`1px solid ${kuerzung>0?T.red:T.border}`, borderRadius:5, fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.875rem", textAlign:"right", background:T.surface, color:T.text }} />
                    </td>
                    <td style={{ padding:"6px 10px", textAlign:"right", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.875rem", color:kuerzung>0?T.red:T.textFaint, fontWeight:kuerzung>0?600:400 }}>
                      {kuerzung > 0 ? `−${fmtEuro(kuerzung)}` : "—"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <FieldInput label="Notizen" value={form.notizen} onChange={F("notizen")} placeholder="Interne Notiz zum Schreiben …" />

      <div style={{ display:"flex", gap:8, marginTop:"1rem" }}>
        <Btn variant="gold" onClick={save} disabled={saving}>{saving ? "…" : `${Ic.check} Speichern`}</Btn>
        <Btn variant="secondary" onClick={onCancel}>Abbrechen</Btn>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   REGULIERUNG SECTION – MODUL 9
══════════════════════════════════════════════════════════════ */
function RegulierungSection({ regulierungen, brutto, hq, dispatch, akteId, schaden, abrechnungenCached }) {
  // Primär: gecachte Daten aus Reducer; fallback: lokaler State beim ersten Laden
  const [abrechnungen, setAbrechnungen] = useState(abrechnungenCached || []);
  const [kuerzungsarten, setKuerzungsarten] = useState([]);
  const [pruefberichte, setPruefberichte]   = useState([]);
  const [showForm, setShowForm]     = useState(false);
  const [showPdfImport, setShowPdf] = useState(false);
  const [pdfPrefill, setPdfPrefill] = useState(null);
  const [expanded, setExpanded]     = useState(null);
  const [toast, setToast]           = useState("");

  useEffect(() => {
    apiKuerzungsarten.liste(true)
      .then(r => setKuerzungsarten(r?.kuerzungsarten || []))
      .catch(() => {});
    apiAbrechnungen.liste(akteId)
      .then(r => {
        const list = r?.abrechnungen || [];
        setAbrechnungen(list);
        // In Reducer cachen damit Übersicht-Tab aktuell bleibt
        dispatch({ type: "SET_ABRECHNUNGEN", akteId, abrechnungen: list });
      })
      .catch(() => {});
    apiPruefberichte.liste(akteId)
      .then(r => setPruefberichte(r?.pruefberichte || []))
      .catch(() => {});
  }, [akteId]);

  const netto           = brutto * (hq / 100);
  const gesamtReguliert = abrechnungen.reduce((s, a) => s + (a.gesamt_reguliert || 0), 0);
  const gesamtKuerzung  = abrechnungen.reduce((s, a) => s + (a.gesamt_kuerzung  || 0), 0);
  const regGrad         = netto > 0 ? Math.min(100, Math.round(gesamtReguliert / netto * 100)) : 0;
  const klageSumme      = abrechnungen.flatMap(a => a.positionen || [])
    .filter(p => p.fuer_klage_vorgemerkt)
    .reduce((s, p) => s + positionKuerzungBetrag(p), 0);

  const onSave = (ab) => {
    const newList = [ab, ...abrechnungen];
    setAbrechnungen(newList);
    setShowForm(false);
    setExpanded(ab.id);
    setToast("Abrechnungsschreiben gespeichert.");
    // Reducer: vollständige Abrechnung + Regulierungs-Summary cachen
    dispatch({ type: "ADD_ABRECHNUNG", akteId,
      abrechnung: ab,
      regulierung: {
        id: ab.id, datum: ab.datum,
        betrag_gefordert: ab.gesamt_gefordert,
        betrag_reguliert: ab.gesamt_reguliert,
        status: ab.haftungsart === "ablehnung" ? "abgelehnt" : "teilreguliert",
        vers_referenz: ab.referenz_nr,
      },
    });
    dispatch({ type: "SET_ABRECHNUNGEN", akteId, abrechnungen: newList });
  };

  const onSavePruefbericht = async (daten) => {
    try {
      const res = await apiPruefberichte.erstelle(akteId, daten);
      setPruefberichte(prev => [res.pruefbericht || daten, ...prev]);
      setToast("Prüfbericht gespeichert.");
    } catch {
      // Demo-Fallback
      setPruefberichte(prev => [{ id: Date.now(), ...daten, erfasst_am: new Date().toLocaleDateString("de-DE") }, ...prev]);
      setToast("Prüfbericht lokal gespeichert.");
    }
  };

  const updatePosLocal = (abid, posId, changes) => {
    setAbrechnungen(prev => prev.map(a =>
      a.id !== abid ? a : {
        ...a,
        positionen: (a.positionen || []).map(p => p.id === posId ? { ...p, ...changes } : p),
      }
    ));
  };

  return (
    <>
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
      <div style={{ display:"flex", flexDirection:"column", gap:"1.25rem" }}>

        {/* KPIs */}
        <Card style={{ padding:"1.1rem 1.4rem" }}>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(150px,1fr))", gap:"1rem", marginBottom:"1rem" }}>
            {[
              { l:"Forderung (netto)", v:fmtEuro(netto), c:T.navy },
              { l:"Reguliert",         v:fmtEuro(gesamtReguliert), c:T.green },
              { l:"Kürzungen gesamt",  v:gesamtKuerzung > 0 ? `−${fmtEuro(gesamtKuerzung)}` : "—", c:gesamtKuerzung > 0 ? T.red : T.textFaint },
              { l:"Klagegegenstand",   v:klageSumme > 0 ? fmtEuro(klageSumme) : "—", c:klageSumme > 0 ? T.amber : T.textFaint },
            ].map((s,i) => (
              <div key={i} style={{ background:T.surface, borderRadius:9, padding:"0.85rem 1rem", border:`1px solid ${T.border}` }}>
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.815rem", color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:5 }}>{s.l}</div>
                <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.375rem", fontWeight:700, color:s.c }}>{s.v}</div>
              </div>
            ))}
          </div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:6 }}>
            <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.905rem", color:T.textMuted }}>Regulierungsgrad</span>
            <span style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.175rem", fontWeight:700, color:regGrad>=100?T.green:T.navy }}>{regGrad} %</span>
          </div>
          <div style={{ height:10, background:T.border, borderRadius:5, overflow:"hidden" }}>
            <div style={{ height:"100%", width:`${regGrad}%`, background:regGrad>=100?`linear-gradient(90deg,${T.green},#34d399)`:`linear-gradient(90deg,${T.gold},${T.goldLight})`, borderRadius:5, transition:"width 0.7s" }} />
          </div>
        </Card>

        {/* Verlauf */}
        <Card>
          <CardHead
            title={`Regulierungsverlauf (${abrechnungen.length} Schreiben)`}
            action={
              <div style={{ display:"flex", gap:6 }}>
                <Btn size="sm" variant="secondary" onClick={() => { setShowPdf(o => !o); setShowForm(false); }}>
                  📄 PDF
                </Btn>
                <Btn size="sm" onClick={() => { setShowForm(o => !o); setShowPdf(false); }}>{Ic.plus} Manuell</Btn>
              </div>
            }
          />

          {showPdfImport && (
            <div style={{ padding:"0 1.4rem 1rem" }}>
              <PdfImportDialog
                akteId={akteId}
                kuerzungsarten={kuerzungsarten}
                schaden={schaden}
                onImport={(importData) => {
                  setPdfPrefill(importData);
                  setShowPdf(false);
                  setShowForm(true);
                }}
                onSavePruefbericht={onSavePruefbericht}
                onCancel={() => setShowPdf(false)}
                dispatch={dispatch}
              />
            </div>
          )}

          {showForm && (
            <div style={{ padding:"0 1.4rem 1rem" }}>
              <AbrechnungFormular
                schaden={schaden}
                kuerzungsarten={kuerzungsarten}
                akteId={akteId}
                prefill={pdfPrefill}
                onSave={(ab) => { onSave(ab); setPdfPrefill(null); }}
                onCancel={() => { setShowForm(false); setPdfPrefill(null); }}
              />
            </div>
          )}

          {abrechnungen.length === 0 && !showForm ? (
            <div style={{ padding:"2.5rem", textAlign:"center", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.975rem", color:T.textFaint }}>
              Noch keine Abrechnungsschreiben erfasst.
            </div>
          ) : (
            <div style={{ padding:"0 1.4rem 1rem", display:"flex", flexDirection:"column", gap:12 }}>
              {abrechnungen.map((ab, i) => {
                const ha = HAFTUNGSART_CFG[ab.haftungsart] || HAFTUNGSART_CFG.vollhaftung;
                const isOpen = expanded === ab.id;
                return (
                  <div key={ab.id} style={{ border:`1px solid ${T.border}`, borderLeft:`3px solid ${ha.color}`, borderRadius:9, overflow:"hidden" }}>
                    {/* Schreiben-Header */}
                    <div
                      onClick={() => setExpanded(isOpen ? null : ab.id)}
                      style={{ padding:"0.85rem 1.1rem", cursor:"pointer", display:"flex", alignItems:"center", gap:12, flexWrap:"wrap", background:isOpen?T.surface:"transparent", transition:"background 0.15s" }}
                    >
                      <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:2, flexShrink:0 }}>
                        <div style={{ width:10, height:10, borderRadius:"50%", background:ha.color }} />
                      </div>
                      <div style={{ flex:1, minWidth:150 }}>
                        <div style={{ display:"flex", alignItems:"center", gap:8, flexWrap:"wrap", marginBottom:3 }}>
                          <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.92rem", fontWeight:600, color:T.text }}>
                            {i + 1}. Abrechnung
                          </span>
                          {ab.versicherung && (
                            <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:T.textMuted }}>· {ab.versicherung}</span>
                          )}
                          <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.84rem", color:T.textFaint }}>· {ab.datum}</span>
                          <span style={{ fontSize:"0.78rem", fontWeight:600, padding:"2px 8px", borderRadius:20, background:ha.bg, color:ha.color }}>{ha.label}{ab.haftungsquote < 100 && ab.haftungsart !== "vollhaftung" ? ` ${ab.haftungsquote}%` : ""}</span>
                          {ab.parse_status === "erfolgreich" && <span style={{ fontSize:"0.72rem", background:T.greenBg, color:T.green, borderRadius:4, padding:"1px 5px" }}>PDF geparst</span>}
                        </div>
                        <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.855rem", color:T.textMuted, display:"flex", gap:16, flexWrap:"wrap" }}>
                          <span>Gefordert: <strong style={{ color:T.text }}>{fmtEuro(ab.gesamt_gefordert)}</strong></span>
                          <span>Reguliert: <strong style={{ color:T.green }}>{fmtEuro(ab.gesamt_reguliert)}</strong></span>
                          {ab.gesamt_kuerzung > 0 && <span>Kürzungen: <strong style={{ color:T.red }}>−{fmtEuro(ab.gesamt_kuerzung)}</strong></span>}
                        </div>
                      </div>
                      <span style={{ color:T.textFaint, fontSize:"0.9rem", marginLeft:"auto" }}>{isOpen ? "▲" : "▼"}</span>
                    </div>

                    {/* Positions-Detail */}
                    {isOpen && (
                      <div style={{ borderTop:`1px solid ${T.border}` }}>
                        {ab.haftungsbegruendung && (
                          <div style={{ padding:"0.75rem 1.1rem", background:T.goldPale, borderBottom:`1px solid ${T.border}`, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:T.textMid, fontStyle:"italic" }}>
                            {ab.haftungsbegruendung}
                          </div>
                        )}
                        <PositionenTabelle
                          positionen={ab.positionen || []}
                          kuerzungsarten={kuerzungsarten}
                          akteId={akteId}
                          abid={ab.id}
                          onUpdate={(posId, changes) => updatePosLocal(ab.id, posId, changes)}
                          readOnly={false}
                        />
                        {ab.notizen && (
                          <div style={{ padding:"0.75rem 1.1rem", borderTop:`1px solid ${T.border}`, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.855rem", color:T.textFaint }}>
                            Notiz: {ab.notizen}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        {/* Klage-Zusammenfassung */}
        {klageSumme > 0 && (
          <Card style={{ borderLeft:`3px solid ${T.gold}` }}>
            <CardHead title="Klagegegenstand (vorgemerktes)" />
            <div style={{ padding:"0 1.4rem 1rem" }}>
              <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:T.textMuted, marginBottom:"0.75rem" }}>
                Alle Positionen mit „Klage"-Markierung über alle Abrechnungsschreiben:
              </div>
              {abrechnungen.flatMap(a => (a.positionen || []).filter(p => p.fuer_klage_vorgemerkt).map(p => ({...p, abDatum: a.datum, versicherung: a.versicherung}))).map((p, i) => (
                <div key={i} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"6px 0", borderBottom:`1px solid ${T.border}`, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem" }}>
                  <div>
                    <span style={{ color:T.text, fontWeight:500 }}>{POSITION_LABELS_FE[p.position_key]}</span>
                    {p.kuerzungsart_bezeichnung && <span style={{ color:T.textFaint, marginLeft:8, fontSize:"0.82rem" }}>({p.kuerzungsart_bezeichnung})</span>}
                  </div>
                  <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontWeight:700, color:T.red }}>
                    −{fmtEuro(positionKuerzungBetrag(p))}
                  </span>
                </div>
              ))}
              <div style={{ display:"flex", justifyContent:"space-between", padding:"10px 0 0", fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.225rem", fontWeight:700 }}>
                <span style={{ color:T.navy }}>Gesamt Klagegegenstand</span>
                <span style={{ color:T.red }}>{fmtEuro(klageSumme)}</span>
              </div>
            </div>
          </Card>
        )}

        {/* Prüfberichte */}
        <Card>
          <CardHead
            title={`Prüfberichte (${pruefberichte.length})`}
            action={
              <Btn size="sm" variant="secondary" onClick={() => { setShowPdf(true); setShowForm(false); }}>
                📄 Prüfbericht aus PDF
              </Btn>
            }
          />
          {pruefberichte.length === 0 ? (
            <div style={{ padding:"1.5rem", textAlign:"center", color:T.textFaint, fontSize:"0.9rem" }}>
              Noch keine Prüfberichte erfasst.
            </div>
          ) : (
            <div style={{ padding:"0 1.4rem 1rem", display:"flex", flexDirection:"column", gap:8 }}>
              {pruefberichte.map((pb, i) => (
                <div key={pb.id || i} style={{ border:`1px solid ${T.border}`, borderLeft:`3px solid ${T.amber}`, borderRadius:8, padding:"0.8rem 1rem" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", flexWrap:"wrap", gap:8 }}>
                    <div>
                      <span style={{ fontWeight:600, color:T.text }}>
                        {pb.pruefdienstleister || "Prüfdienstleister"} 
                      </span>
                      {pb.vorgangsnummer && (
                        <span style={{ fontFamily:"monospace", fontSize:13, color:T.textMuted, marginLeft:8 }}>
                          #{pb.vorgangsnummer}
                        </span>
                      )}
                      {pb.datum && (
                        <span style={{ fontSize:13, color:T.textFaint, marginLeft:8 }}>{pb.datum}</span>
                      )}
                    </div>
                    {pb.reparaturkosten_nach_pruefung && (
                      <div style={{ textAlign:"right" }}>
                        <div style={{ fontSize:12, color:T.textMuted }}>Rep. nach Prüfung</div>
                        <div style={{ fontFamily:"monospace", fontWeight:700, color:T.green }}>
                          {fmtEuro(pb.reparaturkosten_nach_pruefung)}
                        </div>
                      </div>
                    )}
                  </div>
                  {pb.abzug_gesamt > 0 && (
                    <div style={{ marginTop:6, fontSize:13, color:T.red }}>
                      Abzug gesamt: −{fmtEuro(pb.abzug_gesamt)}
                      {pb.referenzwerkstatt_name && (
                        <span style={{ color:T.textMuted, marginLeft:8 }}>
                          · Referenz: {pb.referenzwerkstatt_name}
                        </span>
                      )}
                    </div>
                  )}
                  {pb.ist_image_pdf && (
                    <div style={{ marginTop:6, fontSize:12, color:T.amber }}>
                      ⚠ Bild-PDF (DEKRA) – manuelle Erfassung empfohlen
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </Card>

      </div>
    </>
  );
}

/* ══════════════════════════════════════════════════════════════
   SECTION: KÜRZUNGSKATALOG (Stammdaten)
══════════════════════════════════════════════════════════════ */
const KATEGORIE_CFG = {
  fahrzeugschaden:    { label:"Fahrzeugschaden",     color:"#185FA5", bg:"#E6F1FB" },
  ersatzbeschaffung:  { label:"Ersatzbeschaffung",   color:"#854F0B", bg:"#FAEEDA" },
  sonstiger_schaden:  { label:"Sonstiger Schaden",   color:"#5F5E5A", bg:"#F1EFE8" },
  technisch_gutachten:{ label:"Technisch/Gutachten", color:"#A32D2D", bg:"#FCEBEB" },
};

function KuerzungskatalogSection() {
  const [arten, setArten]           = useState([]);
  const [loading, setLoading]       = useState(true);
  const [showForm, setShowForm]     = useState(false);
  const [editItem, setEditItem]     = useState(null);
  const [filterKat, setFilterKat]   = useState("alle");
  const [toast, setToast]           = useState("");
  const [form, setForm]             = useState({
    bezeichnung:"", kategorie:"fahrzeugschaden",
    standard_gegenargument:"", rechtsgrundlagen:"",
    hinweis_intern:"", sv_stellungnahme_erforderlich:false,
    sortierung:999,
  });

  const ladeArten = async () => {
    setLoading(true);
    try {
      const r = await apiKuerzungsarten.liste(false);
      setArten(r?.kuerzungsarten || []);
    } catch {
      setArten(DEMO_KUERZUNGSARTEN);
    }
    setLoading(false);
  };

  // Bug 1: useEffect statt useState für Datenladen
  useEffect(() => { ladeArten(); }, []);

  const F = (k) => (v) => setForm(p => ({ ...p, [k]: v }));

  const resetForm = () => setForm({
    bezeichnung:"", kategorie:"fahrzeugschaden",
    standard_gegenargument:"", rechtsgrundlagen:"",
    hinweis_intern:"", sv_stellungnahme_erforderlich:false, sortierung:999,
  });

  const startEdit = (art) => {
    setEditItem(art.id);
    setForm({
      bezeichnung: art.bezeichnung,
      kategorie: art.kategorie,
      standard_gegenargument: art.standard_gegenargument || "",
      rechtsgrundlagen: art.rechtsgrundlagen || "",
      hinweis_intern: art.hinweis_intern || "",
      sv_stellungnahme_erforderlich: art.sv_stellungnahme_erforderlich || false,
      sortierung: art.sortierung || 0,
    });
    setShowForm(true);
  };

  const save = async () => {
    if (!form.bezeichnung.trim()) { alert("Bezeichnung ist erforderlich."); return; }
    try {
      if (editItem) {
        const r = await apiKuerzungsarten.update(editItem, form);
        setArten(prev => prev.map(a => a.id === editItem ? r.kuerzungsart : a));
        setToast("Kürzungsart aktualisiert.");
      } else {
        const r = await apiKuerzungsarten.erstelle(form);
        setArten(prev => [...prev, r.kuerzungsart]);
        setToast("Kürzungsart angelegt.");
      }
    } catch {
      // Demo
      const demo = { id: Date.now(), ...form, aktiv:true, erstellt_am: new Date().toLocaleDateString("de-DE") };
      if (editItem) {
        setArten(prev => prev.map(a => a.id === editItem ? { ...a, ...form } : a));
        setToast("Kürzungsart aktualisiert.");
      } else {
        setArten(prev => [...prev, demo]);
        setToast("Kürzungsart angelegt.");
      }
    }
    setShowForm(false);
    setEditItem(null);
    resetForm();
  };

  const toggleAktiv = async (art) => {
    try {
      await apiKuerzungsarten.toggleAktiv(art.id, !art.aktiv);
    } catch { /* Demo */ }
    setArten(prev => prev.map(a => a.id === art.id ? { ...a, aktiv: !a.aktiv } : a));
  };

  const gefiltert = filterKat === "alle" ? arten : arten.filter(a => a.kategorie === filterKat);
  const grupppen = Object.keys(KATEGORIE_CFG).reduce((acc, k) => {
    acc[k] = gefiltert.filter(a => a.kategorie === k);
    return acc;
  }, {});

  return (
    <>
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
      <div style={{ display:"flex", flexDirection:"column", gap:"1.25rem" }}>

        <Card>
          <CardHead
            title={`Kürzungskatalog (${arten.length} Einträge)`}
            action={
              <div style={{ display:"flex", gap:8, alignItems:"center" }}>
                <select
                  value={filterKat}
                  onChange={e => setFilterKat(e.target.value)}
                  style={{ padding:"5px 10px", border:`1px solid ${T.border}`, borderRadius:7, fontSize:"0.875rem", background:T.surface, color:T.text, cursor:"pointer" }}
                >
                  <option value="alle">Alle Kategorien</option>
                  {Object.entries(KATEGORIE_CFG).map(([k,v]) => (
                    <option key={k} value={k}>{v.label}</option>
                  ))}
                </select>
                <Btn size="sm" onClick={() => { setEditItem(null); resetForm(); setShowForm(o => !o); }}>
                  {Ic.plus} Neue Kürzungsart
                </Btn>
              </div>
            }
          />

          {/* Formular */}
          {showForm && (
            <div style={{ margin:"0 1.4rem 1rem", background:T.goldPale, border:`1px solid ${T.goldTrim}`, borderRadius:10, padding:"1.1rem 1.25rem" }}>
              <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", fontWeight:600, color:T.navy, textTransform:"uppercase", letterSpacing:"0.07em", marginBottom:"1rem" }}>
                {editItem ? "Kürzungsart bearbeiten" : "Neue Kürzungsart"}
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))", gap:"0.9rem", marginBottom:"0.9rem" }}>
                <FieldInput label="Bezeichnung *" value={form.bezeichnung} onChange={F("bezeichnung")} placeholder="z.B. Lackierkosten" />
                <FieldSelect label="Kategorie" value={form.kategorie} onChange={F("kategorie")}
                  options={Object.entries(KATEGORIE_CFG).map(([k,v]) => ({value:k, label:v.label}))} />
                <FieldInput label="Rechtsgrundlagen" value={form.rechtsgrundlagen} onChange={F("rechtsgrundlagen")} placeholder="z.B. BGH VI ZR 398/02" />
                <FieldInput label="Interner Hinweis" value={form.hinweis_intern} onChange={F("hinweis_intern")} placeholder="z.B. auch fiktiv" />
              </div>
              <div style={{ marginBottom:"0.9rem" }}>
                <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600, color:T.textMid, textTransform:"uppercase", letterSpacing:"0.05em", display:"block", marginBottom:4 }}>
                  Standard-Gegenargument
                </label>
                <textarea
                  value={form.standard_gegenargument}
                  onChange={e => setForm(p => ({...p, standard_gegenargument: e.target.value}))}
                  rows={3}
                  placeholder="Bewährte Argumentation für den Klage-Generator …"
                  style={{ width:"100%", padding:"8px 10px", border:`1.5px solid ${T.border}`, borderRadius:7, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.925rem", color:T.text, background:T.surface, outline:"none", resize:"vertical", lineHeight:1.5 }}
                  onFocus={e => e.target.style.borderColor=T.gold}
                  onBlur={e => e.target.style.borderColor=T.border}
                />
              </div>
              <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:"1rem" }}>
                <input
                  type="checkbox"
                  id="sv_flag"
                  checked={form.sv_stellungnahme_erforderlich}
                  onChange={e => setForm(p => ({...p, sv_stellungnahme_erforderlich: e.target.checked}))}
                  style={{ width:15, height:15, cursor:"pointer" }}
                />
                <label htmlFor="sv_flag" style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.895rem", color:T.textMid, cursor:"pointer" }}>
                  SV-Stellungnahme erforderlich
                </label>
              </div>
              <div style={{ display:"flex", gap:8 }}>
                <Btn variant="gold" onClick={save}>{Ic.check} {editItem ? "Aktualisieren" : "Anlegen"}</Btn>
                <Btn variant="secondary" onClick={() => { setShowForm(false); setEditItem(null); resetForm(); }}>Abbrechen</Btn>
              </div>
            </div>
          )}

          {/* Tabelle gruppiert nach Kategorie */}
          {loading ? (
            <div style={{ padding:"2rem", textAlign:"center", color:T.textFaint, fontFamily:"'IBM Plex Sans',sans-serif" }}>Lade …</div>
          ) : (
            <div style={{ padding:"0 1.4rem 1rem" }}>
              {Object.entries(KATEGORIE_CFG).map(([kat, katCfg]) => {
                const eintraege = grupppen[kat] || [];
                if (eintraege.length === 0 && filterKat !== "alle") return null;
                return (
                  <div key={kat} style={{ marginBottom:"1.25rem" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:"0.5rem" }}>
                      <span style={{ fontSize:"0.78rem", fontWeight:600, padding:"3px 10px", borderRadius:20, background:katCfg.bg, color:katCfg.color }}>
                        {katCfg.label}
                      </span>
                      <span style={{ fontSize:"0.82rem", color:T.textFaint, fontFamily:"'IBM Plex Sans',sans-serif" }}>
                        {eintraege.length} {eintraege.length === 1 ? "Eintrag" : "Einträge"}
                      </span>
                    </div>
                    {eintraege.length === 0 ? (
                      <div style={{ padding:"0.75rem 1rem", border:`1px dashed ${T.border}`, borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:T.textFaint }}>
                        Keine Einträge in dieser Kategorie.
                      </div>
                    ) : (
                      <div style={{ border:`1px solid ${T.border}`, borderRadius:9, overflow:"hidden" }}>
                        {eintraege.map((art, i) => (
                          <div key={art.id}
                            style={{ padding:"0.8rem 1rem", borderBottom:i<eintraege.length-1?`1px solid ${T.border}`:"none", background:art.aktiv?T.white:"rgba(0,0,0,0.02)", opacity:art.aktiv?1:0.55 }}
                          >
                            <div style={{ display:"flex", alignItems:"flex-start", gap:10 }}>
                              <div style={{ flex:1 }}>
                                <div style={{ display:"flex", alignItems:"center", gap:8, flexWrap:"wrap", marginBottom:art.standard_gegenargument||art.hinweis_intern?4:0 }}>
                                  <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.935rem", fontWeight:600, color:art.aktiv?T.text:T.textFaint }}>
                                    {art.bezeichnung}
                                  </span>
                                  {art.sv_stellungnahme_erforderlich && (
                                    <span style={{ fontSize:"0.72rem", background:T.redBg, color:T.red, borderRadius:4, padding:"1px 5px", fontWeight:600 }}>SV erforderlich</span>
                                  )}
                                  {art.rechtsgrundlagen && (
                                    <span style={{ fontSize:"0.72rem", background:T.surface, color:T.textMuted, borderRadius:4, padding:"1px 5px", fontFamily:"'IBM Plex Mono',monospace" }}>
                                      {art.rechtsgrundlagen}
                                    </span>
                                  )}
                                  {!art.aktiv && (
                                    <span style={{ fontSize:"0.72rem", background:T.surface, color:T.textFaint, borderRadius:4, padding:"1px 5px" }}>inaktiv</span>
                                  )}
                                </div>
                                {art.standard_gegenargument && (
                                  <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.855rem", color:T.textMuted, lineHeight:1.5, marginBottom:art.hinweis_intern?3:0 }}>
                                    {art.standard_gegenargument}
                                  </div>
                                )}
                                {art.hinweis_intern && (
                                  <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", color:T.amber, fontStyle:"italic" }}>
                                    Hinweis: {art.hinweis_intern}
                                  </div>
                                )}
                              </div>
                              <div style={{ display:"flex", gap:6, flexShrink:0 }}>
                                <button
                                  onClick={() => startEdit(art)}
                                  title="Bearbeiten"
                                  style={{ padding:"4px 9px", border:`1px solid ${T.border}`, borderRadius:6, background:T.surface, color:T.textMid, cursor:"pointer", fontSize:"0.8rem" }}
                                >
                                  ✏️
                                </button>
                                <button
                                  onClick={() => toggleAktiv(art)}
                                  title={art.aktiv ? "Deaktivieren" : "Aktivieren"}
                                  style={{ padding:"4px 9px", border:`1px solid ${T.border}`, borderRadius:6, background:art.aktiv?T.surface:T.greenBg, color:art.aktiv?T.textMuted:T.green, cursor:"pointer", fontSize:"0.8rem" }}
                                >
                                  {art.aktiv ? "⏸" : "▶"}
                                </button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      </div>
    </>
  );
}

/* Demo-Daten Kürzungsarten (Fallback ohne Backend) */
const DEMO_KUERZUNGSARTEN = [
  { id:1,  bezeichnung:"Stundenverrechnungssätze",        kategorie:"fahrzeugschaden",    standard_gegenargument:"Werkstattrisiko liegt beim Schädiger; fiktiv nach Stundenverrechnungssatz der Fachwerkstatt zu ersetzen.", hinweis_intern:"Verweisbetrieb prüfen", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:10 },
  { id:2,  bezeichnung:"Wertminderung",                   kategorie:"fahrzeugschaden",    standard_gegenargument:"Wertminderung ist nach Gutachten zu ersetzen; MwSt-Abzug nur bei gewerblicher Nutzung.", hinweis_intern:"MwSt / Berechnungsmethode", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:20 },
  { id:3,  bezeichnung:"Ersatzteilaufschläge / UPE-Zuschläge", kategorie:"fahrzeugschaden", standard_gegenargument:"UPE-Zuschläge sind auch bei fiktiver Abrechnung zu ersetzen.", hinweis_intern:"auch fiktiv", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:30 },
  { id:4,  bezeichnung:"Verbringungskosten",              kategorie:"fahrzeugschaden",    standard_gegenargument:"Verbringungskosten sind ortsüblich und auch fiktiv erstattungsfähig.", hinweis_intern:"auch fiktiv", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:40 },
  { id:5,  bezeichnung:"Beilackierung",                   kategorie:"fahrzeugschaden",    standard_gegenargument:"Zu ersetzen wenn Sachverständiger dies vorsieht; kein Abzug zulässig.", hinweis_intern:"SV-Gutachten maßgeblich", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:50 },
  { id:6,  bezeichnung:"Kürzung Reparaturrechnung",       kategorie:"fahrzeugschaden",    standard_gegenargument:"Unzulässig; Werkstattrisiko liegt allein beim Schädiger.", hinweis_intern:"nie zulässig", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"BGH VI ZR 398/02", sortierung:60 },
  { id:7,  bezeichnung:"Tankrest",                        kategorie:"fahrzeugschaden",    standard_gegenargument:"Zu ersetzen wenn im Gutachten ausgewiesen.", hinweis_intern:"Gutachten prüfen", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:70 },
  { id:8,  bezeichnung:"Batteriestützbetrieb",            kategorie:"fahrzeugschaden",    standard_gegenargument:"Notwendige Reparaturmaßnahme, auch fiktiv erstattungsfähig.", hinweis_intern:"auch fiktiv", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:80 },
  { id:9,  bezeichnung:"Fehlerspeicher auslesen",         kategorie:"fahrzeugschaden",    standard_gegenargument:"Unfallbedingte Reparaturkosten, auch fiktiv zu ersetzen.", hinweis_intern:"auch fiktiv", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:90 },
  { id:10, bezeichnung:"Kleinteilpauschale",              kategorie:"fahrzeugschaden",    standard_gegenargument:"Bestandteil der Reparaturkalkulation, auch fiktiv zu ersetzen.", hinweis_intern:"auch fiktiv", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:100 },
  { id:11, bezeichnung:"Technische Kürzungen",            kategorie:"technisch_gutachten",standard_gegenargument:"Abweichender Reparaturweg bedarf SV-Stellungnahme; einseitige Kürzung unzulässig.", hinweis_intern:"SV-Stellungnahme erforderlich", sv_stellungnahme_erforderlich:true, aktiv:true, rechtsgrundlagen:"", sortierung:110 },
  { id:12, bezeichnung:"Zulassungsdienst",                kategorie:"ersatzbeschaffung",  standard_gegenargument:"Erstattungsfähige Nebenkosten bei Ersatzbeschaffung.", hinweis_intern:null, sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:120 },
  { id:13, bezeichnung:"Kennzeichen / Schilderkosten",    kategorie:"ersatzbeschaffung",  standard_gegenargument:"Notwendige Nebenkosten der Wiederbeschaffung.", hinweis_intern:null, sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:130 },
  { id:14, bezeichnung:"Wunschkennzeichen",               kategorie:"ersatzbeschaffung",  standard_gegenargument:"Mehrkosten nicht erstattungsfähig; Grundkosten schon.", hinweis_intern:"nur Grundbetrag", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:140 },
  { id:15, bezeichnung:"Unkostenpauschale",               kategorie:"sonstiger_schaden",  standard_gegenargument:"Mindestens 30 € nach ständiger Rechtsprechung; Kürzung auf 25 € unzulässig.", hinweis_intern:"mind. 30 €", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:150 },
  { id:16, bezeichnung:"Nutzungsausfall",                 kategorie:"sonstiger_schaden",  standard_gegenargument:"Dauer richtet sich nach Reparaturdauer laut Gutachten zzgl. Wiederbeschaffungszeit.", hinweis_intern:"Dauer prüfen", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:160 },
  { id:17, bezeichnung:"Kürzung Sachverständigenrechnung",kategorie:"sonstiger_schaden",  standard_gegenargument:"Vollständig zu ersetzen; Werkstattrisiko-Grundsatz gilt analog.", hinweis_intern:"wie Werkstattrisiko", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"BGH VI ZR 67/06", sortierung:170 },
  { id:18, bezeichnung:"Mietwagenrechnung",               kategorie:"sonstiger_schaden",  standard_gegenargument:"Erstattung nach Schwacke/Fraunhofer; Kürzung nur bei erheblicher Überschreitung.", hinweis_intern:"Tabelle prüfen", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:180 },
  { id:19, bezeichnung:"Verdienstausfall",                kategorie:"sonstiger_schaden",  standard_gegenargument:"Durch Lohnbescheinigung zu belegen; Abzug nur bei fehlendem Nachweis.", hinweis_intern:"Nachweis prüfen", sv_stellungnahme_erforderlich:false, aktiv:true, rechtsgrundlagen:"", sortierung:190 },
];

/* ══════════════════════════════════════════════════════════════
   SECTION: DOKUMENTE
══════════════════════════════════════════════════════════════ */
const DOK_TYPEN = [{value:"gutachten",label:"Gutachten"},{value:"abrechnungsschreiben",label:"Abrechnungsschreiben"},{value:"forderungsschreiben",label:"Forderungsschreiben"},{value:"sachstandsanfrage",label:"Sachstandsanfrage"},{value:"klage",label:"Klage"},{value:"sonstiges",label:"Sonstiges"}];

function DokumenteSection({ dokumente, dispatch, akteId }) {
  const [dragging, setDrag]   = useState(false);
  const [uploading, setUpl]   = useState(false);
  const [uploadTyp, setTyp]   = useState("gutachten");
  const [toast, setToast]     = useState("");
  const inputRef              = useRef(null);

  const parseStyle = {
    erfolgreich:        { c:T.green,    bg:T.greenBg,  label:"Geparst"   },
    fehler:             { c:T.red,      bg:T.redBg,    label:"Fehler"    },
    ausstehend:         { c:T.textMuted,bg:T.surface,  label:"Ausstehend"},
    manuell_korrigiert: { c:T.blue,     bg:T.blueBg,   label:"Korrigiert"},
  };

  const [uploadProgress, setUploadProgress] = useState(0);

  const fakeUpload = async files => {
    if (!files.length) return;
    const f   = files[0];
    const ext = f.name.split(".").pop().toLowerCase();
    const typ = ["jpg","jpeg","png"].includes(ext) ? "jpg" : ext==="docx" ? "docx" : "pdf";
    setUpl(true); setUploadProgress(0);

    let dokData = {
      id: Date.now(), typ: uploadTyp, dateiname: f.name, dateityp: typ,
      groesse: f.size || Math.floor(Math.random()*900000+100000),
      hochgeladen_am: new Date().toLocaleString("de-DE",{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit"}),
      parse_status: typ==="pdf" ? "erfolgreich" : "ausstehend",
      parse_konfidenz: typ==="pdf" ? (0.7 + Math.random()*0.28) : null,
    };

    try {
      const created = await apiDokumente.hochladen(akteId, f, uploadTyp, pct => setUploadProgress(pct));
      if (created?.id) dokData = { ...dokData, ...created };
    } catch {
      // Demo-Modus: nur lokaler Fake-Upload
      await new Promise(r => setTimeout(r, 1200));
    }

    dispatch({ type:"ADD_DOKUMENT", akteId, dokument: dokData });
    setUpl(false); setUploadProgress(0);
    setToast(`${f.name} hochgeladen${typ==="pdf" ? " und geparst" : ""}.`);
  };

  return (
    <>
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
      <div style={{ display:"flex", flexDirection:"column", gap:"1.25rem" }}>

        {/* Upload */}
        <Card style={{ padding:"1.25rem 1.4rem" }}>
          <div style={{ marginBottom:"1rem", maxWidth:250 }}>
            <FieldSelect label="Dokumenttyp" value={uploadTyp} onChange={setTyp} options={DOK_TYPEN} />
          </div>
          <div
            onDragOver={e => { e.preventDefault(); setDrag(true); }}
            onDragLeave={() => setDrag(false)}
            onDrop={e => { e.preventDefault(); setDrag(false); fakeUpload([...e.dataTransfer.files]); }}
            onClick={() => !uploading && inputRef.current?.click()}
            style={{ border:`2px dashed ${dragging?T.gold:T.border}`, borderRadius:12, padding:"2.5rem 1.5rem", textAlign:"center", cursor:uploading?"default":"pointer", background:dragging?T.goldPale:"transparent", transition:"all 0.2s" }}>
            <input ref={inputRef} type="file" accept=".pdf,.docx,.jpg,.jpeg,.png" style={{ display:"none" }} onChange={e => fakeUpload([...e.target.files])} />
            {uploading ? (
              <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:12 }}>
                <div style={{ width:32, height:32, border:`3px solid ${T.goldTrim}`, borderTopColor:T.gold, borderRadius:"50%", animation:"spin 0.8s linear infinite" }} />
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.975rem", color:T.textMuted }}>Hochladen und analysieren …</div>
                {uploadProgress > 0 && uploadProgress < 100 && (
                  <div style={{ width:200 }}>
                    <div style={{ height:4, background:T.border, borderRadius:4, overflow:"hidden" }}>
                      <div style={{ height:"100%", width:`${uploadProgress}%`, background:`linear-gradient(90deg,${T.gold},${T.goldLight})`, borderRadius:4, transition:"width 0.3s" }}/>
                    </div>
                    <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.825rem", color:T.textFaint, textAlign:"center", marginTop:3 }}>{uploadProgress} %</div>
                  </div>
                )}
              </div>
            ) : (
              <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:10 }}>
                <span style={{ color:dragging?T.gold:T.textFaint }}>{Ic.upload}</span>
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"1.025rem", fontWeight:600, color:dragging?T.gold:T.textMid }}>Datei hier ablegen oder klicken</div>
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.905rem", color:T.textFaint }}>PDF, DOCX, JPG, PNG · max. 20 MB · PDFs werden automatisch geparst</div>
              </div>
            )}
          </div>
        </Card>

        {/* Liste */}
        <Card>
          <CardHead title={`Dokumente (${dokumente.length})`} />
          {dokumente.length === 0 ? (
            <div style={{ padding:"2rem", textAlign:"center", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.975rem", color:T.textFaint }}>Noch keine Dokumente hochgeladen.</div>
          ) : dokumente.map((d, i) => {
            const ps = parseStyle[d.parse_status] || parseStyle.ausstehend;
            const isPdf = d.dateityp === "pdf";
            return (
              <div key={d.id} style={{ display:"flex", alignItems:"center", gap:13, padding:"11px 1.4rem", borderBottom:i<dokumente.length-1?`1px solid ${T.borderSoft}`:"none", transition:"background 0.1s" }}
                onMouseEnter={e => e.currentTarget.style.background=T.surface}
                onMouseLeave={e => e.currentTarget.style.background="transparent"}>
                <div style={{ width:38, height:38, borderRadius:8, background:isPdf?T.redBg:T.blueBg, display:"flex", alignItems:"center", justifyContent:"center", color:isPdf?T.red:T.blue, flexShrink:0 }}>
                  {isPdf ? Ic.pdf : Ic.word}
                </div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.975rem", fontWeight:600, color:T.text, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{d.dateiname}</div>
                  <div style={{ display:"flex", alignItems:"center", gap:6, marginTop:3, flexWrap:"wrap" }}>
                    <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", background:T.surface, color:T.textMuted, border:`1px solid ${T.border}`, borderRadius:10, padding:"1px 7px" }}>{DOK_TYPEN.find(t => t.value===d.typ)?.label||d.typ}</span>
                    <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.815rem", color:T.textFaint }}>{fmtSize(d.groesse)}</span>
                    <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.815rem", color:T.textFaint }}>{d.hochgeladen_am}</span>
                  </div>
                </div>
                <div style={{ display:"flex", alignItems:"center", gap:8, flexShrink:0 }}>
                  {isPdf && (
                    <>
                      <span style={{ display:"inline-flex", alignItems:"center", gap:4, background:ps.bg, color:ps.c, border:`1px solid ${ps.c}33`, borderRadius:10, padding:"2px 8px", fontSize:"0.825rem", fontWeight:600 }}>
                        {d.parse_status==="erfolgreich" && Ic.check} {ps.label}
                      </span>
                      {d.parse_konfidenz != null && (
                        <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.895rem", fontWeight:600, color:d.parse_konfidenz>0.7?T.green:d.parse_konfidenz>0.4?T.amber:T.red }}>{Math.round(d.parse_konfidenz*100)} %</span>
                      )}
                    </>
                  )}
                  <Btn size="sm" variant="secondary" onClick={async () => {
                    try {
                      await apiDokumente.download(akteId, d.id, d.dateiname);
                    } catch {
                      setToast(`${d.dateiname} – Download fehlgeschlagen (Demo-Modus)`);
                    }
                  }}>{Ic.download} Download</Btn>
                  <Btn size="sm" variant="danger" onClick={async () => { if (confirm("Dokument löschen?")) {
                          try { await apiDokumente.loeschen(akteId, d.id); } catch { /* Demo */ }
                          dispatch({ type:"DELETE_DOKUMENT", akteId, id:d.id });
                        }; }}>{Ic.trash}</Btn>
                </div>
              </div>
            );
          })}
        </Card>
      </div>
    </>
  );
}

/* ── RA-Micro Sachstandsanfrage Karte (in Akte > Word) ────────────────────── */
function RaMicroSachstandsCard({ akte }) {
  const [wv,      setWv]      = useState(null);   // gefundene Wiedervorlage
  const [ladeWv,  setLadeWv]  = useState(true);
  const [laedt,   setLaedt]   = useState(false);
  const [erstellt, setErstellt] = useState(false);
  const [fehler,  setFehler]  = useState(null);

  // Suche nach offener WV für dieses Aktenzeichen
  useEffect(() => {
    let aktiv = true;
    setLadeWv(true);
    apiWV.liste().then(res => {
      if (!aktiv) return;
      const treffer = (res?.wiedervorlagen || []).find(w =>
        w.aktenzeichen === akte.az || w.aktenzeichen?.startsWith(akte.az)
      );
      setWv(treffer || null);
    }).catch(() => setWv(null)).finally(() => { if (aktiv) setLadeWv(false); });
    return () => { aktiv = false; };
  }, [akte.az]);

  const generieren = async () => {
    if (!wv) return;
    setLaedt(true); setFehler(null);
    try {
      await apiWV.sachstandsanfrage(wv.guid, wv.aktenzeichen);
      setErstellt(true);
    } catch (e) {
      setFehler(e.message || "Fehler beim Generieren");
    } finally {
      setLaedt(false);
    }
  };

  return (
    <div style={{ marginTop:"1.25rem" }}>
      {/* Trennlinie mit Label */}
      <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:"1.1rem" }}>
        <div style={{ flex:1, height:1, background:T.border }} />
        <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", color:T.textFaint, fontWeight:500, letterSpacing:"0.08em", textTransform:"uppercase", whiteSpace:"nowrap" }}>
          RA-Micro Integration
        </span>
        <div style={{ flex:1, height:1, background:T.border }} />
      </div>

      <Card style={{ padding:"1.4rem", display:"flex", gap:16, alignItems:"flex-start" }}>
        {/* Icon */}
        <div style={{ width:44, height:44, borderRadius:10, background:"linear-gradient(135deg,#1B2A4A,#2e4270)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:"1.4rem", flexShrink:0 }}>
          📋
        </div>

        <div style={{ flex:1 }}>
          <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1rem", fontWeight:700, color:T.navy, marginBottom:2 }}>
            Sachstandsanfrage
          </div>
          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.835rem", color:T.textFaint, marginBottom:10 }}>
            Daten aus RA-Micro Wiedervorlage · Kanzlei-Briefformat
          </div>

          {ladeWv ? (
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:T.textMuted, display:"flex", alignItems:"center", gap:8 }}>
              <div style={{ width:12, height:12, border:`2px solid ${T.border}`, borderTopColor:T.navy, borderRadius:"50%", animation:"spin 0.7s linear infinite" }} />
              Suche Wiedervorlage …
            </div>
          ) : !wv ? (
            <div style={{ display:"inline-flex", alignItems:"center", gap:7, background:"#fffbeb", border:"1px solid #fcd34d", borderRadius:8, padding:"7px 13px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:"#92400e" }}>
              <span>⚠️</span> Keine offene Wiedervorlage „Stellungnahme Gegner" in RA-Micro für {akte.az}
            </div>
          ) : (
            <div style={{ display:"flex", flexWrap:"wrap", gap:8, alignItems:"center" }}>
              {/* WV-Info-Chips */}
              <span style={{ background:T.goldPale, border:`1px solid ${T.goldTrim}`, borderRadius:6, padding:"3px 9px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", color:T.textMid }}>
                Fällig: {wv.datum ? new Date(wv.datum + "T00:00:00").toLocaleDateString("de-DE") : "–"}
              </span>
              {wv.gegner_hv_name && (
                <span style={{ background:T.surface, border:`1px solid ${T.border}`, borderRadius:6, padding:"3px 9px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", color:T.textMid }}>
                  {wv.gegner_hv_name}
                </span>
              )}
              {wv.betreff1 && (
                <span style={{ background:T.surface, border:`1px solid ${T.border}`, borderRadius:6, padding:"3px 9px", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.8rem", color:T.textMuted }}>
                  {wv.betreff1}
                </span>
              )}

              {fehler && (
                <div style={{ width:"100%", background:"#fff1f2", border:"1px solid #fca5a5", borderRadius:7, padding:"6px 12px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", color:"#9f1239" }}>
                  {fehler}
                </div>
              )}

              <button onClick={generieren} disabled={laedt}
                style={{ marginTop:4, display:"flex", alignItems:"center", gap:7,
                  padding:"9px 16px",
                  background: erstellt ? "#f0fdf4" : T.navy,
                  color:      erstellt ? "#065f46" : T.white,
                  border:     erstellt ? "1.5px solid #6ee7b7" : "none",
                  borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.935rem", fontWeight:600,
                  cursor: laedt ? "default" : "pointer", opacity: laedt ? 0.7 : 1, transition:"all 0.2s",
                }}>
                {laedt
                  ? <><div style={{ width:13, height:13, border:"2px solid rgba(255,255,255,0.3)", borderTopColor:"white", borderRadius:"50%", animation:"spin 0.7s linear infinite" }}/> Erstellen …</>
                  : erstellt
                  ? <><svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="7" fill="#10b981"/><path d="M4 7L6 9L10 5" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg> Erstellt – erneut generieren</>
                  : <>📄 Sachstandsanfrage generieren &amp; herunterladen</>}
              </button>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   SECTION: WORD-GENERIERUNG
══════════════════════════════════════════════════════════════ */
function WordSection({ akte, st, dispatch }) {
  const [loading, setL]   = useState({});
  const [done,    setD]   = useState({});
  const [fehler,  setF]   = useState({});
  const [toast,   setT]   = useState("");

  // Beteiligte laden wenn noch nicht im State
  useEffect(() => {
    if (st.beteiligte && st.beteiligte.length > 0) return;
    apiBeteiligte.liste(akte.id)
      .then(res => {
        const liste = res?.beteiligte || [];
        if (liste.length > 0) {
          dispatch({ type: "SET_BETEILIGTE", akteId: akte.id, beteiligte: liste });
        }
      })
      .catch(() => {});
  }, [akte.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Adressat-Dropdown: voreingestellt auf GHPV-Beteiligten
  const beteiligte_alle = st.beteiligte || [];
  // GHPV = gegnerische Haftpflichtversicherung, Fallback: erster Gegner
  const ghpv = beteiligte_alle.find(b =>
    ["GHPV","GHV","GBEV"].includes((b.kuerzel || "").toUpperCase())
  ) || beteiligte_alle.find(b => b.rolle === "gegner");
  // id kann null sein (RA-Micro-Fallback) → dann kein adressat_id mitsenden
  const [adressatId, setAdressatId] = useState(ghpv?.id ?? null);

  // Adressaten-Optionen: alle Gegner + Versicherungen
  // Adressaten: alle Gegner + Beteiligte mit Versicherung/Kürzel
  const adressatOptionen = beteiligte_alle.filter(b =>
    b.rolle === "gegner" ||
    (b.versicherung && b.versicherung.trim()) ||
    (b.kuerzel && b.kuerzel.trim())
  );

  const gen = async (typ, label) => {
    setL(p => ({...p,[typ]:true}));
    setD(p => ({...p,[typ]:false}));
    setF(p => ({...p,[typ]:null}));
    try {
      await apiWord.generieren(akte.id, typ, typ === "forderungsschreiben" ? (adressatId || null) : null);
      setD(p => ({...p,[typ]:true}));
      setT(`✓ ${label} erstellt.`);
      // Sofort-Download nach Generierung
      await apiWord.vorschau(akte.id, typ);
    } catch(err) {
      const msg = err?.message || String(err);
      setF(p => ({...p,[typ]: msg.slice(0,200)}));
      setT(`Fehler beim Erstellen: ${msg.slice(0,100)}`);
    } finally {
      setL(p => ({...p,[typ]:false}));
    }
  };

  const download = async (typ, label) => {
    try {
      await apiWord.vorschau(akte.id, typ);
    } catch(err) {
      setT(`Download fehlgeschlagen: ${String(err).slice(0,100)}`);
    }
  };

  const gegner    = st.beteiligte?.find(b => b.rolle==="gegner");
  const mandant   = st.beteiligte?.find(b => b.rolle==="mandant");
  // Lokale Schadensberechnung (identisch zu AkteDetailView.liveBrutto)
  const _ws_sd   = st.schaden || {};
  const _ws_g    = k => parseFloat(_ws_sd[k]) || 0;
  const _ws_repN = _ws_g("rep_gutachten_netto") || _ws_g("reparaturkosten");
  const _ws_repRN= _ws_g("rep_rechnung_netto");
  const _ws_effR = (_ws_repRN > 0 && _ws_repRN > _ws_repN) ? _ws_repRN : _ws_repN;
  const _ws_wbw  = _ws_g("wiederbeschaffung"), _ws_rst = _ws_g("restwert");
  const _ws_nFzg = _ws_wbw - _ws_rst;
  const _ws_fzg  = _ws_wbw > 0 ? (_ws_effR > 0 && _ws_effR <= _ws_nFzg ? _ws_effR : _ws_nFzg) : _ws_effR;
  const liveBrutto = _ws_sd.gesamt_brutto != null ? _ws_sd.gesamt_brutto
    : _ws_fzg + _ws_g("wertminderung") + _ws_g("nutzungsausfall") + _ws_g("mietwagenkosten")
      + _ws_g("sv_kosten") + _ws_g("abschleppkosten") + _ws_g("standkosten")
      + _ws_g("anabmeldekosten") + _ws_g("schmerzensgeld") + _ws_g("sonstiges")
      + _ws_g("verdienstausfall") + _ws_g("haushalt") + (_ws_g("unkostenpauschale") || 0)
      + _ws_g("kostennb") + _ws_g("kostennb_ust")
      + (_ws_sd._extras || []).reduce((s, e) => s + (parseFloat(e.betrag) || 0), 0);
  const netto     = (st.schaden?.gesamt_brutto ?? liveBrutto) * (akte.hq/100);
  const gesamtReg = st.regulierungen?.reduce((s,r) => s+r.betrag_reguliert, 0) || 0;

  const docs = [
    { typ:"forderungsschreiben",  label:"Forderungsschreiben",  icon:"⚖️", an:gegner?.versicherung||"Versicherung",  desc:"Schadensersatzforderung an den Haftpflichtversicherer gemäß §§ 7, 17, 18 StVG, § 115 VVG mit vollständiger Schadensaufstellung." },
    { typ:"abrechnungsuebersicht",label:"Abrechnungsübersicht", icon:"📊", an:mandant?.name||"Mandant",             desc:"Mandanteninformation über den aktuellen Regulierungsstand mit übersichtlicher Schadenaufstellung." },
  ];

  return (
    <>
      {toast && <Toast msg={toast} onDone={() => setT("")} />}
      <div style={{ display:"flex", flexDirection:"column", gap:"1.25rem" }}>

        {/* Info-Banner */}
        <div style={{ background:T.navyDark, borderRadius:12, padding:"1rem 1.4rem", border:"1px solid rgba(200,168,75,0.2)", display:"flex", alignItems:"center", gap:14, flexWrap:"wrap" }}>
          <div style={{ color:T.white }}>{Ic.word}</div>
          <div style={{ flex:1 }}>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.945rem", fontWeight:600, color:T.white }}>Dokumente werden automatisch aus den Aktendaten generiert</div>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:"rgba(255,255,255,0.48)", marginTop:2 }}>Kanzlei-Design (Navy/Gold) · DIN 5008 · Haftungsquote {akte.hq} %</div>
          </div>
          <div style={{ display:"flex", gap:16, flexShrink:0 }}>
            {[{l:"Forderung",v:fmtEuro(netto)},{l:"Reguliert",v:fmtEuro(gesamtReg)},{l:"Offen",v:fmtEuro(Math.max(0,netto-gesamtReg))}].map((s,i) => (
              <div key={i} style={{ textAlign:"center" }}>
                <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"1.025rem", fontWeight:600, color:T.white }}>{s.v}</div>
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.795rem", color:"rgba(255,255,255,0.44)", marginTop:1 }}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Dokument-Kacheln */}
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(290px,1fr))", gap:"1.25rem" }}>
          {docs.map(doc => {
            const isL = loading[doc.typ];
            const isD = done[doc.typ];
            const err = fehler[doc.typ];
            return (
              <Card key={doc.typ} style={{ padding:"1.4rem", display:"flex", flexDirection:"column", gap:14, transition:"transform 0.15s,box-shadow 0.15s" }}
                onMouseEnter={e => { e.currentTarget.style.transform="translateY(-2px)"; e.currentTarget.style.boxShadow="0 8px 24px rgba(0,0,0,0.09)"; }}
                onMouseLeave={e  => { e.currentTarget.style.transform=""; e.currentTarget.style.boxShadow=""; }}>

                {/* Kachel-Kopf */}
                <div style={{ display:"flex", alignItems:"flex-start", gap:12 }}>
                  <div style={{ width:44, height:44, borderRadius:10, background:T.navy, display:"flex", alignItems:"center", justifyContent:"center", fontSize:"1.475rem", flexShrink:0 }}>{doc.icon}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1rem", fontWeight:700, color:T.navy }}>{doc.label}</div>
                    <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.835rem", color:T.textFaint, marginTop:2 }}>An: {doc.an}</div>
                  </div>
                  {/* Download-Icon nach erfolgreicher Generierung */}
                  {isD && !err && (
                    <button title={`${doc.label} erneut herunterladen`}
                      onClick={() => download(doc.typ, doc.label)}
                      style={{ flexShrink:0, display:"flex", alignItems:"center", gap:5, padding:"5px 10px", background:T.greenBg, border:`1px solid ${T.green}44`, borderRadius:7, cursor:"pointer", color:T.green, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", fontWeight:600, whiteSpace:"nowrap" }}>
                      {Ic.download} .docx
                    </button>
                  )}
                </div>

                {/* Beschreibung */}
                <p style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.935rem", color:T.textMuted, lineHeight:1.65, margin:0 }}>{doc.desc}</p>

                {/* Fehlermeldung */}
                {err && (
                  <div style={{ background:T.redBg, border:`1px solid ${T.red}33`, borderRadius:7, padding:"8px 12px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.855rem", color:T.red }}>
                    ⚠ {err}
                  </div>
                )}

                {/* Adressat-Dropdown nur für Forderungsschreiben */}
                {doc.typ === "forderungsschreiben" && adressatOptionen.length > 0 && (
                  <div>
                    <label style={{ display:"block", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", fontWeight:600, color:T.textMuted, marginBottom:5, textTransform:"uppercase", letterSpacing:"0.06em" }}>
                      Adressat
                    </label>
                    <select
                      value={adressatId ?? ""}
                      onChange={e => setAdressatId(e.target.value ? parseInt(e.target.value) : null)}
                      style={{ width:"100%", padding:"7px 10px", borderRadius:7, border:`1.5px solid ${T.border}`,
                        background:T.surface, color:T.text, fontFamily:"'IBM Plex Sans',sans-serif",
                        fontSize:"0.875rem", cursor:"pointer", outline:"none" }}>
                      {adressatOptionen.map((b, idx) => {
                        const basis = b.versicherung || b.firma ||
                          `${b.vorname||""} ${b.name||""}`.trim() || `Beteiligter ${idx+1}`;
                        const rolle = b.kuerzel ? b.kuerzel.toUpperCase()
                          : b.rolle === "gegner" ? "Gegner" : b.rolle || "";
                        // id=null → RA-Micro-Eintrag, adressat_id nicht mitsenden (word_service lädt selbst)
                        return <option key={b.id ?? `ra_${idx}`} value={b.id ?? ""}>{basis}{rolle ? ` (${rolle})` : ""}</option>;
                      })}
                    </select>
                  </div>
                )}

                {/* Aktions-Button */}
                <div style={{ marginTop:"auto" }}>
                  <button onClick={() => gen(doc.typ, doc.label)} disabled={isL}
                    style={{ width:"100%", display:"flex", alignItems:"center", justifyContent:"center", gap:7, padding:"9px 14px",
                      background: err ? T.red : isD ? T.greenBg : T.navy,
                      color:      err ? T.white : isD ? T.green : T.white,
                      border:     isD && !err ? `1px solid ${T.green}33` : "none",
                      borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.965rem", fontWeight:600,
                      cursor:isL?"default":"pointer", opacity:isL?0.7:1, transition:"all 0.2s" }}>
                    {isL
                      ? <><div style={{ width:13, height:13, border:"2px solid rgba(255,255,255,0.3)", borderTopColor:"white", borderRadius:"50%", animation:"spin 0.7s linear infinite" }}/> Erstelle …</>
                      : err
                        ? <>{Ic.refresh} Erneut versuchen</>
                        : isD
                          ? <>{Ic.refresh} Erneut generieren</>
                          : <>{Ic.word} Generieren &amp; Herunterladen</>}
                  </button>
                </div>

              </Card>
            );
          })}
        </div>

        {/* RA-Micro Sachstandsanfrage */}
        <RaMicroSachstandsCard akte={akte} />

      </div>
    </>
  );
}


/* ══════════════════════════════════════════════════════════════
   AKTE DETAIL VIEW
══════════════════════════════════════════════════════════════ */
function AkteDetailView({ akte, st, dispatch }) {
  const [sec, setSec] = useState("uebersicht");

  // Beim ersten Öffnen: Schaden, Regulierungen und Beteiligte aus DB laden
  useEffect(() => {
    const id = akte.id;
    // Schaden laden
    if (!st.schaden) {
      apiSchaden.holen(id)
        .then(res => {
          if (res?.schaden) dispatch({ type:"SAVE_SCHADEN", akteId:id, schaden:res.schaden });
        })
        .catch(() => {});
    }
    // Regulierungen laden
    if (!st.regulierungen) {
      apiSchaden.regulierungen(id)
        .then(res => {
          if (res?.regulierungen) dispatch({ type:"SET_REGULIERUNGEN", akteId:id, regulierungen:res.regulierungen });
        })
        .catch(() => {});
    }
    // Beteiligte laden
    if (!st.beteiligte) {
      apiBeteiligte.liste(id)
        .then(res => {
          if (res?.beteiligte?.length) dispatch({ type:"SET_BETEILIGTE", akteId:id, beteiligte:res.beteiligte });
        })
        .catch(() => {});
    }
  }, [akte.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Live-Schadensumme — identische Formel wie SchadenSection.calcBrutto
  // Wird immer neu berechnet (gesamt_brutto aus DB ist nur Fallback wenn alle Felder 0)
  const _sd = st.schaden || {};
  const _g  = k => parseFloat(_sd[k]) || 0;
  const _repN  = _g("rep_gutachten_netto") || _g("reparaturkosten");
  const _repRN = _g("rep_rechnung_netto");
  const _effRep = _repRN > 0 ? _repRN : _repN;
  const _wbw = _g("wiederbeschaffung"), _rst = _g("restwert");
  const _nettoFzg = _wbw - _rst;
  const _ist130 = _repRN > 0 && _wbw > 0 && _repRN > _nettoFzg && _repRN <= 1.3 * _wbw;
  const _fzg = _wbw > 0 ? (_ist130 || (_effRep > 0 && _effRep <= _nettoFzg) ? _effRep : _nettoFzg) : _effRep;
  // _extras: aus Store (nach WDM-Übernahme) oder aus wdm_extras_json (nach DB-Reload)
  const _sdExtras = (() => {
    if (_sd._extras && _sd._extras.length > 0) return _sd._extras;
    if (_sd.wdm_extras_json) {
      try { const p = JSON.parse(_sd.wdm_extras_json); if (Array.isArray(p)) return p; } catch {}
    }
    return [];
  })();
  const _berechneterBrutto = _fzg
    + _g("wertminderung") + _g("nutzungsausfall") + _g("mietwagenkosten")
    + _g("sv_kosten") + _g("abschleppkosten") + _g("standkosten")
    + _g("anabmeldekosten") + _g("schmerzensgeld") + _g("sonstiges")
    + _g("verdienstausfall") + _g("haushalt") + (_g("unkostenpauschale") || 0)
    + _g("kostennb") + _g("kostennb_ust")
    + _sdExtras.reduce((s, e) => s + (parseFloat(e.betrag) || 0), 0);
  // liveBrutto: berechneter Wert hat Vorrang; gesamt_brutto als Fallback wenn Felder leer
  const liveBrutto = _berechneterBrutto > 0 ? _berechneterBrutto
    : (_sd.gesamt_brutto || akte.brutto || 0);

  const tabs = [
    { id:"uebersicht",    label:"Übersicht" },
    { id:"schaden",       label:"Schaden" },
    { id:"regulierung",   label:`Regulierung (${st.regulierungen?.length||0})` },
    { id:"dokumente",     label:`Dokumente (${st.dokumente?.length||0})` },
    { id:"word",          label:"Word-Generierung" },
  ];

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>

      {/* Header */}
      <div style={{ background:T.navy, padding:"1.1rem 1.75rem 0", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"flex-start", gap:13, marginBottom:"0.8rem", flexWrap:"wrap" }}>
          <div style={{ width:40, height:40, background:T.goldTrim, borderRadius:9, border:"1px solid rgba(200,168,75,0.3)", display:"flex", alignItems:"center", justifyContent:"center", color:T.white, flexShrink:0 }}>{Ic.akte}</div>
          <div style={{ flex:1, minWidth:200 }}>
            <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.805rem", color:"rgba(200,168,75,0.65)", letterSpacing:"0.1em", textTransform:"uppercase", marginBottom:2 }}>Aktenzeichen</div>
            <h1 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.675rem", fontWeight:700, color:T.white, margin:0, lineHeight:1.1 }}>{akte.az}</h1>
            <div style={{ display:"flex", alignItems:"center", gap:8, marginTop:4, flexWrap:"wrap" }}>
              <StatusBadge status={st.status||akte.status} />
              <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.865rem", color:"rgba(255,255,255,0.45)" }}>{akte.unfalldatum}</span>
              <span style={{ color:"rgba(255,255,255,0.2)" }}>·</span>
              <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.865rem", color:"rgba(255,255,255,0.45)", maxWidth:240, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{akte.unfallort}</span>
              <span style={{ color:"rgba(255,255,255,0.2)" }}>·</span>
              <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.865rem", color:"rgba(255,255,255,0.45)" }}>Haftung {akte.hq} %</span>
            </div>
          </div>
          <div style={{ display:"flex", gap:10, background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:10, padding:"8px 15px", flexShrink:0, flexWrap:"wrap" }}>
            {(() => {
              const gefordert  = liveBrutto * ((akte.hq || 100) / 100);
              const reguliert  = st.regulierungen?.reduce((s,r) => s + (r.betrag_reguliert||0), 0) || 0;
              const offen      = Math.max(0, gefordert - reguliert);
              return [
                { l:"Gefordert", v: fmtEuro(gefordert),  farbe: gefordert === 0 ? "#51cf66" : "#ffa94d", divider: false },
                { l:"Reguliert", v: fmtEuro(reguliert),  farbe: reguliert === 0 ? "#51cf66" : "#51cf66", divider: true  },
                { l:"Offen",     v: fmtEuro(offen),       farbe: offen     === 0 ? "#51cf66" : "#ff6b6b", divider: true  },
              ].map((s, i) => (
                <React.Fragment key={i}>
                  {s.divider && <div style={{ width:1, background:"rgba(255,255,255,0.12)", alignSelf:"stretch", margin:"2px 5px" }}/>}
                  <div style={{ textAlign:"center", padding:"0 4px" }}>
                    <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"1.05rem", fontWeight:700, color:s.farbe }}>{s.v}</div>
                    <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.735rem", color:"rgba(255,255,255,0.45)", marginTop:2, letterSpacing:"0.04em" }}>{s.l}</div>
                  </div>
                </React.Fragment>
              ));
            })()}
          </div>
        </div>

        <div style={{ display:"flex", overflowX:"auto", scrollbarWidth:"none" }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setSec(t.id)}
              style={{ padding:"8px 16px", background:"transparent", border:"none", borderBottom:sec===t.id?`2px solid ${T.gold}`:"2px solid transparent", color:sec===t.id?T.white:"rgba(255,255,255,0.5)", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.935rem", fontWeight:sec===t.id?600:400, cursor:"pointer", transition:"all 0.15s", whiteSpace:"nowrap", flexShrink:0 }}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Section content */}
      <div style={{ flex:1, overflowY:"auto", background:T.offWhite, padding:"1.5rem 1.75rem" }}>
        <div style={{ maxWidth:1200 }}>
          {sec==="uebersicht"      && <UebersichtSection akte={akte} st={st} dispatch={dispatch} />}
          {sec==="schaden"         && <SchadenSection schaden={st.schaden||{}} hq={akte.hq} dispatch={dispatch} akteId={akte.id} vorsteuer={(st.beteiligte||[]).find(b=>b.rolle==="mandant")?.vorsteuer==="Y"} />}
          {sec==="regulierung"     && <RegulierungSection regulierungen={st.regulierungen||[]} brutto={st.schaden?.gesamt_brutto ?? liveBrutto} hq={akte.hq} dispatch={dispatch} akteId={akte.id} schaden={st.schaden||{}} abrechnungenCached={st.abrechnungen||[]} />}
          {sec==="dokumente"       && <DokumenteSection dokumente={st.dokumente||[]} dispatch={dispatch} akteId={akte.id} />}
          {sec==="word"            && <WordSection akte={akte} st={st} dispatch={dispatch} />}
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   AKTEN REDUCER
══════════════════════════════════════════════════════════════ */
function reducer(state, action) {
  const { akteId } = action;
  const cur = state[akteId] || {};
  switch (action.type) {
    case "SAVE_BETEILIGTER": {
      const list = cur.beteiligte || [];
      const idx  = list.findIndex(b => b.id === action.beteiligter.id);
      return { ...state, [akteId]:{ ...cur, beteiligte: idx>=0 ? list.map((b,i) => i===idx ? action.beteiligter : b) : [...list, action.beteiligter] } };
    }
    case "DELETE_BETEILIGTER":
      return { ...state, [akteId]:{ ...cur, beteiligte:(cur.beteiligte||[]).filter(b => b.id!==action.id) } };
    case "SET_BETEILIGTE":
      return { ...state, [akteId]:{ ...cur, beteiligte: action.beteiligte } };
    case "SAVE_SCHADEN":
      return { ...state, [akteId]:{ ...cur, schaden:action.schaden } };
    case "SET_ABRECHNUNGEN":
      return { ...state, [akteId]:{ ...cur, abrechnungen: action.abrechnungen } };
    case "ADD_ABRECHNUNG":
      return { ...state, [akteId]:{ ...cur,
        abrechnungen: [action.abrechnung, ...(cur.abrechnungen || [])],
        regulierungen: [action.regulierung, ...(cur.regulierungen || [])],
      }};
    case "ADD_REGULIERUNG":
      return { ...state, [akteId]:{ ...cur, regulierungen:[...(cur.regulierungen||[]), action.regulierung] } };
    case "ADD_DOKUMENT":
      return { ...state, [akteId]:{ ...cur, dokumente:[...(cur.dokumente||[]), action.dokument] } };
    case "DELETE_DOKUMENT":
      return { ...state, [akteId]:{ ...cur, dokumente:(cur.dokumente||[]).filter(d => d.id!==action.id) } };
    case "SET_AKTIVITAETEN":
      return { ...state, [akteId]:{ ...cur, aktivitaeten: action.aktivitaeten } };
    case "PREPEND_AKTIVITAET":
      return { ...state, [akteId]:{ ...cur, aktivitaeten: [action.aktivitaet, ...(cur.aktivitaeten||[])] } };
    case "SET_STATUS":
      return { ...state, [akteId]:{ ...cur, status:action.status } };
    case "SET_NOTIZEN":
      return { ...state, [akteId]:{ ...cur, notizen:action.notizen } };
    default: return state;
  }
}

/* ══════════════════════════════════════════════════════════════
   EMAIL IMPORT VIEW – MODUL 3
══════════════════════════════════════════════════════════════ */

const EMAIL_STATUS = {
  zugeordnet:       { label:"Zugeordnet",       color:T.green,    bg:T.greenBg  },
  nicht_zugeordnet: { label:"Nicht zugeordnet", color:T.amber,    bg:T.amberBg  },
  fehler:           { label:"Fehler",           color:T.red,      bg:T.redBg    },
  duplikat:         { label:"Duplikat",         color:T.textMuted,bg:T.surface  },
};

const MATCH_LABELS = {
  aktenzeichen:    { label:"Aktenzeichen",    color:T.blue  },
  kfz_kennzeichen: { label:"KFZ-Kennzeichen", color:T.green },
  absender_email:  { label:"Absender-E-Mail", color:T.amber },
};

const IMPORT_STEPS = [
  "Verbinde mit IMAP-Server …",
  "Prüfe auf neue E-Mails …",
  "Lade Nachrichten herunter …",
  "Parse E-Mail-Header …",
  "Ordne Akten zu …",
  "Speichere Anhänge …",
  "Aktualisiere Import-Log …",
];

/* ══════════════════════════════════════════════════════════════
   IMAP-KONFIGURATIONSDIALOG
══════════════════════════════════════════════════════════════ */

function ImapKonfigDialog({ cfg, onClose, onGespeichert }) {
  const [form, setForm] = useState({
    host:      cfg?.host      || "",
    port:      cfg?.port      || 993,
    user:      cfg?.user      || "",
    password:  "",                     // Passwort nie vorab befüllen
    folder:    cfg?.folder || cfg?.ordner || "INBOX",
    max_fetch: cfg?.max_fetch || 50,
  });
  const [saving, setSaving]   = useState(false);
  const [testOk, setTestOk]   = useState(null);  // null | true | false
  const [testMsg, setTestMsg] = useState("");

  const F = (k) => (v) => setForm(p => ({ ...p, [k]: v }));

  const handleTest = async () => {
    setSaving(true); setTestOk(null); setTestMsg("");
    try {
      const res = await apiEmail.status();
      setTestOk(res?.verbindung_ok ?? false);
      setTestMsg(res?.nachricht || (res?.verbindung_ok ? "Verbindung erfolgreich." : "Verbindung fehlgeschlagen."));
    } catch (e) {
      setTestOk(false);
      setTestMsg("Verbindungstest fehlgeschlagen: " + (e?.message || String(e)));
    } finally {
      setSaving(false);
    }
  };

  const handleSpeichern = () => {
    // Konfiguration kann nur über .env geändert werden – wir zeigen den Hinweis
    // und geben die neuen (eingetippten) Werte für die Anzeige zurück
    onGespeichert({
      host:      form.host,
      port:      Number(form.port),
      user:      form.user,
      folder:    form.folder,
      max_fetch: Number(form.max_fetch),
    });
  };

  const fieldStyle = {
    width:"100%", padding:"8px 10px",
    border:`1.5px solid ${T.border}`, borderRadius:7,
    fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.925rem",
    color:T.text, background:T.white, outline:"none", boxSizing:"border-box",
  };

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.45)", zIndex:1000, display:"flex", alignItems:"center", justifyContent:"center", padding:"1rem" }}>
      <div style={{ background:T.white, borderRadius:12, width:"100%", maxWidth:520, boxShadow:"0 8px 40px rgba(0,0,0,0.18)", overflow:"hidden" }}>
        {/* Header */}
        <div style={{ background:T.navy, padding:"1rem 1.4rem", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div>
            <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.15rem", fontWeight:700, color:T.white }}>
              IMAP-Konfiguration
            </div>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", color:"rgba(255,255,255,0.5)", marginTop:2 }}>
              Werte werden in der <code style={{ color:T.gold }}>.env</code>-Datei gespeichert
            </div>
          </div>
          <button onClick={onClose} style={{ background:"none", border:"none", color:"rgba(255,255,255,0.6)", fontSize:"1.4rem", cursor:"pointer", lineHeight:1 }}>×</button>
        </div>

        {/* Body */}
        <div style={{ padding:"1.2rem 1.4rem", display:"flex", flexDirection:"column", gap:"0.85rem" }}>

          {/* Hinweis */}
          <div style={{ background:T.amberBg, border:`1px solid ${T.amber}44`, borderRadius:7, padding:"8px 12px", fontSize:"0.825rem", color:T.amber, fontFamily:"'IBM Plex Sans',sans-serif" }}>
            ⚠ Änderungen werden nur in der Anzeige übernommen. Um die <code>.env</code>-Datei dauerhaft zu ändern, bitte manuell bearbeiten und den Server neu starten.
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"1fr auto", gap:"0.75rem", alignItems:"start" }}>
            <div>
              <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", fontWeight:600, color:T.textMid, display:"block", marginBottom:4 }}>
                IMAP-Server <span style={{ color:T.textFaint, fontWeight:400 }}>(EMAIL_HOST)</span>
              </label>
              <input style={fieldStyle} value={form.host} onChange={e => F("host")(e.target.value)} placeholder="mail.anwalt-offenbach.de" />
            </div>
            <div>
              <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", fontWeight:600, color:T.textMid, display:"block", marginBottom:4 }}>
                Port <span style={{ color:T.textFaint, fontWeight:400 }}>(EMAIL_PORT)</span>
              </label>
              <input style={{ ...fieldStyle, width:80 }} type="number" value={form.port} onChange={e => F("port")(e.target.value)} placeholder="993" />
            </div>
          </div>

          <div>
            <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", fontWeight:600, color:T.textMid, display:"block", marginBottom:4 }}>
              Benutzername <span style={{ color:T.textFaint, fontWeight:400 }}>(EMAIL_USER)</span>
            </label>
            <input style={fieldStyle} value={form.user} onChange={e => F("user")(e.target.value)} placeholder="import@anwalt-offenbach.de" />
          </div>

          <div>
            <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", fontWeight:600, color:T.textMid, display:"block", marginBottom:4 }}>
              Passwort <span style={{ color:T.textFaint, fontWeight:400 }}>(EMAIL_PASSWORD)</span>
            </label>
            <input style={fieldStyle} type="password" value={form.password} onChange={e => F("password")(e.target.value)} placeholder="Nur ausfüllen wenn ändern" autoComplete="new-password" />
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"0.75rem" }}>
            <div>
              <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", fontWeight:600, color:T.textMid, display:"block", marginBottom:4 }}>
                Ordner <span style={{ color:T.textFaint, fontWeight:400 }}>(EMAIL_FOLDER)</span>
              </label>
              <input style={fieldStyle} value={form.folder} onChange={e => F("folder")(e.target.value)} placeholder="INBOX" />
            </div>
            <div>
              <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", fontWeight:600, color:T.textMid, display:"block", marginBottom:4 }}>
                Max. E-Mails <span style={{ color:T.textFaint, fontWeight:400 }}>(EMAIL_MAX_FETCH)</span>
              </label>
              <input style={fieldStyle} type="number" min="1" max="200" value={form.max_fetch} onChange={e => F("max_fetch")(e.target.value)} placeholder="50" />
            </div>
          </div>

          {/* Verbindungstest-Ergebnis */}
          {testMsg && (
            <div style={{ padding:"7px 12px", borderRadius:6, fontSize:"0.83rem", fontFamily:"'IBM Plex Sans',sans-serif",
              background: testOk ? T.greenBg : T.redBg,
              color:      testOk ? T.green   : T.red,
              border:`1px solid ${testOk ? T.green : T.red}33` }}>
              {testOk ? "✓" : "✗"} {testMsg}
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ padding:"0.85rem 1.4rem", borderTop:`1px solid ${T.border}`, display:"flex", gap:8, justifyContent:"flex-end" }}>
          <Btn variant="ghost" onClick={onClose}>Abbrechen</Btn>
          <Btn variant="secondary" onClick={handleTest} disabled={saving}>
            {saving ? "…" : "🔌 Verbindung testen"}
          </Btn>
          <Btn variant="gold" onClick={handleSpeichern}>
            Übernehmen
          </Btn>
        </div>
      </div>
    </div>
  );
}

function EmailImportView({ onOpenAkte }) {
  const [log, setLog]             = useState([]);
  const [filter, setFilter]       = useState("alle");
  const [suche, setSuche]         = useState("");
  const [expanded, setExpanded]   = useState(null);
  const [importing, setImporting] = useState(false);
  const [importStep, setStep]     = useState(-1);
  const [importResult, setResult] = useState(null);
  const [toast, setToast]         = useState("");

  // IMAP-Konfiguration aus Backend laden
  const [imapCfg, setImapCfg]         = useState(null);   // echte Werte aus .env
  const [cfgStatus, setCfgStatus]     = useState(null);   // verbindungsstatus
  const [showKonfigDialog, setShowKonfigDialog] = useState(false);
  const [cfgLaden, setCfgLaden]       = useState(false);

  useEffect(() => {
    // IMAP-Konfig laden
    apiEmail.status()
      .then(data => {
        setCfgStatus(data);
        if (data?.konfiguration) setImapCfg(data.konfiguration);
      })
      .catch(() => {});
    // E-Mail-Log aus API laden
    apiEmail.log({ limit: 200 })
      .then(data => { if (data?.log) setLog(data.log); })
      .catch(() => {});
  }, []);

  // Angezeigte Konfigurationswerte: echte Werte bevorzugen, sonst Mock
  const angezeigteKfg = imapCfg ?? IMAP_CONFIG;
  const verbunden = cfgStatus?.verbindung_ok ?? (IMAP_CONFIG.status === "verbunden");

  const stats = {
    gesamt:           log.length,
    zugeordnet:       log.filter(e => e.status==="zugeordnet").length,
    nicht_zugeordnet: log.filter(e => e.status==="nicht_zugeordnet").length,
    fehler:           log.filter(e => e.status==="fehler" || e.status==="duplikat").length,
    anhaenge:         log.flatMap(e => e.anhaenge||[]).length,
    ungelesen:        log.filter(e => !e.als_gelesen).length,
  };

  const gefiltert = log
    .filter(e => filter==="alle" || e.status===filter)
    .filter(e => {
      if (!suche) return true;
      const s = suche.toLowerCase();
      return [e.von_email, e.von_name, e.betreff, e.erkannt_az, e.erkannt_kfz, e.akte_az]
        .some(f => f?.toLowerCase().includes(s));
    });

  const startImport = async () => {
    if (importing) return;
    setImporting(true); setResult(null); setStep(0);

    // Schrittweise Animation
    let step = 0;
    const advanceStep = () => new Promise(r => {
      step++;
      if (step < IMPORT_STEPS.length) { setStep(step); setTimeout(r, 420 + Math.random()*160); }
      else { setStep(step); setTimeout(r, 300); }
    });

    // Backend-Aufruf parallel zur Animation
    const runAnimation = async () => {
      for (let i = 0; i < IMPORT_STEPS.length; i++) await advanceStep();
    };

    const apiCallPromise = apiEmail.starten().catch(() => null); // null bei Demo-Modus
    await Promise.all([runAnimation(), apiCallPromise.then(() => {})]);
    const apiResult = await apiCallPromise;

    const now = new Date().toLocaleTimeString("de-DE",{hour:"2-digit",minute:"2-digit"});

    if (apiResult?.neue_emails) {
      // Echte API-Antwort
      const newEntries = (apiResult.neue_emails || []).map((e, i) => ({ ...e, id: Date.now() + i, als_gelesen: false }));
      if (newEntries.length) setLog(prev => [...newEntries, ...prev]);
      setResult({ neu: apiResult.neue_emails.length, zugeordnet: apiResult.zugeordnet ?? 0, anhaenge: apiResult.anhaenge ?? 0 });
      setToast(`Import: ${apiResult.neue_emails.length} neue E-Mail(s) importiert.`);
    } else {
      // Demo-Modus: Mock-Einträge
      const newEntries = [
        { id:Date.now(),   empfangen_am:`09.03.2026 ${now}`, von_email:"rv-info@ruv.de",    von_name:"R+V Versicherung", betreff:"Weitere Unterlagen zu AZ 1087/24 angefordert",    erkannt_az:"1087/24", erkannt_kfz:null,      match:"aktenzeichen",    akte_az:"1087/24", akte_id:12, anhaenge:[{name:"Anforderung_RV_neu.pdf",size:98700,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.84}], status:"zugeordnet", als_gelesen:false },
        { id:Date.now()+1, empfangen_am:`09.03.2026 ${now}`, von_email:"devk-info@devk.de", von_name:"DEVK",             betreff:"OF-WK 7 – ergänzende Stellungnahme zum Schaden", erkannt_az:null,      erkannt_kfz:"OF-WK 7",  match:"kfz_kennzeichen", akte_az:"40/25", akte_id:3,  anhaenge:[],                                                                                           status:"zugeordnet", als_gelesen:false },
      ];
      setLog(prev => [...newEntries, ...prev]);
      setResult({ neu:2, zugeordnet:2, anhaenge:1 });
      setToast("Import abgeschlossen: 2 neue E-Mails importiert. (Demo-Modus)");
    }

    setImporting(false); setStep(-1);
  };

  const markRead    = id  => setLog(prev => prev.map(e => e.id===id ? {...e, als_gelesen:true} : e));
  const markAllRead = ()  => setLog(prev => prev.map(e => ({...e, als_gelesen:true})));

  const handleOpenAkte = entry => {
    if (entry.akte_az) {
      onOpenAkte({ az: entry.akte_az, id: entry.akte_az, az_roh: entry.akte_az,
                   status: "offen", brutto: 0, hq: 100,
                   unfalldatum: "", unfallort: "" });
    }
  };

  return (
    <div style={{ flex:1, overflowY:"auto", background:T.offWhite }}>
      {toast && <Toast msg={toast} onDone={() => setToast("")}/>}
      <div style={{ maxWidth:1440, margin:"0 auto", padding:"1.75rem" }}>

        {/* Header */}
        <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", marginBottom:"1.5rem", flexWrap:"wrap", gap:12 }}>
          <div>
            <h1 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"2.0rem", fontWeight:700, color:T.navy, margin:0 }}>E-Mail-Import</h1>
            <p style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.955rem", color:T.textMuted, marginTop:4 }}>
              Automatischer IMAP-Import · Letzte Synchronisation: <span style={{ fontWeight:600, color:T.text }}>{IMAP_CONFIG.letzte_sync} Uhr</span>
            </p>
          </div>
          <div style={{ display:"flex", gap:10, alignItems:"center", flexWrap:"wrap" }}>
            <div style={{ display:"flex", alignItems:"center", gap:7, background:T.white, border:`1px solid ${T.border}`, borderRadius:8, padding:"7px 13px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.925rem", color:T.textMid }}>
              <span style={{ width:8, height:8, borderRadius:"50%", background:T.green, display:"block" }}/>
              Verbunden · {IMAP_CONFIG.host}
            </div>
            {stats.ungelesen > 0 && (
              <button onClick={markAllRead} style={{ display:"flex", alignItems:"center", gap:6, padding:"7px 13px", background:T.surface, border:`1px solid ${T.border}`, borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.925rem", color:T.textMid, cursor:"pointer" }}>
                {Ic.check} Alle als gelesen
              </button>
            )}
            <button onClick={startImport} disabled={importing}
              style={{ display:"flex", alignItems:"center", gap:8, padding:"9px 18px", background:importing?T.navyMid:T.navy, color:T.white, border:"none", borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.975rem", fontWeight:600, cursor:importing?"default":"pointer", position:"relative", overflow:"hidden", minWidth:200 }}>
              {importing
                ? <><div style={{ width:14, height:14, border:"2px solid rgba(255,255,255,0.3)", borderTopColor:"white", borderRadius:"50%", animation:"spin 0.7s linear infinite" }}/>{IMPORT_STEPS[importStep]||"…"}</>
                : <>{Ic.refresh} Jetzt importieren</>}
              <div style={{ position:"absolute", bottom:0, left:0, right:0, height:2, background:`linear-gradient(90deg,${T.gold},${T.goldLight})` }}/>
            </button>
          </div>
        </div>

        {/* Result Banner */}
        {importResult && (
          <div style={{ background:T.greenBg, border:`1px solid ${T.green}33`, borderRadius:10, padding:"12px 16px", marginBottom:"1.25rem", display:"flex", alignItems:"center", gap:12, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.975rem", color:T.green }}>
            {Ic.check}
            <span><strong>{importResult.neu} neue E-Mails</strong> importiert · {importResult.zugeordnet} Akten zugeordnet · {importResult.anhaenge} Anhang geparst</span>
            <button onClick={() => setResult(null)} style={{ marginLeft:"auto", background:"none", border:"none", cursor:"pointer", color:T.green, display:"flex" }}>{Ic.x}</button>
          </div>
        )}

        {/* KPI-Karten + Konfig-Kachel */}
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(155px,1fr))", gap:"1rem", marginBottom:"1.25rem" }}>
          {[
            { label:"Gesamt",           v:stats.gesamt,           c:T.navy,      f:"alle"            },
            { label:"Zugeordnet",       v:stats.zugeordnet,       c:T.green,     f:"zugeordnet"      },
            { label:"Nicht zugeordnet", v:stats.nicht_zugeordnet, c:T.amber,     f:"nicht_zugeordnet"},
            { label:"Fehler",           v:stats.fehler,           c:T.red,       f:"fehler"          },
            { label:"Anhänge",          v:stats.anhaenge,         c:T.blue,      f:"alle"            },
            { label:"Ungelesen",        v:stats.ungelesen,        c:T.textMuted, f:"alle"            },
          ].map((k,i) => (
            <div key={i} onClick={() => setFilter(k.f)} style={{ background:T.white, borderRadius:12, padding:"1rem 1.25rem", border:`1px solid ${T.border}`, borderTop:`3px solid ${k.c}`, boxShadow:"0 2px 6px rgba(0,0,0,0.04)", cursor:"pointer", transition:"transform 0.15s,box-shadow 0.15s" }}
              onMouseEnter={e => { e.currentTarget.style.transform="translateY(-2px)"; e.currentTarget.style.boxShadow="0 6px 20px rgba(0,0,0,0.09)"; }}
              onMouseLeave={e => { e.currentTarget.style.transform=""; e.currentTarget.style.boxShadow="0 2px 6px rgba(0,0,0,0.04)"; }}>
              <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.805rem", fontWeight:600, letterSpacing:"0.08em", textTransform:"uppercase", color:T.textMuted, marginBottom:8 }}>{k.label}</div>
              <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"2.325rem", fontWeight:700, color:k.c, lineHeight:1 }}>{k.v}</div>
            </div>
          ))}

          {/* IMAP-Konfig-Kachel */}
          <div onClick={() => setShowKonfigDialog(true)}
            style={{ background:T.white, borderRadius:12, padding:"1rem 1.25rem", border:`1px solid ${T.border}`, borderTop:`3px solid ${verbunden ? T.green : T.red}`, boxShadow:"0 2px 6px rgba(0,0,0,0.04)", cursor:"pointer", transition:"transform 0.15s,box-shadow 0.15s", display:"flex", flexDirection:"column", justifyContent:"space-between", minHeight:100 }}
            onMouseEnter={e => { e.currentTarget.style.transform="translateY(-2px)"; e.currentTarget.style.boxShadow="0 6px 20px rgba(0,0,0,0.09)"; }}
            onMouseLeave={e => { e.currentTarget.style.transform=""; e.currentTarget.style.boxShadow="0 2px 6px rgba(0,0,0,0.04)"; }}>
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
              <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.805rem", fontWeight:600, letterSpacing:"0.08em", textTransform:"uppercase", color:T.textMuted }}>E-Mail</div>
              <svg viewBox="0 0 24 24" fill={T.textFaint} style={{ width:15, height:15 }}><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>
            </div>
            <div>
              <div style={{ display:"flex", alignItems:"center", gap:6, marginBottom:4 }}>
                <span style={{ width:10, height:10, borderRadius:"50%", background: verbunden ? T.green : T.red, display:"block", flexShrink:0, boxShadow: verbunden ? `0 0 0 3px ${T.green}22` : `0 0 0 3px ${T.red}22` }}/>
                <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", fontWeight:600, color: verbunden ? T.green : T.red }}>
                  {verbunden ? "Verbunden" : "Getrennt"}
                </span>
              </div>
              <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.78rem", color:T.textFaint, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                {angezeigteKfg.host}
              </div>
            </div>
          </div>
        </div>

        {/* Import-Log Tabelle */}
        <Card>
          <div style={{ display:"flex", alignItems:"center", gap:10, padding:"0.9rem 1.4rem", borderBottom:`1px solid ${T.border}`, flexWrap:"wrap" }}>
            <h2 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.35rem", fontWeight:700, color:T.navy, margin:0, flex:1 }}>
              Import-Log
              {stats.ungelesen > 0 && <span style={{ marginLeft:8, fontSize:"0.845rem", fontWeight:600, background:T.blue, color:T.white, borderRadius:10, padding:"2px 8px" }}>{stats.ungelesen} neu</span>}
            </h2>
            <div style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
              {[["alle","Alle",stats.gesamt],["zugeordnet","Zugeordnet",stats.zugeordnet],["nicht_zugeordnet","Nicht zugeordnet",stats.nicht_zugeordnet],["fehler","Fehler",stats.fehler]].map(([f,l,cnt]) => {
                const es = EMAIL_STATUS[f]; const isA = filter===f;
                return <button key={f} onClick={() => setFilter(f)} style={{ padding:"4px 9px", borderRadius:20, border:`1px solid ${isA?(es?.color||T.navy):T.border}`, background:isA?(es?.bg||T.goldPale):"transparent", color:isA?(es?.color||T.navy):T.textMuted, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600, cursor:"pointer" }}>{l} ({cnt})</button>;
              })}
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:7, background:T.surface, border:`1px solid ${T.border}`, borderRadius:8, padding:"5px 10px" }}>
              <span style={{ color:T.textFaint }}>{Ic.search}</span>
              <input placeholder="Absender, Betreff, AZ …" value={suche} onChange={e => setSuche(e.target.value)} style={{ border:"none", background:"transparent", outline:"none", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.955rem", color:T.text, width:195 }}/>
            </div>
          </div>

          <div style={{ overflowX:"auto" }}>
            <table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead>
                <tr style={{ background:T.surface }}>
                  {["","Empfangen","Absender","Betreff","Erkennung","Zugeordnete Akte","Anhänge","Status",""].map((h,i) => (
                    <th key={i} style={{ padding:"8px 12px", textAlign:"left", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.815rem", fontWeight:600, color:T.textMuted, letterSpacing:"0.06em", textTransform:"uppercase", borderBottom:`1px solid ${T.border}`, whiteSpace:"nowrap" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {gefiltert.map((e, i) => {
                  const isExp = expanded === e.id;
                  const mc = MATCH_LABELS[e.match];
                  const es = EMAIL_STATUS[e.status] || EMAIL_STATUS.nicht_zugeordnet;
                  return (
                    <React.Fragment key={e.id}>
                      <tr
                        style={{ borderBottom:`1px solid ${T.borderSoft}`, background:!e.als_gelesen?"rgba(59,130,246,0.04)":i%2===0?T.white:T.surface, cursor:"pointer", transition:"background 0.1s" }}
                        onMouseEnter={ev => ev.currentTarget.style.background = T.goldPale}
                        onMouseLeave={ev => ev.currentTarget.style.background = !e.als_gelesen?"rgba(59,130,246,0.04)":i%2===0?T.white:T.surface}>
                        <td style={{ padding:"10px 6px 10px 14px", width:18 }} onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}>
                          {!e.als_gelesen && <span style={{ width:8, height:8, borderRadius:"50%", background:T.blue, display:"block" }}/>}
                        </td>
                        <td style={{ padding:"10px 12px", whiteSpace:"nowrap" }} onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}>
                          <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.905rem", color:T.textMid }}>{e.empfangen_am}</div>
                        </td>
                        <td style={{ padding:"10px 12px", maxWidth:180 }} onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}>
                          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.955rem", fontWeight:e.als_gelesen?400:600, color:T.text, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{e.von_name||e.von_email}</div>
                          <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.825rem", color:T.textFaint, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{e.von_email}</div>
                        </td>
                        <td style={{ padding:"10px 12px", maxWidth:240 }} onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}>
                          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.955rem", fontWeight:e.als_gelesen?400:600, color:T.text, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{e.betreff || <span style={{ color:T.textFaint }}>(kein Betreff)</span>}</div>
                        </td>
                        <td style={{ padding:"10px 12px" }} onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}>
                          {mc ? (
                            <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
                              <span style={{ display:"inline-flex", alignItems:"center", background:`${mc.color}18`, color:mc.color, border:`1px solid ${mc.color}33`, borderRadius:10, padding:"1px 7px", fontSize:"0.815rem", fontWeight:600, whiteSpace:"nowrap" }}>{mc.label}</span>
                              <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.875rem", color:T.textMid, fontWeight:600 }}>{e.erkannt_az || e.erkannt_kfz || "–"}</span>
                            </div>
                          ) : <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.905rem", color:T.textFaint }}>–</span>}
                        </td>
                        <td style={{ padding:"10px 12px" }}>
                          {e.akte_az ? (
                            <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                              <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.945rem", fontWeight:600, color:T.navy }}>{e.akte_az}</span>
                              <button onClick={ev => { ev.stopPropagation(); handleOpenAkte(e); }}
                                style={{ background:T.goldPale, border:`1px solid rgba(200,168,75,0.3)`, borderRadius:5, padding:"2px 7px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", cursor:"pointer", color:T.navy, fontWeight:600, display:"flex", alignItems:"center", gap:3 }}>
                                {Ic.chevR} Öffnen
                              </button>
                            </div>
                          ) : <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.905rem", color:T.textFaint }}>–</span>}
                        </td>
                        <td style={{ padding:"10px 12px" }} onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}>
                          {(e.anhaenge||[]).length > 0 ? (
                            <div style={{ display:"flex", alignItems:"center", gap:5 }}>
                              <span style={{ color:T.textMuted }}>{Ic.attach}</span>
                              <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.905rem", color:T.textMid }}>{e.anhaenge.length}</span>
                              {e.anhaenge.some(a => a.parse_status==="erfolgreich") && <span style={{ fontSize:"0.805rem", background:T.greenBg, color:T.green, border:`1px solid ${T.green}33`, borderRadius:8, padding:"0px 5px" }}>geparst</span>}
                            </div>
                          ) : <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.905rem", color:T.textFaint }}>–</span>}
                        </td>
                        <td style={{ padding:"10px 12px" }} onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}>
                          <StatusBadge status={e.status} map={EMAIL_STATUS}/>
                        </td>
                        <td style={{ padding:"10px 12px" }}>
                          <button onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}
                            style={{ background:"none", border:"none", cursor:"pointer", color:T.textFaint, display:"flex", padding:4, borderRadius:4 }}
                            onMouseEnter={ev => ev.currentTarget.style.color=T.navy}
                            onMouseLeave={ev => ev.currentTarget.style.color=T.textFaint}>
                            <svg viewBox="0 0 24 24" fill="currentColor" style={{ width:14, height:14, transform:isExp?"rotate(180deg)":"none", transition:"transform 0.2s" }}><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"/></svg>
                          </button>
                        </td>
                      </tr>

                      {isExp && (
                        <tr>
                          <td colSpan={9} style={{ padding:"0 14px 14px 38px", background:T.goldPale, borderBottom:`1px solid ${T.border}` }}>
                            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:"1rem", paddingTop:"1rem" }}>
                              {/* E-Mail Details */}
                              <div>
                                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:8 }}>E-Mail-Details</div>
                                {[["Von",`${e.von_name} <${e.von_email}>`],["Betreff",e.betreff||"(kein Betreff)"],["Empfangen",e.empfangen_am],["Status",e.als_gelesen?"Gelesen":"Ungelesen"]].map(([l,v]) => (
                                  <div key={l} style={{ display:"flex", gap:8, marginBottom:6 }}>
                                    <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.835rem", color:T.textFaint, width:80, flexShrink:0 }}>{l}</span>
                                    <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.915rem", color:T.text, wordBreak:"break-all" }}>{v}</span>
                                  </div>
                                ))}
                                {e.fehler && <div style={{ marginTop:8, background:T.redBg, border:`1px solid ${T.red}33`, borderRadius:7, padding:"7px 10px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.905rem", color:T.red }}>⚠ {e.fehler}</div>}
                              </div>
                              {/* Parser */}
                              <div>
                                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:8 }}>Parser-Ergebnis</div>
                                {[["Erkanntes AZ",e.erkannt_az||"–"],["Erkanntes KFZ",e.erkannt_kfz||"–"],["Match-Methode",e.match?MATCH_LABELS[e.match]?.label:"Keine Übereinstimmung"],["Zugeordnet zu",e.akte_az||"–"]].map(([l,v]) => (
                                  <div key={l} style={{ display:"flex", gap:8, marginBottom:6 }}>
                                    <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.835rem", color:T.textFaint, width:120, flexShrink:0 }}>{l}</span>
                                    <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.915rem", color:T.text, fontWeight:(e.erkannt_az&&l==="Erkanntes AZ")||(e.akte_az&&l==="Zugeordnet zu")?600:400 }}>{v}</span>
                                  </div>
                                ))}
                              </div>
                              {/* Anhänge */}
                              <div>
                                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:8 }}>Anhänge ({(e.anhaenge||[]).length})</div>
                                {(e.anhaenge||[]).length === 0
                                  ? <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.925rem", color:T.textFaint }}>Keine Anhänge</div>
                                  : (e.anhaenge||[]).map((a,ai) => {
                                      const isPdf = a.typ==="pdf";
                                      const ps = a.parse_status==="erfolgreich"?{c:T.green,l:"Geparst"}:a.parse_status==="nicht_unterstuetzt"?{c:T.amber,l:"Nicht unterstützt"}:{c:T.textMuted,l:a.parse_status};
                                      return (
                                        <div key={ai} style={{ display:"flex", alignItems:"center", gap:8, background:T.white, border:`1px solid ${T.border}`, borderRadius:7, padding:"7px 10px", marginBottom:5 }}>
                                          <span style={{ color:isPdf?T.red:T.textMuted }}>{isPdf?Ic.pdf:Ic.attach}</span>
                                          <div style={{ flex:1, minWidth:0 }}>
                                            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.905rem", fontWeight:600, color:T.text, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{a.name}</div>
                                            <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.805rem", color:T.textFaint }}>{fmtSize(a.size)}</div>
                                          </div>
                                          <div style={{ display:"flex", alignItems:"center", gap:6, flexShrink:0 }}>
                                            <span style={{ fontSize:"0.805rem", fontWeight:600, color:ps.c }}>{ps.l}</span>
                                            {a.konfidenz!=null && <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.805rem", color:a.konfidenz>0.7?T.green:T.amber }}>{Math.round(a.konfidenz*100)} %</span>}
                                            {a.dokument_id && e.akte_id ? (
                                              <button onClick={async () => {
                                                try { await apiDokumente.download(e.akte_id, a.dokument_id, a.name); }
                                                catch { alert(`Anhang "${a.name}" konnte nicht heruntergeladen werden.`); }
                                              }} style={{ display:"flex", alignItems:"center", gap:3, padding:"3px 8px", background:T.navy, color:T.white, border:"none", borderRadius:5, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem", fontWeight:600, cursor:"pointer" }}>
                                                {Ic.download} Download
                                              </button>
                                            ) : (
                                              <span style={{ fontSize:"0.805rem", color:T.textFaint, fontStyle:"italic" }}>in Akte</span>
                                            )}
                                          </div>
                                        </div>
                                      );
                                    })
                                }
                                {e.akte_id && (
                                  <button onClick={() => handleOpenAkte(e)} style={{ marginTop:6, width:"100%", display:"flex", alignItems:"center", justifyContent:"center", gap:6, padding:"7px", background:T.navy, color:T.white, border:"none", borderRadius:7, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.905rem", fontWeight:600, cursor:"pointer" }}>
                                    {Ic.akte} Akte {e.akte_az} öffnen
                                  </button>
                                )}
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div style={{ padding:"8px 1.4rem", borderTop:`1px solid ${T.border}`, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.845rem", color:T.textFaint, display:"flex", justifyContent:"space-between" }}>
            <span>{gefiltert.length} von {log.length} Einträgen</span>
            <span>Klick auf Zeile expandiert Details · „Öffnen" springt zur Akte</span>
          </div>
        </Card>
      </div>

      {/* ── IMAP-Konfigurationsdialog ─────────────────────────────── */}
      {showKonfigDialog && (
        <ImapKonfigDialog
          cfg={angezeigteKfg}
          onClose={() => setShowKonfigDialog(false)}
          onGespeichert={(neueCfg) => {
            setImapCfg(neueCfg);
            setShowKonfigDialog(false);
            setToast("Konfiguration gespeichert. Bitte Server neu starten, damit .env-Änderungen wirksam werden.");
          }}
        />
      )}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   MODUL 8: WIEDERVORLAGE VIEW
══════════════════════════════════════════════════════════════ */
function WiedervorlageView({ onOpenAkte }) {
  const [wvListe,       setWvListe]       = useState(null);
  const [wvSeite,       setWvSeite]       = useState(1);
  const WV_SEITE_GROESSE = 50;
  const [bereitsErstellt, setBereitsErstellt] = useState(new Set());
  const [ramicroStatus, setRamicroStatus] = useState(null);
  const [loading,       setLoading]       = useState(true);
  const [fehler,        setFehler]        = useState(null);
  const [filterHeute,   setFilterHeute]   = useState(false);
  const [filterAlleWv,  setFilterAlleWv]  = useState(false);
  const [filterSb,      setFilterSb]      = useState("");
  const [filterGrund,   setFilterGrund]   = useState("");
  const [ausgewaehlt,   setAusgewaehlt]   = useState(new Set());
  const [batchLaeuft,   setBatchLaeuft]   = useState(false);
  const [batchFortschritt, setBatchFortschritt] = useState({ aktuell: 0, gesamt: 0 });
  const [einzelnLaedt,  setEinzelnLaedt]  = useState(new Set());
  const [toast,         setToast]         = useState("");
  const [adressatenMap, setAdressatenMap] = useState({});        // guid → [{adress_nr, name, ort, kennzeichen}]
  const [adressWahl,    setAdressWahl]    = useState({});        // guid → adress_nr (null = Fallback)
  const [beteiligteLoading, setBeteiligteLoading] = useState(new Set());

  const zeigeToast = (msg) => { setToast(msg); setTimeout(() => setToast(""), 3500); };

  const lade = useCallback(async () => {
    setLoading(true); setFehler(null);
    try {
      const [statusRes, listeRes, bereitsRes] = await Promise.allSettled([
        apiWV.status(),
        apiWV.liste({ nurHeute: filterHeute && !filterAlleWv, nurStellungnahme: !filterAlleWv, sb: filterSb || null, grund: filterGrund || null }),
        apiWV.bereitsErstellt(),
      ]);
      if (statusRes.status === "fulfilled") setRamicroStatus(statusRes.value);
      if (listeRes.status   === "fulfilled") setWvListe(listeRes.value?.wiedervorlagen || []);
      else setFehler(listeRes.reason?.message || "RA-Micro nicht erreichbar");
      if (bereitsRes.status === "fulfilled")
        setBereitsErstellt(new Set(bereitsRes.value?.aktenzeichen || []));
    } catch (e) {
      setFehler(e.message || "Unbekannter Fehler");
    } finally {
      setLoading(false);
    }
  }, [filterHeute, filterAlleWv, filterSb, filterGrund]);

  // Seite zurücksetzen wenn Filter sich ändert
  useEffect(() => { setWvSeite(1); }, [filterHeute, filterAlleWv, filterSb, filterGrund]);

  useEffect(() => { lade(); }, [lade]);

  // ── Auswahl-Logik ─────────────────────────────────────────────────────────
  const alleIds       = (wvListe || []).map(w => w.guid);
  const alleAusgewaehlt = alleIds.length > 0 && alleIds.every(id => ausgewaehlt.has(id));
  const toggleAlle    = () => setAusgewaehlt(alleAusgewaehlt ? new Set() : new Set(alleIds));
  const toggleEinen   = (id) => setAusgewaehlt(prev => {
    const n = new Set(prev);
    n.has(id) ? n.delete(id) : n.add(id);
    return n;
  });

  // ── Einzelner Download ────────────────────────────────────────────────────
  const einzelnGenerieren = async (wv) => {
    setEinzelnLaedt(p => new Set(p).add(wv.guid));
    const adressNr = adressWahl[wv.guid] ?? null;
    try {
      await apiWV.sachstandsanfrage(wv.guid, wv.aktenzeichen, adressNr);
      setBereitsErstellt(p => new Set(p).add(wv.aktenzeichen));
      zeigeToast(`✓ ${wv.aktenzeichen} – Sachstandsanfrage heruntergeladen`);
    } catch (e) {
      zeigeToast(`Fehler bei ${wv.aktenzeichen}: ${e.message}`);
    } finally {
      setEinzelnLaedt(p => { const n = new Set(p); n.delete(wv.guid); return n; });
    }
  };

  // ── Beteiligte lazy laden ────────────────────────────────────────────────
  const ladeBeteiligte = async (guid, grund = "", bezeichnung = "", referat = 0) => {
    if (adressatenMap[guid] || beteiligteLoading.has(guid)) return;
    setBeteiligteLoading(p => new Set(p).add(guid));
    try {
      const res = await apiWV.beteiligte(guid, { grund, bezeichnung, referat });
      const liste = res?.beteiligte || [];
      setAdressatenMap(prev => ({ ...prev, [guid]: liste }));
      // Vorauswahl nur setzen wenn der Nutzer noch nichts manuell gewählt hat
      if (res?.vorauswahl_adress_nr != null) {
        setAdressWahl(prev => ({
          ...prev,
          [guid]: prev[guid] !== undefined ? prev[guid] : res.vorauswahl_adress_nr,
        }));
      }
    } catch (e) {
      setAdressatenMap(prev => ({ ...prev, [guid]: [] }));
    } finally {
      setBeteiligteLoading(p => { const n = new Set(p); n.delete(guid); return n; });
    }
  };

  // ── Batch: einzeln nacheinander ───────────────────────────────────────────
  const batchEinzeln = async () => {
    const liste = (wvListe || []).filter(w => ausgewaehlt.has(w.guid));
    setBatchLaeuft(true);
    setBatchFortschritt({ aktuell: 0, gesamt: liste.length });
    let ok = 0;
    for (let i = 0; i < liste.length; i++) {
      setBatchFortschritt({ aktuell: i + 1, gesamt: liste.length });
      try {
        await apiWV.sachstandsanfrage(liste[i].guid, liste[i].aktenzeichen);
        setBereitsErstellt(p => new Set(p).add(liste[i].aktenzeichen));
        ok++;
        await new Promise(r => setTimeout(r, 350)); // kurze Pause zwischen Downloads
      } catch (e) {
        console.error("Batch-Fehler:", liste[i].aktenzeichen, e);
      }
    }
    setBatchLaeuft(false);
    zeigeToast(`${ok} von ${liste.length} Sachstandsanfragen heruntergeladen`);
  };

  // ── Batch: als ZIP ────────────────────────────────────────────────────────
  const batchZip = async () => {
    const guids = [...ausgewaehlt];
    setBatchLaeuft(true);
    try {
      await apiWV.batchZip(guids);
      const neueAz = (wvListe || [])
        .filter(w => ausgewaehlt.has(w.guid))
        .map(w => w.aktenzeichen);
      setBereitsErstellt(p => new Set([...p, ...neueAz]));
      zeigeToast(`${guids.length} Sachstandsanfragen als ZIP heruntergeladen`);
    } catch (e) {
      zeigeToast(`ZIP-Fehler: ${e.message}`);
    } finally {
      setBatchLaeuft(false);
    }
  };

  // ── Sachbearbeiter-Liste für Filter ──────────────────────────────────────
  const sbListe    = [...new Set((wvListe || []).map(w => w.sachbearbeiter).filter(Boolean))].sort();
  const grundListe = [...new Set((wvListe || []).map(w => w.grund).filter(Boolean))].sort();

  // ── Marker-Komponente ─────────────────────────────────────────────────────
  const Marker = ({ erstellt }) => erstellt
    ? <span title="Sachstandsanfrage bereits erstellt" style={{
        display:"inline-flex", alignItems:"center", gap:4,
        background:"#d1fae5", color:"#065f46",
        border:"1.5px solid #6ee7b7",
        borderRadius:20, padding:"3px 10px 3px 7px",
        fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", fontWeight:600,
        whiteSpace:"nowrap",
      }}>
        <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
          <circle cx="6.5" cy="6.5" r="6.5" fill="#10b981"/>
          <path d="M3.5 6.5L5.5 8.5L9.5 4.5" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        Erstellt
      </span>
    : <span title="Noch nicht erstellt" style={{
        display:"inline-flex", alignItems:"center", gap:4,
        background:"#fff1f2", color:"#9f1239",
        border:"1.5px solid #fca5a5",
        borderRadius:20, padding:"3px 10px 3px 7px",
        fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", fontWeight:600,
        whiteSpace:"nowrap",
      }}>
        <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
          <circle cx="6.5" cy="6.5" r="6.5" fill="#f87171"/>
          <path d="M4.5 4.5L8.5 8.5M8.5 4.5L4.5 8.5" stroke="white" strokeWidth="1.8" strokeLinecap="round"/>
        </svg>
        Offen
      </span>;

  // ── Status-Banner ─────────────────────────────────────────────────────────
  const StatusBanner = () => {
    if (!ramicroStatus) return null;
    const isOk  = ramicroStatus.status === "ok";
    const isDeak = ramicroStatus.status === "deaktiviert";
    return (
      <div style={{
        display:"flex", alignItems:"center", gap:10,
        background: isOk ? "#f0fdf4" : isDeak ? "#fffbeb" : "#fff1f2",
        border: `1px solid ${isOk ? "#86efac" : isDeak ? "#fcd34d" : "#fca5a5"}`,
        borderRadius:10, padding:"10px 16px", marginBottom:"1.25rem",
        fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.885rem",
      }}>
        <span style={{ fontSize:"1.1rem" }}>{isOk ? "🟢" : isDeak ? "🟡" : "🔴"}</span>
        <span style={{ color: isOk ? "#065f46" : isDeak ? "#92400e" : "#9f1239", fontWeight:500 }}>
          {isOk
            ? `RA-Micro verbunden · ${ramicroStatus.host} · DB: ${ramicroStatus.datenbank}`
            : isDeak
            ? "RA-Micro Verbindung deaktiviert – RAMICRO_AKTIV=true in .env setzen"
            : `RA-Micro nicht erreichbar: ${ramicroStatus.meldung || ""}`}
        </span>
      </div>
    );
  };

  const anAusgewaehlt   = ausgewaehlt.size;
  const wvGesamtAnzahl  = (wvListe || []).length;
  const wvGesamtSeiten  = Math.max(1, Math.ceil(wvGesamtAnzahl / WV_SEITE_GROESSE));
  const wvSeiteKorr     = Math.min(wvSeite, wvGesamtSeiten);
  const wvListeSeite    = (wvListe || []).slice((wvSeiteKorr - 1) * WV_SEITE_GROESSE, wvSeiteKorr * WV_SEITE_GROESSE);

  return (
    <div style={{ flex:1, overflowY:"auto", background:T.offWhite }}>
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
      <div style={{ maxWidth:1440, margin:"0 auto", padding:"1.75rem" }}>

        {/* Header */}
        <div style={{ marginBottom:"1.5rem", display:"flex", alignItems:"flex-end", justifyContent:"space-between", flexWrap:"wrap", gap:12 }}>
          <div>
            <h1 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"2.0rem", fontWeight:700, color:T.navy, margin:0 }}>
              Wiedervorlage
            </h1>
            <p style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.955rem", color:T.textMuted, marginTop:4, margin:0 }}>
              Fällige Stellungnahmen Gegner · RA-Micro Integration
            </p>
          </div>
          <button onClick={lade} disabled={loading}
            style={{ display:"flex", alignItems:"center", gap:6, padding:"8px 14px",
              background:T.navy, color:T.white, border:"none", borderRadius:8,
              fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.9rem", fontWeight:500, cursor:"pointer", opacity:loading?0.6:1 }}>
            <span style={{ display:"inline-block", animation:loading?"spin 0.7s linear infinite":"none" }}>↻</span>
            Aktualisieren
          </button>
        </div>

        <StatusBanner />

        {/* Filterzeile */}
        <div style={{ display:"flex", gap:10, marginBottom:"1.25rem", flexWrap:"wrap", alignItems:"center" }}>
          <label style={{ display:"flex", alignItems:"center", gap:7, background:T.white, border:`1px solid ${T.border}`, borderRadius:8, padding:"7px 13px", cursor:"pointer", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.895rem", color:T.textMid, userSelect:"none" }}>
            <input type="checkbox" checked={filterHeute} onChange={e => {
                setFilterHeute(e.target.checked);
                if (e.target.checked) setFilterAlleWv(false);
              }} style={{ accentColor:T.navy, width:15, height:15 }} />
            Nur heute fällig
          </label>
          <label style={{ display:"flex", alignItems:"center", gap:7, background:T.white, border:`1px solid ${T.border}`, borderRadius:8, padding:"7px 13px", cursor:"pointer", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.895rem", color:T.textMid, userSelect:"none" }}>
            <input type="checkbox" checked={filterAlleWv} onChange={e => {
                setFilterAlleWv(e.target.checked);
                if (e.target.checked) setFilterHeute(false);
              }} style={{ accentColor:T.navy, width:15, height:15 }} />
            Alle Wiedervorlagen
          </label>
          {grundListe.length > 0 && (
            <select value={filterGrund} onChange={e => setFilterGrund(e.target.value)}
              style={{ padding:"7px 13px", background:T.white, border:`1px solid ${T.border}`, borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.895rem", color:T.textMid, cursor:"pointer", maxWidth:220 }}>
              <option value="">Alle WV-Gründe</option>
              {grundListe.map(g => <option key={g} value={g}>{g}</option>)}
            </select>
          )}
          {sbListe.length > 0
            ? <select value={filterSb} onChange={e => setFilterSb(e.target.value)}
                style={{ padding:"7px 13px", background:T.white, border:`1px solid ${T.border}`, borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.895rem", color:T.textMid, cursor:"pointer" }}>
                <option value="">Alle Sachbearbeiter</option>
                {sbListe.map(sb => <option key={sb} value={sb}>{sb}</option>)}
              </select>
            : <input value={filterSb} onChange={e => setFilterSb(e.target.value)}
                placeholder="SB-Kürzel (z.B. AS)"
                style={{ padding:"7px 13px", background:T.white, border:`1px solid ${T.border}`, borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.895rem", color:T.textMid, width:160 }} />
          }
          {wvListe && (
            <span style={{ marginLeft:"auto", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.865rem", color:T.textMuted }}>
              {wvGesamtAnzahl} Einträge
              {wvGesamtSeiten > 1 && <span> · Seite {wvSeiteKorr}/{wvGesamtSeiten}</span>}
              {anAusgewaehlt > 0 && <strong style={{ color:T.navy }}> · {anAusgewaehlt} ausgewählt</strong>}
            </span>
          )}
        </div>

        {/* Batch-Aktionsleiste */}
        {anAusgewaehlt > 0 && (
          <div style={{ display:"flex", alignItems:"center", gap:10, background:T.navy, borderRadius:10, padding:"11px 16px", marginBottom:"1.25rem", flexWrap:"wrap" }}>
            <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.9rem", color:T.white, fontWeight:500, flex:1 }}>
              {batchLaeuft && batchFortschritt.gesamt > 0
                ? `Generiere ${batchFortschritt.aktuell} / ${batchFortschritt.gesamt} …`
                : `${anAusgewaehlt} ausgewählt`}
            </span>
            <button onClick={batchEinzeln} disabled={batchLaeuft}
              style={{ display:"flex", alignItems:"center", gap:6, padding:"8px 15px", background:"rgba(255,255,255,0.12)", color:T.white, border:"1px solid rgba(255,255,255,0.25)", borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.9rem", fontWeight:500, cursor:batchLaeuft?"default":"pointer", opacity:batchLaeuft?0.6:1 }}>
              📄 Einzeln herunterladen
            </button>
            <button onClick={batchZip} disabled={batchLaeuft}
              style={{ display:"flex", alignItems:"center", gap:6, padding:"8px 15px", background:T.gold, color:T.navy, border:"none", borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.9rem", fontWeight:600, cursor:batchLaeuft?"default":"pointer", opacity:batchLaeuft?0.6:1 }}>
              🗜 Als ZIP herunterladen
            </button>
            <button onClick={() => setAusgewaehlt(new Set())}
              style={{ padding:"8px 10px", background:"transparent", color:"rgba(255,255,255,0.5)", border:"none", borderRadius:8, cursor:"pointer", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.9rem" }}>
              ✕
            </button>
          </div>
        )}

        {/* Hauptinhalt */}
        {loading ? (
          <div style={{ display:"flex", justifyContent:"center", padding:"4rem", color:T.textMuted, fontFamily:"'IBM Plex Sans',sans-serif" }}>
            <div style={{ textAlign:"center" }}>
              <div style={{ width:32, height:32, border:`3px solid ${T.border}`, borderTopColor:T.navy, borderRadius:"50%", animation:"spin 0.7s linear infinite", margin:"0 auto 12px" }} />
              Lädt Wiedervorlagen aus RA-Micro …
            </div>
          </div>
        ) : fehler ? (
          <div style={{ background:"#fff1f2", border:"1px solid #fca5a5", borderRadius:12, padding:"2rem", textAlign:"center" }}>
            <div style={{ fontSize:"2rem", marginBottom:8 }}>⚠️</div>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontWeight:600, color:"#9f1239", marginBottom:6 }}>RA-Micro nicht erreichbar</div>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", color:"#6b7094" }}>{fehler}</div>
            <button onClick={lade} style={{ marginTop:14, padding:"8px 18px", background:T.navy, color:T.white, border:"none", borderRadius:8, cursor:"pointer", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.9rem" }}>
              Erneut versuchen
            </button>
          </div>
        ) : !wvListe || wvListe.length === 0 ? (
          <div style={{ background:T.white, borderRadius:12, border:`1px solid ${T.border}`, padding:"3rem", textAlign:"center" }}>
            <div style={{ fontSize:"2.5rem", marginBottom:12 }}>🎉</div>
            <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.2rem", fontWeight:700, color:T.navy, marginBottom:6 }}>
              Keine fälligen Wiedervorlagen
            </div>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.9rem", color:T.textMuted }}>
              Keine offenen „Stellungnahme Gegner"-Wiedervorlagen{filterHeute ? " für heute" : ""}.
            </div>
          </div>
        ) : (
          <div style={{ background:T.white, borderRadius:12, border:`1px solid ${T.border}`, overflow:"hidden" }}>
            <table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead>
                <tr style={{ background:T.navy }}>
                  {/* Alles-auswählen Checkbox */}
                  <th style={{ width:44, padding:"11px 14px" }}>
                    <input type="checkbox" checked={alleAusgewaehlt}
                      onChange={toggleAlle}
                      title="Alle auswählen"
                      style={{ accentColor:T.gold, width:16, height:16, cursor:"pointer" }} />
                  </th>
                  {[
                    { label:"Datum",         w:"100px"  },
                    { label:"Aktenzeichen",  w:"120px"  },
                    { label:"Akte",          w:null     },
                    { label:"SB",            w:"50px"   },
                    { label:"WV-Grund",      w:"180px"  },
                    { label:"Status",        w:"110px"  },
                    { label:"Adressat",      w:"200px"  },
                    { label:"Aktion",        w:"170px"  },
                  ].map(col => (
                    <th key={col.label} style={{ padding:"11px 14px", textAlign:"left", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", fontWeight:600, color:"rgba(255,255,255,0.75)", letterSpacing:"0.06em", textTransform:"uppercase", whiteSpace:"nowrap", ...(col.w ? { width:col.w } : {}) }}>
                      {col.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {wvListeSeite.map((wv, idx) => {
                  const istErstellt  = bereitsErstellt.has(wv.aktenzeichen);
                  const istAusgewaehlt = ausgewaehlt.has(wv.guid);
                  const istAmLaden   = einzelnLaedt.has(wv.guid);
                  const istHeute     = wv.datum === new Date().toISOString().slice(0,10);
                  const istUeberfaellig = wv.datum < new Date().toISOString().slice(0,10);
                  return (
                    <tr key={wv.guid}
                      style={{ background: istAusgewaehlt ? "#f0f4ff" : idx % 2 === 0 ? T.white : "#fafaf8", borderBottom:`1px solid ${T.border}`, transition:"background 0.12s" }}
                      onMouseEnter={e => { if (!istAusgewaehlt) e.currentTarget.style.background = "#f6f4ef"; }}
                      onMouseLeave={e => { e.currentTarget.style.background = istAusgewaehlt ? "#f0f4ff" : idx % 2 === 0 ? T.white : "#fafaf8"; }}>

                      {/* Checkbox */}
                      <td style={{ padding:"10px 14px", textAlign:"center" }}>
                        <input type="checkbox" checked={istAusgewaehlt} onChange={() => toggleEinen(wv.guid)}
                          style={{ accentColor:T.navy, width:15, height:15, cursor:"pointer" }} />
                      </td>

                      {/* Datum */}
                      <td style={{ padding:"10px 14px" }}>
                        <span style={{
                          fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.845rem",
                          color: istUeberfaellig ? "#b91c1c" : istHeute ? "#065f46" : T.textMid,
                          fontWeight: (istUeberfaellig || istHeute) ? 600 : 400,
                        }}>
                          {wv.datum ? new Date(wv.datum + "T00:00:00").toLocaleDateString("de-DE") : "–"}
                        </span>
                        {istUeberfaellig && <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.73rem", color:"#ef4444", fontWeight:600 }}>überfällig</div>}
                        {istHeute && <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.73rem", color:"#10b981", fontWeight:600 }}>heute</div>}
                      </td>

                      {/* Aktenzeichen – klickbar */}
                      <td style={{ padding:"10px 14px" }}>
                        <button onClick={() => onOpenAkte({ id: wv.aktenzeichen, az: wv.aktenzeichen, az_roh: wv.aktenzeichen, status: "offen", brutto: 0, hq: 100, unfalldatum: "", unfallort: "" })}
                          style={{ background:"none", border:"none", padding:0, cursor:"pointer", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.875rem", fontWeight:600, color:T.navy, textDecoration:"underline", textDecorationColor:"rgba(27,42,74,0.3)" }}>
                          {wv.aktenzeichen}
                        </button>
                      </td>

                      {/* Aktenkurz- + Langbezeichnung */}
                      <td style={{ padding:"10px 14px", maxWidth:280 }}>
                        <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", fontWeight:600, color:T.textMid, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}
                             title={wv.kurzbezeichnung}>
                          {wv.kurzbezeichnung || wv.mandant || "–"}
                        </div>
                        {wv.bezeichnung && (
                          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.795rem", fontWeight:400, color:T.textMuted, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", marginTop:2 }}
                               title={wv.bezeichnung}>
                            {wv.bezeichnung}
                          </div>
                        )}
                      </td>

                      {/* Sachbearbeiter */}
                      <td style={{ padding:"10px 14px" }}>
                        <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.85rem", background:T.goldPale, color:T.navy, border:`1px solid ${T.goldTrim}`, borderRadius:5, padding:"2px 7px", fontWeight:600 }}>
                          {wv.sachbearbeiter || "–"}
                        </span>
                      </td>

                      {/* WV-Grund */}
                      <td style={{ padding:"10px 14px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.835rem", color:T.textMuted, maxWidth:180, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }} title={wv.grund}>
                        {wv.grund || "–"}
                        {wv.bemerkung && <div style={{ fontSize:"0.775rem", color:T.textFaint }}>{wv.bemerkung}</div>}
                      </td>

                      {/* Status-Marker */}
                      <td style={{ padding:"10px 14px" }}>
                        <Marker erstellt={istErstellt} />
                      </td>

                      {/* Adressat-Dropdown */}
                      <td style={{ padding:"8px 14px" }}>
                        <select
                          value={adressWahl[wv.guid] ?? ""}
                          onFocus={() => ladeBeteiligte(wv.guid, wv.grund, wv.bezeichnung, wv.referat)}
                          onChange={e => setAdressWahl(prev => ({
                            ...prev,
                            [wv.guid]: e.target.value ? parseInt(e.target.value) : null
                          }))}
                          style={{
                            width:"100%", padding:"5px 8px",
                            border:`1px solid ${T.border}`, borderRadius:6,
                            fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.825rem",
                            color:T.text, background:T.white, cursor:"pointer",
                            maxWidth:190,
                          }}>
                          <option value="">
                            {beteiligteLoading.has(wv.guid)
                              ? "Lädt…"
                              : wv.gegner_hv_name || "Standard"}
                          </option>
                          {(adressatenMap[wv.guid] || []).map(b => (
                            <option key={b.adress_nr ?? b.guid_adresse} value={b.adress_nr ?? ""}>
                              {b.kennzeichen ? `[${b.kennzeichen}] ` : ""}{b.name}{b.ort ? ` · ${b.ort}` : ""}
                            </option>
                          ))}
                        </select>
                      </td>

                      {/* Aktion */}
                      <td style={{ padding:"10px 14px" }}>
                        <button
                          onClick={() => einzelnGenerieren(wv)}
                          disabled={istAmLaden || batchLaeuft}
                          style={{
                            display:"flex", alignItems:"center", gap:6,
                            padding:"7px 13px",
                            background: istErstellt ? T.surface : T.navy,
                            color:      istErstellt ? T.textMid : T.white,
                            border: istErstellt ? `1px solid ${T.border}` : "none",
                            borderRadius:8,
                            fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", fontWeight:500,
                            cursor: (istAmLaden || batchLaeuft) ? "default" : "pointer",
                            opacity: (istAmLaden || batchLaeuft) ? 0.65 : 1,
                            whiteSpace:"nowrap", transition:"all 0.15s",
                          }}>
                          {istAmLaden
                            ? <><div style={{ width:11, height:11, border:"2px solid rgba(255,255,255,0.3)", borderTopColor:"white", borderRadius:"50%", animation:"spin 0.7s linear infinite" }}/> Lädt …</>
                            : istErstellt
                            ? <>↻ Erneut erstellen</>
                            : <>📄 Brief erstellen</>}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {/* Paginierung */}
            {wvGesamtSeiten > 1 && (
              <div style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:6, padding:"14px 16px", borderTop:`1px solid ${T.border}`, background:T.surface }}>
                <button onClick={() => setWvSeite(1)} disabled={wvSeiteKorr === 1}
                  style={{ padding:"5px 10px", background:"none", border:`1px solid ${T.border}`, borderRadius:6, cursor:wvSeiteKorr===1?"default":"pointer", color:T.textMid, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", opacity:wvSeiteKorr===1?0.4:1 }}>
                  «
                </button>
                <button onClick={() => setWvSeite(s => Math.max(1, s-1))} disabled={wvSeiteKorr === 1}
                  style={{ padding:"5px 10px", background:"none", border:`1px solid ${T.border}`, borderRadius:6, cursor:wvSeiteKorr===1?"default":"pointer", color:T.textMid, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", opacity:wvSeiteKorr===1?0.4:1 }}>
                  ‹
                </button>
                {Array.from({ length: wvGesamtSeiten }, (_, i) => i + 1)
                  .filter(p => p === 1 || p === wvGesamtSeiten || Math.abs(p - wvSeiteKorr) <= 2)
                  .reduce((acc, p, i, arr) => {
                    if (i > 0 && p - arr[i-1] > 1) acc.push("...");
                    acc.push(p);
                    return acc;
                  }, [])
                  .map((p, i) => p === "..." ? (
                    <span key={`e${i}`} style={{ padding:"5px 4px", color:T.textMuted, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem" }}>…</span>
                  ) : (
                    <button key={p} onClick={() => setWvSeite(p)}
                      style={{ padding:"5px 11px", background:p===wvSeiteKorr?T.navy:"none", border:`1px solid ${p===wvSeiteKorr?T.navy:T.border}`, borderRadius:6, cursor:"pointer", color:p===wvSeiteKorr?T.white:T.textMid, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", fontWeight:p===wvSeiteKorr?600:400 }}>
                      {p}
                    </button>
                  ))
                }
                <button onClick={() => setWvSeite(s => Math.min(wvGesamtSeiten, s+1))} disabled={wvSeiteKorr === wvGesamtSeiten}
                  style={{ padding:"5px 10px", background:"none", border:`1px solid ${T.border}`, borderRadius:6, cursor:wvSeiteKorr===wvGesamtSeiten?"default":"pointer", color:T.textMid, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", opacity:wvSeiteKorr===wvGesamtSeiten?0.4:1 }}>
                  ›
                </button>
                <button onClick={() => setWvSeite(wvGesamtSeiten)} disabled={wvSeiteKorr === wvGesamtSeiten}
                  style={{ padding:"5px 10px", background:"none", border:`1px solid ${T.border}`, borderRadius:6, cursor:wvSeiteKorr===wvGesamtSeiten?"default":"pointer", color:T.textMid, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", opacity:wvSeiteKorr===wvGesamtSeiten?0.4:1 }}>
                  »
                </button>
                <span style={{ marginLeft:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.84rem", color:T.textMuted }}>
                  {(wvSeiteKorr-1)*WV_SEITE_GROESSE+1}–{Math.min(wvSeiteKorr*WV_SEITE_GROESSE, wvGesamtAnzahl)} von {wvGesamtAnzahl}
                </span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   APP SHELL
══════════════════════════════════════════════════════════════ */
/* ══════════════════════════════════════════════════════════════
   AKTENSUCHE (RA-Micro Direktsuche)
══════════════════════════════════════════════════════════════ */

const SUCHMODUS_LABEL = {
  aktenzeichen: "Aktenzeichen",
  name:         "Name (Mandant / Gegner)",
  kennzeichen:  "KFZ-Kennzeichen",
  schadentag:   "Schadentag",
};

function AktensucheView({ onOpenAkte }) {
  const [az, setAz]         = useState("");
  const [kz, setKz]         = useState("");
  const [tag, setTag]       = useState("");
  const [loading, setLoad]  = useState(false);
  const [treffer, setTref]  = useState(null);
  const [suchmodus, setMod] = useState("");
  const [fehler, setFeh]    = useState("");
  const [ramicroAktiv, setRA] = useState(true);

  const suchen = async (feld) => {
    const azQ = az.trim(), kzQ = kz.trim(), tagQ = tag.trim();
    // Nur das gerade ausgefüllte / angesteuerte Feld auswerten
    const nutzAz  = feld === "az"  && azQ;
    const nutzKz  = feld === "kz"  && kzQ;
    const nutzTag = feld === "tag" && tagQ;
    if (!nutzAz && !nutzKz && !nutzTag) return;
    setLoad(true); setFeh(""); setTref(null); setMod("");
    try {
      let res;
      if (nutzKz)       res = await apiAktensuche.nachKennzeichen(kzQ);
      else if (nutzTag) res = await apiAktensuche.nachSchadentag(tagQ);
      else              res = await apiAktensuche.suchen(azQ);
      setTref(res.treffer || []);
      setMod(res.suchmodus || "");
      setRA(res.ramicro_aktiv !== false);
      if (res.hinweis) setFeh(res.hinweis);
    } catch (e) {
      setFeh(e?.message || "Fehler bei der Suche.");
      setTref([]);
    } finally {
      setLoad(false);
    }
  };

  const kachelStyle = {
    flex:1, background:T.white, border:`1px solid ${T.border}`,
    borderRadius:10, padding:"1rem 1.1rem",
    boxShadow:"0 1px 4px rgba(0,0,0,0.04)",
  };

  const labelStyle = {
    fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem",
    fontWeight:600, color:T.textMid, letterSpacing:"0.06em",
    textTransform:"uppercase", display:"block", marginBottom:6,
  };

  const inpStyle = {
    width:"100%", padding:"9px 11px", border:`1.5px solid ${T.border}`,
    borderRadius:7, fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.975rem",
    color:T.text, background:T.white, outline:"none",
    boxSizing:"border-box", transition:"border-color 0.15s",
  };

  const hint = {
    marginTop:5, fontFamily:"'IBM Plex Sans',sans-serif",
    fontSize:"0.75rem", color:T.textFaint, lineHeight:1.4,
  };

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden", background:T.offWhite }}>

      {/* Header */}
      <div style={{ background:T.white, borderBottom:`1px solid ${T.border}`, padding:"1.1rem 1.75rem", flexShrink:0 }}>
        <h1 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.45rem", fontWeight:700, color:T.navy, margin:"0 0 3px" }}>
          Aktensuche
        </h1>
        <p style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.855rem", color:T.textMuted, margin:0 }}>
          Direktsuche in der RA-Micro Datenbank · Alle aktiven Akten
        </p>
      </div>

      {/* Drei Suchkacheln nebeneinander */}
      <div style={{ padding:"1.25rem 1.75rem", flexShrink:0, display:"flex", gap:"1rem" }}>

        {/* Kachel 1: AZ / Name */}
        <div style={kachelStyle}>
          <label style={labelStyle}>
            Aktenzeichen oder Name
          </label>
          <input
            value={az} onChange={e => setAz(e.target.value)}
            onKeyDown={e => e.key==="Enter" && suchen("az")}
            placeholder="42/25  ·  Müller"
            style={inpStyle}
            onFocus={e => e.target.style.borderColor=T.gold}
            onBlur={e  => e.target.style.borderColor=T.border}
          />
          <div style={hint}>Mit „/" → Aktenzeichen · Ohne „/" → Mandant &amp; Gegner</div>
          <div style={{ marginTop:"0.7rem" }}>
            <Btn variant="gold" size="sm" onClick={() => suchen("az")} disabled={loading || !az.trim()} style={{ width:"100%" }}>
              {loading && suchmodus==="" ? "…" : "🔍 Suchen"}
            </Btn>
          </div>
        </div>

        {/* Kachel 2: KFZ */}
        <div style={kachelStyle}>
          <label style={labelStyle}>
            KFZ-Kennzeichen
          </label>
          <input
            value={kz} onChange={e => setKz(e.target.value)}
            onKeyDown={e => e.key==="Enter" && suchen("kz")}
            placeholder="OF-NM 444"
            style={inpStyle}
            onFocus={e => e.target.style.borderColor=T.gold}
            onBlur={e  => e.target.style.borderColor=T.border}
          />
          <div style={hint}>Sucht via WDM varM-KZ · Teileingabe möglich</div>
          <div style={{ marginTop:"0.7rem" }}>
            <Btn variant="gold" size="sm" onClick={() => suchen("kz")} disabled={loading || !kz.trim()} style={{ width:"100%" }}>
              🔍 Suchen
            </Btn>
          </div>
        </div>

        {/* Kachel 3: Schadentag */}
        <div style={kachelStyle}>
          <label style={labelStyle}>
            Schadentag
          </label>
          <input
            type="date"
            value={tag} onChange={e => setTag(e.target.value)}
            onKeyDown={e => e.key==="Enter" && suchen("tag")}
            style={{ ...inpStyle, fontFamily:"'IBM Plex Sans',sans-serif" }}
            onFocus={e => e.target.style.borderColor=T.gold}
            onBlur={e  => e.target.style.borderColor=T.border}
          />
          <div style={hint}>Alle Unfälle an diesem Tag · WDM varU-TAG</div>
          <div style={{ marginTop:"0.7rem" }}>
            <Btn variant="gold" size="sm" onClick={() => suchen("tag")} disabled={loading || !tag.trim()} style={{ width:"100%" }}>
              🔍 Suchen
            </Btn>
          </div>
        </div>
      </div>

      {/* Hinweis / Fehler */}
      {fehler && (
        <div style={{ margin:"0 1.75rem 0.75rem", padding:"9px 14px",
          background: ramicroAktiv ? T.redBg : T.amberBg,
          border:`1px solid ${ramicroAktiv ? T.red : T.amber}44`,
          borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif",
          fontSize:"0.855rem", color: ramicroAktiv ? T.red : T.amber }}>
          {ramicroAktiv ? "⚠" : "ℹ"} {fehler}
        </div>
      )}

      {/* Ergebnisliste */}
      {treffer !== null && (
        <div style={{ flex:1, overflowY:"auto", padding:"0 1.75rem 1.75rem" }}>
          {treffer.length === 0 && !fehler ? (
            <div style={{ textAlign:"center", padding:"3rem 0", color:T.textFaint, fontFamily:"'IBM Plex Sans',sans-serif" }}>
              <div style={{ fontSize:"2.5rem", marginBottom:8 }}>🗂</div>
              <div style={{ fontSize:"1rem" }}>Keine aktiven Akten gefunden</div>
              {suchmodus && <div style={{ fontSize:"0.85rem", marginTop:4 }}>Suchmodus: {SUCHMODUS_LABEL[suchmodus]}</div>}
            </div>
          ) : treffer.length > 0 && (
            <Card>
              <div style={{ padding:"0.65rem 1.4rem", display:"flex", justifyContent:"space-between", alignItems:"center", borderBottom:`1px solid ${T.border}` }}>
                <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                  <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.08em" }}>
                    Ergebnisse
                  </span>
                  {suchmodus && (
                    <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", background:T.goldPale, color:T.navy, border:`1px solid rgba(200,168,75,0.3)`, borderRadius:10, padding:"1px 8px" }}>
                      {SUCHMODUS_LABEL[suchmodus]}
                    </span>
                  )}
                </div>
                <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", color:T.textFaint }}>
                  {treffer.length} Treffer
                </span>
              </div>
              <table style={{ width:"100%", borderCollapse:"collapse" }}>
                <thead>
                  <tr style={{ background:T.surface }}>
                    {["Aktenzeichen","Bezeichnung","Sachbearb.",""].map((h,i) => (
                      <th key={i} style={{ padding:"8px 14px", textAlign:"left", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", fontWeight:600, color:T.textMuted, letterSpacing:"0.06em", textTransform:"uppercase", borderBottom:`1px solid ${T.border}`, whiteSpace:"nowrap" }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {treffer.map((t, i) => (
                    <tr key={t.az + i}
                      style={{ borderBottom:`1px solid ${T.borderSoft}`, background:i%2===0?T.white:"#fafaf8", transition:"background 0.12s", cursor:"default" }}
                      onMouseEnter={e => e.currentTarget.style.background="#f6f4ef"}
                      onMouseLeave={e => e.currentTarget.style.background=i%2===0?T.white:"#fafaf8"}>
                      <td style={{ padding:"10px 14px", whiteSpace:"nowrap" }}>
                        <button onClick={() => onOpenAkte({ id:t.az_roh, az:t.az, az_roh:t.az_roh, unfalldatum:"", unfallort:"", status:"offen", hq:100, brutto:0 })}
                          style={{ background:"none", border:"none", padding:0, cursor:"pointer", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.875rem", fontWeight:600, color:T.navy, textDecoration:"underline", textDecorationColor:"rgba(27,42,74,0.3)" }}>
                          {t.az}
                        </button>
                      </td>
                      <td style={{ padding:"10px 14px", maxWidth:380 }}>
                        <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.875rem", fontWeight:600, color:T.textMid, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}
                             title={t.kurzbezeichnung}>
                          {t.kurzbezeichnung || t.mandant || "–"}
                        </div>
                        {(t.bezeichnung || t.kennzeichen) && (
                          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.795rem", color:T.textMuted, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", marginTop:2 }}
                               title={[t.bezeichnung, t.kennzeichen].filter(Boolean).join(" · ")}>
                            {t.bezeichnung}
                            {t.bezeichnung && t.kennzeichen && <span style={{ margin:"0 4px", color:T.textFaint }}>·</span>}
                            {t.kennzeichen && <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.775rem", fontWeight:700, color:T.blue }}>{t.kennzeichen}</span>}
                          </div>
                        )}
                      </td>
                      <td style={{ padding:"10px 14px", whiteSpace:"nowrap" }}>
                        <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.85rem", background:T.goldPale, color:T.navy, border:`1px solid ${T.goldTrim}`, borderRadius:5, padding:"2px 7px", fontWeight:600 }}>
                          {t.sachbearbeiter || "–"}
                        </span>
                      </td>
                      <td style={{ padding:"10px 10px", textAlign:"right" }}>
                        <Btn size="sm" variant="secondary"
                          onClick={() => onOpenAkte({ id:t.az_roh, az:t.az, az_roh:t.az_roh, unfalldatum:"", unfallort:"", status:"offen", hq:100, brutto:0 })}>
                          Öffnen
                        </Btn>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          )}
        </div>
      )}

      {/* Leerzustand */}
      {treffer === null && !loading && (
        <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", color:T.textFaint, fontFamily:"'IBM Plex Sans',sans-serif", gap:10 }}>
          <div style={{ fontSize:"3rem" }}>🔍</div>
          <div style={{ fontSize:"1rem" }}>Suchfeld ausfüllen und „Suchen" klicken</div>
          <div style={{ fontSize:"0.83rem", color:T.textFaint, textAlign:"center", maxWidth:380, lineHeight:1.6 }}>
            <code style={{ background:T.surface, padding:"1px 5px", borderRadius:4 }}>42/25</code> Aktenzeichen &nbsp;·&nbsp;
            <code style={{ background:T.surface, padding:"1px 5px", borderRadius:4 }}>Müller</code> Name &nbsp;·&nbsp;
            <code style={{ background:T.surface, padding:"1px 5px", borderRadius:4 }}>OF-NM 444</code> Kennzeichen &nbsp;·&nbsp;
            Datum über Kalender
          </div>
        </div>
      )}
    </div>
  );
}
function AppShell({ user, onLogout }) {
  const [tabs, setTabs]          = useState([]);
  const [active, setActive]      = useState("dashboard");   // "dashboard" | "email-import" | "wiedervorlage" | "akte-N"
  const [aktenState, dispatch]   = useReducer(reducer, INITIAL_STATE);
  const { online }               = useBackend();

  const handleLogout = useCallback(async () => {
    await apiAuth.logout().catch(() => {});
    onLogout();
  }, [onLogout]);

  const openAkte = useCallback((baseAkte) => {
    const azVoll  = baseAkte.az_roh || baseAkte.az || String(baseAkte.id);
    // SB-Kürzel entfernen für SQLite-PK und RA-Micro-Suche: "1213/25AS" → "1213/25"
    const azBasis = azVoll.replace(/[A-Z]{2,3}$/i, "").trim();
    const az      = azBasis.includes("/") ? azBasis : azVoll;
    const tabId   = `akte-${az}`;
    setTabs(prev => prev.find(t => t.id===tabId) ? prev : [
      ...prev,
      { id:tabId, label:azVoll, status:aktenState[az]?.status||baseAkte.status||"offen",
        akte:{ ...baseAkte, id:az, az:azVoll, az_roh:az } }
    ]);
    setActive(tabId);
    // On-demand SQLite-Anlage mit Basis-AZ (fire and forget)
    if (az.includes("/")) {
      ramicroListe.onDemand(az).catch(() => {});
    }
  }, [aktenState]);

  const closeTab = useCallback((tabId) => {
    setTabs(prev => {
      const filtered = prev.filter(t => t.id!==tabId);
      if (active===tabId) {
        const idx = prev.findIndex(t => t.id===tabId);
        const fallback = filtered[Math.max(0, idx-1)]?.id || "dashboard";
        setActive(fallback);
      }
      return filtered;
    });
  }, [active]);

  const tabsLive = tabs.map(t => t.akte ? { ...t, status:aktenState[t.akte.id]?.status||t.status } : t);
  const activeTab = tabs.find(t => t.id===active);

  // Linke Menü-Einträge
  const navItems = [
    { id:"dashboard",       icon:Ic.dash,  label:"Dashboard"       },
    { id:"aktensuche",      icon:"🔍",     label:"Aktensuche"       },
    { id:"email-import",    icon:Ic.email, label:"E-Mail-Import"    },
    { id:"wiedervorlage",   icon:"📋",     label:"Wiedervorlage"    },
    { id:"kuerzungskatalog",icon:"⚖️",    label:"Kürzungskatalog"  },
  ];

  return (
    <div style={{ height:"100vh", display:"flex", flexDirection:"column", overflow:"hidden" }}>
      <TopNav user={user} onLogout={handleLogout} backendOnline={online} />

      {/* Haupt-Layout: Seitenmenü + Inhalt */}
      <div style={{ flex:1, display:"flex", overflow:"hidden" }}>

        {/* ── Linke Menüspalte ────────────────────────────────── */}
        <div style={{ width:210, background:T.navy, borderRight:"1px solid rgba(200,168,75,0.15)", display:"flex", flexDirection:"column", flexShrink:0, zIndex:10 }}>

          {/* Navigationseinträge */}
          <div style={{ padding:"0.6rem 0.5rem", flex:1 }}>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.72rem", fontWeight:600, color:"rgba(255,255,255,0.35)", letterSpacing:"0.12em", textTransform:"uppercase", padding:"8px 10px 4px" }}>
              Navigation
            </div>
            {navItems.map(item => {
              const isA = active === item.id;
              return (
                <button key={item.id} onClick={() => setActive(item.id)}
                  style={{ width:"100%", display:"flex", alignItems:"center", justifyContent:"flex-start", gap:10, padding:"9px 12px", borderRadius:7, border:"none", cursor:"pointer",
                    background:isA?"rgba(200,168,75,0.15)":"transparent",
                    color: T.white,
                    fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"1rem",
                    fontWeight:isA?600:400, textAlign:"left", transition:"all 0.12s", marginBottom:2,
                    ...(isA ? { boxShadow:`inset 2px 0 0 ${T.gold}` } : {}) }}
                  onMouseEnter={e => { if (!isA) e.currentTarget.style.background="rgba(255,255,255,0.06)"; }}
                  onMouseLeave={e => { if (!isA) e.currentTarget.style.background="transparent"; }}>
                  <span style={{ fontSize:"1rem", flexShrink:0 }}>{item.icon}</span>
                  <span style={{ overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{item.label}</span>
                </button>
              );
            })}

            {/* Trennlinie vor offenen Akten */}
            {tabs.length > 0 && (
              <>
                <div style={{ margin:"8px 10px", borderTop:"1px solid rgba(255,255,255,0.08)" }} />
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.72rem", fontWeight:600, color:"rgba(255,255,255,0.35)", letterSpacing:"0.12em", textTransform:"uppercase", padding:"4px 10px 4px" }}>
                  Offene Akten
                </div>
              </>
            )}
          </div>

          {/* User-Info unten */}
          <div style={{ padding:"0.75rem 0.75rem", borderTop:"1px solid rgba(255,255,255,0.08)", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", color:"rgba(255,255,255,0.45)" }}>
            <div style={{ overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{user?.name}</div>
          </div>
        </div>

        {/* ── Rechter Bereich: TabBar + Inhalt ────────────────── */}
        <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
          <TabBar tabs={tabsLive} active={active} onActivate={setActive} onClose={closeTab} />
          <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
            {active==="dashboard"        ? <DashboardView onOpenAkte={openAkte} aktenState={aktenState} />
            : active==="statistiken"     ? <StatistikenView />
            : active==="aktensuche"      ? <AktensucheView onOpenAkte={openAkte} />
            : active==="email-import"    ? <EmailImportView onOpenAkte={openAkte} />
            : active==="wiedervorlage"   ? <WiedervorlageView onOpenAkte={openAkte} />
            : active==="kuerzungskatalog"? <KuerzungskatalogSection />
            : activeTab?.akte            ? <AkteDetailView akte={activeTab.akte} st={aktenState[activeTab.akte.id]||{}} dispatch={dispatch} />
            : null}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   ROOT
══════════════════════════════════════════════════════════════ */
export default function App() {
  const [user, setUser] = useState(null);
  if (!user) return <LoginPage onLogin={setUser} />;
  return <AppShell user={user} onLogout={() => setUser(null)} />;
}
