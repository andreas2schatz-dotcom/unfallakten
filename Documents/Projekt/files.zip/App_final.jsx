import React, { useState, useRef, useEffect, useCallback, useReducer } from "react";
import {
  auth as apiAuth, akten as apiAkten, beteiligte as apiBeteiligte,
  schaden as apiSchaden, dokumente as apiDokumente, word as apiWord,
  emailImport as apiEmail, ping, tokenStore, ApiError,
} from "./api.js";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line
} from "recharts";

/* ══════════════════════════════════════════════════════════════
   DESIGN TOKENS
══════════════════════════════════════════════════════════════ */
const T = {
  navy:"#1B2A4A", navyDark:"#111d35", navyMid:"#243660", navyLight:"#2e4270",
  gold:"#C8A84B", goldLight:"#dfc070", goldPale:"#f8f1e0", goldTrim:"rgba(200,168,75,0.18)",
  white:"#FFFFFF", offWhite:"#F6F4EF", surface:"#FAFAF8",
  border:"#E2DDD3", borderSoft:"rgba(226,221,211,0.6)",
  text:"#1a1a2e", textMid:"#3d4060", textMuted:"#6b7094", textFaint:"#9da3be",
  green:"#10b981", greenBg:"#ecfdf5",
  amber:"#f59e0b", amberBg:"#fffbeb",
  red:"#ef4444",   redBg:"#fef2f2",
  blue:"#3b82f6",  blueBg:"#eff6ff",
};

const STATUS_MAP = {
  offen:          { label:"Offen",          color:T.blue,  bg:T.blueBg  },
  in_regulierung: { label:"In Regulierung", color:T.amber, bg:T.amberBg },
  abgeschlossen:  { label:"Abgeschlossen",  color:T.green, bg:T.greenBg },
  klage:          { label:"Klage",          color:T.red,   bg:T.redBg   },
};

const REG_STATUS = {
  vollreguliert: { label:"Vollreguliert", color:T.green },
  teilreguliert: { label:"Teilreguliert", color:T.amber },
  abgelehnt:     { label:"Abgelehnt",     color:T.red   },
  ausstehend:    { label:"Ausstehend",    color:T.textMuted },
};

/* ══════════════════════════════════════════════════════════════
   MOCK DATA
══════════════════════════════════════════════════════════════ */
const MOCK_USER = { id:1, name:"RA Koch", email:"koch@anwalt-offenbach.de", rolle:"admin" };

const BASE_AKTEN = [
  { id:1,  az:"25-0042", unfalldatum:"2025-03-15", unfallort:"Offenbach, Berliner Str. 12",   status:"in_regulierung", hq:100, brutto:8220  },
  { id:2,  az:"25-0041", unfalldatum:"2025-03-10", unfallort:"Frankfurt, Kaiserstr. 88",      status:"abgeschlossen",  hq:70,  brutto:3450  },
  { id:3,  az:"25-0040", unfalldatum:"2025-03-08", unfallort:"Offenbach, Bieberer Str. 5",    status:"offen",          hq:100, brutto:12100 },
  { id:4,  az:"25-0038", unfalldatum:"2025-02-28", unfallort:"Darmstadt, Rheinstr. 14",       status:"klage",          hq:50,  brutto:22000 },
  { id:5,  az:"25-0035", unfalldatum:"2025-02-20", unfallort:"Offenbach, Ludwigstr. 3",       status:"in_regulierung", hq:100, brutto:5670  },
  { id:6,  az:"25-0033", unfalldatum:"2025-02-15", unfallort:"Frankfurt, Hanauer Landstr.",   status:"abgeschlossen",  hq:80,  brutto:7890  },
  { id:7,  az:"25-0029", unfalldatum:"2025-02-10", unfallort:"Hanau, Am Markt 2",             status:"offen",          hq:100, brutto:4320  },
  { id:8,  az:"25-0024", unfalldatum:"2025-01-30", unfallort:"Offenbach, Waldstr. 1",         status:"in_regulierung", hq:60,  brutto:9100  },
  { id:9,  az:"25-0018", unfalldatum:"2025-01-20", unfallort:"Seligenstadt, Hauptstr. 4",     status:"abgeschlossen",  hq:100, brutto:2100  },
  { id:10, az:"25-0011", unfalldatum:"2025-01-10", unfallort:"Frankfurt, Zeil 80",            status:"abgeschlossen",  hq:100, brutto:6750  },
  { id:11, az:"24-1098", unfalldatum:"2024-12-12", unfallort:"Offenbach, Berliner Str. 44",   status:"klage",          hq:50,  brutto:35000 },
  { id:12, az:"24-1087", unfalldatum:"2024-12-01", unfallort:"Mühlheim, Frankfurter Str. 9",  status:"in_regulierung", hq:75,  brutto:11200 },
];

const NAMEN     = ["Müller","Schmidt","Wagner","Becker","Fischer","Braun","Hoffmann","Schulz","Werner","Klein","Günther","Neumann"];
const VORNAMEN  = ["Hans","Eva","Klaus","Maria","Tom","Petra","Lars","Anna","Dieter","Sabine","Marc","Julia"];
const KENNZ     = ["OF-HM 1","F-SC 22","OF-WK 7","DA-BE 4","OF-FT 9","F-BR 77","MKK-HO 3","OF-SZ 66","OF-WE 12","F-KL 5","OF-GU 3","MKK-NE 8"];
const VERSICHER = ["HUK-Coburg","Allianz","DEVK","AXA","Zurich","Generali","Ergo","ADAC","Württemberg.","Signal Iduna","HDI","R+V"];
const REG_BETR  = [6180,3450,0,0,3000,7890,0,2730,2100,6750,0,6000];

function buildMockState(a) {
  const b = a.brutto, i = a.id - 1;
  return {
    status: a.status,
    notizen: a.id===1 ? "HUK verweigert Wertminderung. Gutachter Schmidt eingeschaltet." : "",
    beteiligte: [
      { id:1, rolle:"mandant", name:NAMEN[i], vorname:VORNAMEN[i], firma:"", email:`mandant${a.id}@email.de`, telefon:`069 ${1000000+a.id*111111}`, kfz:KENNZ[i], kfz_typ:"PKW", versicherung:"DEVK", vers_nr:`DEVK-2025-00${a.id}`, schaden_nr:"", iban:"DE89 3704 0044 0532 0130 00", anschrift:"Berliner Str. 12", plz:"63065", ort:"Offenbach", notizen:"" },
      { id:2, rolle:"gegner",  name:VERSICHER[i], vorname:"", firma:VERSICHER[i], email:"regulierung@versicherung.de", telefon:"0800 123456", kfz:"", kfz_typ:"", versicherung:VERSICHER[i], vers_nr:`VN-2025-${a.id}00`, schaden_nr:`SN-${a.id}`, iban:"", anschrift:"", plz:"", ort:"", notizen:"" },
    ],
    schaden: {
      reparaturkosten:   Math.round(b*0.52), wiederbeschaffung:0, restwert:0,
      wertminderung:     Math.round(b*0.05), nutzungsausfall:Math.round(b*0.08),
      mietwagenkosten:   Math.round(b*0.06), sv_kosten:Math.round(b*0.09),
      abschleppkosten:   Math.round(b*0.03), standkosten:Math.round(b*0.02),
      anabmeldekosten:   Math.round(b*0.01), schmerzensgeld:0,
      sonstiges:         Math.round(b*0.04), sonstiges_beschr:"Kostenpauschale",
      gesamt_brutto:     b, quelle: a.id<=2 ? "gutachten_pdf" : "manuell",
    },
    regulierungen: REG_BETR[i] > 0 ? [{
      id:1, datum:"2025-02-20",
      betrag_gefordert: b*(a.hq/100),
      betrag_reguliert: REG_BETR[i],
      status: REG_BETR[i] >= b*(a.hq/100) ? "vollreguliert" : "teilreguliert",
      vers_referenz:`REF-2025-00${a.id}`,
      kuerz_begruendung: REG_BETR[i] < b*(a.hq/100) ? "Wertminderung nicht anerkannt" : "",
    }] : [],
    dokumente: a.id<=3 ? [
      { id:1, typ:"gutachten", dateiname:`Gutachten_${a.az}.pdf`, dateityp:"pdf", groesse:892341, hochgeladen_am:"17.03.2025 09:12", parse_status:"erfolgreich", parse_konfidenz:0.87 },
      { id:2, typ:"abrechnungsschreiben", dateiname:`Abrechnung_${a.az}.pdf`, dateityp:"pdf", groesse:124500, hochgeladen_am:"18.03.2025 14:30", parse_status:"erfolgreich", parse_konfidenz:0.73 },
    ] : a.id<=6 ? [
      { id:1, typ:"gutachten", dateiname:`Gutachten_${a.az}.pdf`, dateityp:"pdf", groesse:654200, hochgeladen_am:"22.02.2025 11:05", parse_status:"erfolgreich", parse_konfidenz:0.91 },
    ] : [],
    aktivitaeten: [
      { id:1, zeit:"vor 2 Std.", user:"Koch",   aktion:"Akte angelegt",             typ:"akte" },
      { id:2, zeit:"Gestern",    user:"Schatz", aktion:"Beteiligten hinzugefügt",   typ:"beteiligter" },
      ...(a.id<=3 ? [{ id:3, zeit:"Gestern",     user:"Ihl", aktion:"Gutachten hochgeladen (PDF · Konfidenz 87 %)", typ:"pdf" }] : []),
      ...(REG_BETR[i]>0 ? [{ id:4, zeit:"vor 3 Tagen", user:"Koch", aktion:`Regulierung erfasst: ${fmt€(REG_BETR[i])}`, typ:"regulierung" }] : []),
    ],
  };
}

const INITIAL_STATE = Object.fromEntries(BASE_AKTEN.map(a => [a.id, buildMockState(a)]));

const MONATS = [
  {m:"Okt",a:6,r:42000},{m:"Nov",a:9,r:67000},{m:"Dez",a:11,r:89000},
  {m:"Jan",a:8,r:54000},{m:"Feb",a:14,r:103000},{m:"Mär",a:12,r:88000},
];

/* E-Mail-Import Mock-Daten */
const IMAP_CONFIG = {
  host:"mail.anwalt-offenbach.de", port:993, ssl:true,
  user:"import@anwalt-offenbach.de", ordner:"INBOX", max_fetch:50,
  letzte_sync:"09.03.2026 08:00", naechste_sync:"09.03.2026 09:00",
  status:"verbunden",
};

const MOCK_EMAIL_LOG_BASE = [
  { id:1,  empfangen_am:"09.03.2026 07:41", von_email:"regulierung@huk-coburg.de",   von_name:"HUK-Coburg Regulierung",  betreff:"Re: Schadensfall AZ 25-0042 – Regulierungsantwort",                 erkannt_az:"25-0042", erkannt_kfz:null,       match:"aktenzeichen",    akte_az:"25-0042", akte_id:1,  anhaenge:[{name:"Regulierungsschreiben_25-0042.pdf",size:187230,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.91}], status:"zugeordnet",       als_gelesen:true  },
  { id:2,  empfangen_am:"09.03.2026 06:15", von_email:"schaden@allianz.de",           von_name:"Allianz Schadenservice",  betreff:"Schadennummer SN-202-2 – weitere Unterlagen erbeten",               erkannt_az:null,      erkannt_kfz:"F-SC 22",  match:"kfz_kennzeichen", akte_az:"25-0041", akte_id:2,  anhaenge:[{name:"Anforderung_Allianz.pdf",size:94200,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.78}], status:"zugeordnet",       als_gelesen:true  },
  { id:3,  empfangen_am:"08.03.2026 17:33", von_email:"mueller.hans@email.de",         von_name:"Hans Müller",             betreff:"Gutachten liegt vor",                                               erkannt_az:null,      erkannt_kfz:null,       match:"absender_email",  akte_az:"25-0042", akte_id:1,  anhaenge:[{name:"Gutachten_Schmidt_25-0042.pdf",size:1240500,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.87},{name:"Fotos_Unfall.zip",size:4890200,typ:"zip",parse_status:"nicht_unterstuetzt",konfidenz:null}], status:"zugeordnet", als_gelesen:true },
  { id:4,  empfangen_am:"08.03.2026 14:20", von_email:"info@devk.de",                 von_name:"DEVK Versicherung",       betreff:"Eingang Ihrer Schadenmeldung bestätigt",                            erkannt_az:"25-0040", erkannt_kfz:null,       match:"aktenzeichen",    akte_az:"25-0040", akte_id:3,  anhaenge:[], status:"zugeordnet", als_gelesen:false },
  { id:5,  empfangen_am:"08.03.2026 11:05", von_email:"axa-schaden@axa.de",           von_name:"AXA Schaden",             betreff:"AZ 25-0038 – Abweisung Ihrer Forderung",                            erkannt_az:"25-0038", erkannt_kfz:null,       match:"aktenzeichen",    akte_az:"25-0038", akte_id:4,  anhaenge:[{name:"Ablehnungsschreiben_AXA.pdf",size:223100,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.83}], status:"zugeordnet", als_gelesen:false },
  { id:6,  empfangen_am:"08.03.2026 09:48", von_email:"kanzlei@recht-ffm.de",         von_name:"RAe Bernhardt & Partner", betreff:"Forderungsschreiben – Ihr Mandant Wagner",                          erkannt_az:null,      erkannt_kfz:"OF-WK 7",  match:"kfz_kennzeichen", akte_az:"25-0040", akte_id:3,  anhaenge:[{name:"Gegenforderung.pdf",size:156800,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.69}], status:"zugeordnet", als_gelesen:true },
  { id:7,  empfangen_am:"07.03.2026 16:02", von_email:"noreply@zurich.de",            von_name:"Zurich Insurance",        betreff:"Ihre Anfrage vom 06.03.2026 – AZ 25-0035",                          erkannt_az:"25-0035", erkannt_kfz:null,       match:"aktenzeichen",    akte_az:"25-0035", akte_id:5,  anhaenge:[], status:"zugeordnet", als_gelesen:true },
  { id:8,  empfangen_am:"07.03.2026 13:17", von_email:"info@sv-mueller.de",           von_name:"Sachverständigenbüro Müller", betreff:"Gutachten Fahrzeug OF-SZ 66 – Kostenrechnung",                 erkannt_az:null,      erkannt_kfz:"OF-SZ 66", match:"kfz_kennzeichen", akte_az:"25-0024", akte_id:8,  anhaenge:[{name:"Kostenrechnung_SV.pdf",size:98700,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.74},{name:"Gutachten_OF-SZ66.pdf",size:2340000,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.92}], status:"zugeordnet", als_gelesen:true },
  { id:9,  empfangen_am:"07.03.2026 10:30", von_email:"newsletter@verband.de",        von_name:"Anwaltsverband Hessen",   betreff:"Newsletter März 2026 – Neue Rechtsprechung StVG",                   erkannt_az:null,      erkannt_kfz:null,       match:null,              akte_az:null,      akte_id:null, anhaenge:[{name:"Newsletter_03-2026.pdf",size:445000,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.12}], status:"nicht_zugeordnet", als_gelesen:false },
  { id:10, empfangen_am:"06.03.2026 18:55", von_email:"generali@schaden.de",          von_name:"Generali Schaden",        betreff:"Schadennummer 2025-06-GEN – abschließende Regulierung",             erkannt_az:null,      erkannt_kfz:null,       match:null,              akte_az:null,      akte_id:null, anhaenge:[{name:"Abschlussschreiben.pdf",size:133400,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.31}], status:"nicht_zugeordnet", als_gelesen:false },
  { id:11, empfangen_am:"06.03.2026 15:40", von_email:"ergo-haftpflicht@ergo.de",     von_name:"Ergo Haftpflicht",        betreff:"Regulierungsangebot AZ 25-0029 – Kulanzleistung",                   erkannt_az:"25-0029", erkannt_kfz:null,       match:"aktenzeichen",    akte_az:"25-0029", akte_id:7,  anhaenge:[{name:"Regulierungsangebot.pdf",size:178900,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.88}], status:"zugeordnet", als_gelesen:true },
  { id:12, empfangen_am:"06.03.2026 11:22", von_email:"adac-recht@adac.de",           von_name:"ADAC Rechtsschutz",       betreff:"Widerspruch gegen Ihre Forderung – OF-SZ 66",                       erkannt_az:null,      erkannt_kfz:"OF-SZ 66", match:"kfz_kennzeichen", akte_az:"25-0024", akte_id:8,  anhaenge:[{name:"Widerspruch_ADAC.pdf",size:201300,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.81}], status:"zugeordnet", als_gelesen:true },
  { id:13, empfangen_am:"05.03.2026 09:14", von_email:"wuerttemberg@vers.de",         von_name:"Württembergische Vers.",  betreff:"Bestätigung Vollregulierung 25-0018",                               erkannt_az:"25-0018", erkannt_kfz:null,       match:"aktenzeichen",    akte_az:"25-0018", akte_id:9,  anhaenge:[{name:"Vollreg_Bestaetigung.pdf",size:89200,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.95}], status:"zugeordnet", als_gelesen:true },
  { id:14, empfangen_am:"05.03.2026 14:05", von_email:"signal@iduna.de",              von_name:"Signal Iduna",            betreff:"Zahlungseingang bestätigt – 25-0011",                               erkannt_az:"25-0011", erkannt_kfz:null,       match:"aktenzeichen",    akte_az:"25-0011", akte_id:10, anhaenge:[], status:"zugeordnet", als_gelesen:true },
  { id:15, empfangen_am:"04.03.2026 17:30", von_email:"unbekannt@domain.xyz",         von_name:"Unbekannt",               betreff:"Wichtige Mitteilung zu Ihrem Fall",                                 erkannt_az:null,      erkannt_kfz:null,       match:null,              akte_az:null,      akte_id:null, anhaenge:[], status:"nicht_zugeordnet", als_gelesen:false },
  { id:16, empfangen_am:"04.03.2026 10:18", von_email:"hdi-direkt@hdi.de",            von_name:"HDI Direkt",              betreff:"Re: Klageverfahren 24-1098 – Klageerwiderung",                       erkannt_az:"24-1098", erkannt_kfz:null,       match:"aktenzeichen",    akte_az:"24-1098", akte_id:11, anhaenge:[{name:"Klageerwiderung_HDI.pdf",size:567800,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.89},{name:"Anlagen_KE.pdf",size:1230000,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.76}], status:"zugeordnet", als_gelesen:true },
  { id:17, empfangen_am:"03.03.2026 16:45", von_email:"rv-schaden@ruv.de",            von_name:"R+V Versicherung",        betreff:"AZ 24-1087 – Teilregulierung weitere Positionen ausstehend",        erkannt_az:"24-1087", erkannt_kfz:null,       match:"aktenzeichen",    akte_az:"24-1087", akte_id:12, anhaenge:[{name:"Teilreg_RV.pdf",size:144200,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.86}], status:"zugeordnet", als_gelesen:true },
  { id:18, empfangen_am:"03.03.2026 08:55", von_email:"malformed@",                   von_name:"",                        betreff:"",                                                                  erkannt_az:null,      erkannt_kfz:null,       match:null,              akte_az:null,      akte_id:null, anhaenge:[], status:"fehler", fehler:"Ungültiger E-Mail-Header – RFC-822-Parserfehler", als_gelesen:false },
  { id:19, empfangen_am:"02.03.2026 14:20", von_email:"becker.maria@email.de",        von_name:"Maria Becker",            betreff:"Frage zu meinem Fall – AZ 25-0038",                                 erkannt_az:"25-0038", erkannt_kfz:null,       match:"aktenzeichen",    akte_az:"25-0038", akte_id:4,  anhaenge:[], status:"zugeordnet", als_gelesen:true },
  { id:20, empfangen_am:"02.03.2026 09:03", von_email:"gutachter@schmidt-sv.de",      von_name:"Dipl.-Ing. Schmidt SV",   betreff:"Rechnung Nr. 2026-0047 – Gutachten OF-HM 1",                        erkannt_az:null,      erkannt_kfz:"OF-HM 1",  match:"kfz_kennzeichen", akte_az:"25-0042", akte_id:1,  anhaenge:[{name:"Rechnung_Schmidt_0047.pdf",size:112300,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.82}], status:"zugeordnet", als_gelesen:true },
];

const EMAIL_TAGES_STATS = [
  {tag:"Mi 03.03", zugeordnet:4, nicht_zugeordnet:1, fehler:1},
  {tag:"Do 04.03", zugeordnet:3, nicht_zugeordnet:2, fehler:0},
  {tag:"Fr 05.03", zugeordnet:2, nicht_zugeordnet:0, fehler:0},
  {tag:"Sa 06.03", zugeordnet:3, nicht_zugeordnet:1, fehler:0},
  {tag:"So 07.03", zugeordnet:3, nicht_zugeordnet:0, fehler:0},
  {tag:"Mo 08.03", zugeordnet:4, nicht_zugeordnet:0, fehler:0},
  {tag:"Di 09.03", zugeordnet:1, nicht_zugeordnet:0, fehler:0},
];

/* ══════════════════════════════════════════════════════════════
   UTILS
══════════════════════════════════════════════════════════════ */
function fmt€(v) {
  if (v==null) return "–";
  return new Intl.NumberFormat("de-DE",{style:"currency",currency:"EUR",maximumFractionDigits:0}).format(v);
}
function fmtSize(bytes) {
  if (!bytes) return "";
  return bytes < 1048576 ? `${Math.round(bytes/1024)} KB` : `${(bytes/1048576).toFixed(1)} MB`;
}

/* ══════════════════════════════════════════════════════════════
   ICONS
══════════════════════════════════════════════════════════════ */
const Ic = {
  logo:     <svg viewBox="0 0 24 24" fill="currentColor" style={{width:20,height:20}}><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-1 14l-3-3 1.41-1.41L11 12.17l4.59-4.58L17 9l-6 6z"/></svg>,
  dash:     <svg viewBox="0 0 24 24" fill="currentColor" style={{width:16,height:16}}><path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/></svg>,
  akte:     <svg viewBox="0 0 24 24" fill="currentColor" style={{width:14,height:14}}><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg>,
  x:        <svg viewBox="0 0 24 24" fill="currentColor" style={{width:13,height:13}}><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>,
  search:   <svg viewBox="0 0 24 24" fill="currentColor" style={{width:15,height:15}}><path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>,
  user:     <svg viewBox="0 0 24 24" fill="currentColor" style={{width:16,height:16}}><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>,
  logout:   <svg viewBox="0 0 24 24" fill="currentColor" style={{width:15,height:15}}><path d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z"/></svg>,
  plus:     <svg viewBox="0 0 24 24" fill="currentColor" style={{width:14,height:14}}><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>,
  edit:     <svg viewBox="0 0 24 24" fill="currentColor" style={{width:13,height:13}}><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>,
  trash:    <svg viewBox="0 0 24 24" fill="currentColor" style={{width:13,height:13}}><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>,
  upload:   <svg viewBox="0 0 24 24" fill="currentColor" style={{width:28,height:28}}><path d="M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z"/></svg>,
  download: <svg viewBox="0 0 24 24" fill="currentColor" style={{width:13,height:13}}><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>,
  pdf:      <svg viewBox="0 0 24 24" fill="currentColor" style={{width:18,height:18}}><path d="M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8.5 7.5c0 .83-.67 1.5-1.5 1.5H9v2H7.5V7H10c.83 0 1.5.67 1.5 1.5v1zm5 2c0 .83-.67 1.5-1.5 1.5h-2.5V7H15c.83 0 1.5.67 1.5 1.5v3zm4-3H19v1h1.5V11H19v2h-1.5V7h3v1.5zM4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6z"/></svg>,
  word:     <svg viewBox="0 0 24 24" fill="currentColor" style={{width:16,height:16}}><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zM6 20V4h7v5h5v11H6z"/></svg>,
  check:    <svg viewBox="0 0 24 24" fill="currentColor" style={{width:14,height:14}}><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>,
  chevR:    <svg viewBox="0 0 24 24" fill="currentColor" style={{width:13,height:13}}><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg>,
  email:    <svg viewBox="0 0 24 24" fill="currentColor" style={{width:15,height:15}}><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>,
  refresh:  <svg viewBox="0 0 24 24" fill="currentColor" style={{width:15,height:15}}><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>,
  attach:   <svg viewBox="0 0 24 24" fill="currentColor" style={{width:13,height:13}}><path d="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.38 1.12 2.5 2.5 2.5s2.5-1.12 2.5-2.5V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z"/></svg>,
  settings: <svg viewBox="0 0 24 24" fill="currentColor" style={{width:15,height:15}}><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>,
};

/* ══════════════════════════════════════════════════════════════
   SHARED ATOMS
══════════════════════════════════════════════════════════════ */
function StatusBadge({ status, map = STATUS_MAP }) {
  const s = map[status] || { label: status, color: "#888", bg: "#f0f0f0" };
  const bg = s.bg || s.color + "18";
  return (
    <span style={{ display:"inline-flex", alignItems:"center", gap:5, background:bg, color:s.color, border:`1px solid ${s.color}33`, borderRadius:20, padding:"2px 9px", fontSize:"0.72rem", fontWeight:600, whiteSpace:"nowrap" }}>
      <span style={{ width:6, height:6, borderRadius:"50%", background:s.color, flexShrink:0 }} />
      {s.label}
    </span>
  );
}

function Card({ children, style = {} }) {
  return <div style={{ background:T.white, borderRadius:12, border:`1px solid ${T.border}`, boxShadow:"0 2px 8px rgba(0,0,0,0.04)", overflow:"hidden", ...style }}>{children}</div>;
}

function CardHead({ title, action }) {
  return (
    <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"0.9rem 1.4rem", borderBottom:`1px solid ${T.border}` }}>
      <h3 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1rem", fontWeight:700, color:T.navy, margin:0 }}>{title}</h3>
      {action}
    </div>
  );
}

function Btn({ children, variant="primary", onClick, disabled=false, size="md", style={} }) {
  const pad  = { sm:"5px 10px", md:"8px 14px", lg:"10px 18px" }[size];
  const fs   = { sm:"0.74rem",  md:"0.82rem",  lg:"0.88rem"  }[size];
  const vars = {
    primary:   { background:T.navy,    color:T.white,    border:"none" },
    secondary: { background:T.surface, color:T.textMid,  border:`1px solid ${T.border}` },
    gold:      { background:T.gold,    color:T.navy,     border:"none" },
    danger:    { background:T.redBg,   color:T.red,      border:`1px solid ${T.red}33` },
  };
  return (
    <button disabled={disabled} onClick={disabled ? null : onClick}
      style={{ display:"inline-flex", alignItems:"center", gap:6, borderRadius:7, fontFamily:"'IBM Plex Sans',sans-serif", fontWeight:600, cursor:disabled?"default":"pointer", transition:"all 0.15s", opacity:disabled?0.55:1, padding:pad, fontSize:fs, ...vars[variant], ...style }}>
      {children}
    </button>
  );
}

function FieldInput({ label, value, onChange, type="text", placeholder="", required=false }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
      {label && <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMid, letterSpacing:"0.05em", textTransform:"uppercase" }}>{label}{required && <span style={{ color:T.red }}> *</span>}</label>}
      <input type={type} value={value} placeholder={placeholder} onChange={e => onChange(e.target.value)}
        style={{ padding:"8px 10px", border:`1.5px solid ${T.border}`, borderRadius:7, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.86rem", color:T.text, background:T.surface, outline:"none" }}
        onFocus={e => e.target.style.borderColor = T.gold}
        onBlur={e  => e.target.style.borderColor = T.border} />
    </div>
  );
}

function FieldSelect({ label, value, onChange, options }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
      {label && <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMid, letterSpacing:"0.05em", textTransform:"uppercase" }}>{label}</label>}
      <select value={value} onChange={e => onChange(e.target.value)}
        style={{ padding:"8px 10px", border:`1.5px solid ${T.border}`, borderRadius:7, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.86rem", color:T.text, background:T.surface, outline:"none", cursor:"pointer" }}>
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

function Toast({ msg, onDone }) {
  useEffect(() => { const t = setTimeout(onDone, 2600); return () => clearTimeout(t); }, []);
  return (
    <div style={{ position:"fixed", bottom:24, right:24, zIndex:600, background:T.navy, color:T.white, padding:"10px 18px", borderRadius:10, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", boxShadow:"0 8px 32px rgba(0,0,0,0.25)", borderLeft:`3px solid ${T.gold}`, display:"flex", alignItems:"center", gap:8, animation:"slideUp 0.3s ease-out" }}>
      <span style={{ color:T.gold }}>{Ic.check}</span>{msg}
    </div>
  );
}

function SlidePanel({ open, onClose, title, children }) {
  return (
    <>
      {open && <div onClick={onClose} style={{ position:"fixed", inset:0, background:"rgba(17,29,53,0.45)", zIndex:300, backdropFilter:"blur(2px)" }} />}
      <div style={{ position:"fixed", top:0, right:0, bottom:0, width:500, background:T.white, boxShadow:"-8px 0 48px rgba(0,0,0,0.18)", zIndex:310, display:"flex", flexDirection:"column", transform:open?"translateX(0)":"translateX(105%)", transition:"transform 0.3s cubic-bezier(0.16,1,0.3,1)" }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"1.1rem 1.5rem", borderBottom:`1px solid ${T.border}`, background:T.navy, flexShrink:0 }}>
          <span style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.05rem", fontWeight:700, color:T.white }}>{title}</span>
          <button onClick={onClose} style={{ background:"rgba(255,255,255,0.1)", border:"none", borderRadius:6, padding:7, cursor:"pointer", color:T.white, display:"flex" }}>{Ic.x}</button>
        </div>
        <div style={{ flex:1, overflowY:"auto", padding:"1.4rem" }}>{children}</div>
      </div>
    </>
  );
}


/* ══════════════════════════════════════════════════════════════
   API / BACKEND INTEGRATION LAYER
══════════════════════════════════════════════════════════════ */

/**
 * useBackend – erkennt ob das Backend erreichbar ist.
 * Im Demo-Modus (kein Backend) werden alle Operationen gegen
 * den lokalen Reducer-State ausgeführt.
 */
function useBackend() {
  const [online,  setOnline]  = useState(null); // null = prüfend
  const [checked, setChecked] = useState(false);
  useEffect(() => {
    ping().then(ok => { setOnline(ok); setChecked(true); });
  }, []);
  return { online, checked };
}

/** Konvertiert ApiError → benutzerfreundliche deutsche Nachricht */
function apiErrMsg(err) {
  if (!err) return "Unbekannter Fehler.";
  if (err instanceof ApiError) {
    if (err.status === 0)   return "Keine Verbindung zum Server.";
    if (err.status === 401) return "Sitzung abgelaufen. Bitte neu anmelden.";
    if (err.status === 403) return "Keine Berechtigung für diese Aktion.";
    if (err.status === 404) return "Datensatz nicht gefunden.";
    if (err.status === 409) return "Konflikt: Datensatz existiert bereits.";
    if (err.status >= 500)  return `Serverfehler (${err.status}). Bitte IT informieren.`;
    return err.message || `Fehler ${err.status}`;
  }
  return err.message || "Unbekannter Fehler.";
}

/** Kleiner Status-Indikator für die TopNav */
function BackendBadge({ online }) {
  if (online === null) return (
    <div style={{ display:"flex", alignItems:"center", gap:5, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.72rem", color:"rgba(255,255,255,0.45)", padding:"4px 9px", background:"rgba(255,255,255,0.06)", borderRadius:6, border:"1px solid rgba(255,255,255,0.1)" }}>
      <span style={{ width:6, height:6, borderRadius:"50%", background:"rgba(255,255,255,0.3)" }}/>Verbinde …
    </div>
  );
  if (online) return (
    <div style={{ display:"flex", alignItems:"center", gap:5, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.72rem", color:"rgba(100,220,150,0.9)", padding:"4px 9px", background:"rgba(16,185,129,0.1)", borderRadius:6, border:"1px solid rgba(16,185,129,0.2)" }}>
      <span style={{ width:6, height:6, borderRadius:"50%", background:"#10b981" }}/>Live-API
    </div>
  );
  return (
    <div style={{ display:"flex", alignItems:"center", gap:5, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.72rem", color:"rgba(200,168,75,0.85)", padding:"4px 9px", background:"rgba(200,168,75,0.1)", borderRadius:6, border:"1px solid rgba(200,168,75,0.2)" }}>
      <span style={{ width:6, height:6, borderRadius:"50%", background:T.gold }}/>Demo-Modus
    </div>
  );
}

/** Lade-Skeleton für Tabellen / Karten */
function Skeleton({ width="100%", height=18, radius=6, style={} }) {
  return (
    <div style={{ width, height, borderRadius:radius, background:"linear-gradient(90deg,#f0ece4 25%,#e8e2d8 50%,#f0ece4 75%)", backgroundSize:"200% 100%", animation:"shimmer 1.5s infinite", ...style }}/>
  );
}

/** Fehler-Hinweis-Karte */
function ApiErrorBanner({ error, onRetry }) {
  if (!error) return null;
  return (
    <div style={{ background:T.redBg, border:`1px solid ${T.red}33`, borderRadius:10, padding:"10px 14px", display:"flex", alignItems:"center", gap:10, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", color:T.red, marginBottom:"1rem" }}>
      <span>⚠</span>
      <span style={{ flex:1 }}>{apiErrMsg(error)}</span>
      {onRetry && <Btn variant="danger" size="sm" onClick={onRetry}>Erneut versuchen</Btn>}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   LOGIN
══════════════════════════════════════════════════════════════ */
function LoginPage({ onLogin }) {
  const [email, setEmail] = useState("koch@anwalt-offenbach.de");
  const [pw, setPw]       = useState("Kanzlei2024!");
  const [loading, setL]   = useState(false);
  const [fehler, setF]    = useState("");
  const [ok, setOk]       = useState(false);

  useEffect(() => { setTimeout(() => setOk(true), 60); }, []);

  const submit = async () => {
    setF("");
    if (!email || !pw) { setF("Bitte alle Felder ausfüllen."); return; }
    setL(true);
    // Erst echtes Backend versuchen
    try {
      const benutzer = await apiAuth.login(email, pw);
      onLogin(benutzer);
      return;
    } catch (apiErr) {
      // Backend nicht erreichbar → Demo-Modus mit Mock-Credentials
      if (apiErr.status === 0 || apiErr.status == null) {
        if (email === "koch@anwalt-offenbach.de" && pw === "Kanzlei2024!") {
          onLogin(MOCK_USER);
          return;
        }
      }
      setF(apiErr.status === 401 ? "Ungültige E-Mail oder Passwort." : apiErrMsg(apiErr));
    }
    setL(false);
  };

  const inp = {
    width:"100%", padding:"11px 14px", border:`1.5px solid ${T.border}`,
    borderRadius:8, fontSize:"0.92rem", fontFamily:"'IBM Plex Sans',sans-serif",
    color:T.text, background:T.surface, outline:"none", boxSizing:"border-box",
  };

  return (
    <div style={{ minHeight:"100vh", display:"flex", background:`linear-gradient(145deg,${T.navyDark},${T.navy} 55%,${T.navyMid})`, position:"relative", overflow:"hidden" }}>
      <div style={{ position:"absolute", inset:0, backgroundImage:`linear-gradient(rgba(200,168,75,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(200,168,75,0.04) 1px,transparent 1px)`, backgroundSize:"48px 48px" }} />
      <div style={{ position:"absolute", inset:0, background:`radial-gradient(ellipse 700px 500px at 30% 40%,rgba(200,168,75,0.07) 0%,transparent 65%)` }} />

      {/* Left */}
      <div style={{ flex:1, display:"flex", flexDirection:"column", justifyContent:"center", padding:"4rem 5rem", position:"relative", opacity:ok?1:0, transform:ok?"none":"translateX(-20px)", transition:"all 0.7s cubic-bezier(0.16,1,0.3,1)" }}>
        <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:"3.5rem" }}>
          <div style={{ width:44, height:44, background:T.gold, borderRadius:10, display:"flex", alignItems:"center", justifyContent:"center", color:T.navy }}>{Ic.logo}</div>
          <div>
            <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.05rem", color:T.white }}>Koch, Schatz &amp; Kollegen</div>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.68rem", color:"rgba(255,255,255,0.45)", letterSpacing:"0.1em", textTransform:"uppercase" }}>Rechtsanwaltskanzlei · Offenbach</div>
          </div>
        </div>
        <h1 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"clamp(2.4rem,4vw,3.4rem)", fontWeight:700, color:T.white, lineHeight:1.1, marginBottom:"1rem" }}>
          Unfallakten<br/><em style={{ fontStyle:"normal", color:T.gold }}>Verwaltung</em>
        </h1>
        <p style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"1rem", color:"rgba(255,255,255,0.55)", lineHeight:1.75, maxWidth:420, fontWeight:300, marginBottom:"2.5rem" }}>
          Professionelles Aktenmanagementsystem für Verkehrsunfallmandate – von der Schadenserfassung bis zur vollständigen Regulierung.
        </p>
        {["PDF-Parsing mit automatischer Schadensextraktion","Word-Generierung: Forderungsschreiben & Anfragen","Automatischer E-Mail-Import per IMAP","Mehrbenutzerfähig mit Rollenkonzept"].map((f,i) => (
          <div key={i} style={{ display:"flex", alignItems:"center", gap:10, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", color:"rgba(255,255,255,0.5)", marginBottom:10, opacity:ok?1:0, transform:ok?"none":`translateX(-12px)`, transition:`all 0.5s ${0.3+i*0.07}s ease-out` }}>
            <span style={{ width:6, height:6, borderRadius:"50%", background:T.gold, flexShrink:0 }} />{f}
          </div>
        ))}
      </div>

      <div style={{ width:1, background:"linear-gradient(to bottom,transparent,rgba(200,168,75,0.2) 30%,rgba(200,168,75,0.2) 70%,transparent)" }} />

      {/* Card */}
      <div style={{ width:480, display:"flex", alignItems:"center", justifyContent:"center", padding:"3rem 3.5rem", opacity:ok?1:0, transform:ok?"none":"translateY(20px)", transition:"all 0.7s 0.1s cubic-bezier(0.16,1,0.3,1)" }}>
        <div style={{ width:"100%", background:"rgba(255,255,255,0.97)", borderRadius:20, padding:"2.8rem", boxShadow:"0 32px 80px rgba(0,0,0,0.35),0 0 0 1px rgba(200,168,75,0.2)" }}>
          <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.65rem", fontWeight:700, color:T.navy, marginBottom:4 }}>Anmelden</div>
          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", color:T.textMuted, marginBottom:"1.8rem" }}>Bitte melden Sie sich mit Ihren Zugangsdaten an.</div>
          {fehler && <div style={{ background:T.redBg, border:`1px solid ${T.red}55`, borderRadius:8, padding:"10px 14px", marginBottom:"1.2rem", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", color:T.red }}>{fehler}</div>}
          <div style={{ marginBottom:"1.2rem" }}>
            <label style={{ display:"block", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.72rem", fontWeight:600, color:T.textMid, letterSpacing:"0.06em", textTransform:"uppercase", marginBottom:6 }}>E-Mail</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key==="Enter"&&submit()} style={inp} onFocus={e=>e.target.style.borderColor=T.gold} onBlur={e=>e.target.style.borderColor=T.border} />
          </div>
          <div style={{ marginBottom:"1.5rem" }}>
            <label style={{ display:"block", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.72rem", fontWeight:600, color:T.textMid, letterSpacing:"0.06em", textTransform:"uppercase", marginBottom:6 }}>Passwort</label>
            <input type="password" value={pw} onChange={e => setPw(e.target.value)} onKeyDown={e => e.key==="Enter"&&submit()} style={inp} onFocus={e=>e.target.style.borderColor=T.gold} onBlur={e=>e.target.style.borderColor=T.border} />
          </div>
          <button onClick={submit} disabled={loading} style={{ width:"100%", padding:"13px", background:T.navy, color:T.white, border:"none", borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.9rem", fontWeight:600, cursor:loading?"default":"pointer", position:"relative", overflow:"hidden" }}>
            {loading ? "Anmelden …" : "Anmelden"}
            <div style={{ position:"absolute", bottom:0, left:0, right:0, height:3, background:`linear-gradient(90deg,${T.gold},${T.goldLight},${T.gold})` }} />
          </button>
          <div style={{ marginTop:"1.5rem", padding:"10px 14px", background:T.goldPale, border:`1px solid rgba(200,168,75,0.3)`, borderRadius:8, fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.72rem", color:T.navy, lineHeight:1.9 }}>
            Demo: koch@anwalt-offenbach.de<br />Passwort: Kanzlei2024!
          </div>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   TOP NAV
══════════════════════════════════════════════════════════════ */
function TopNav({ user, onLogout, backendOnline }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ height:56, background:T.navy, borderBottom:`3px solid ${T.gold}`, display:"flex", alignItems:"center", padding:"0 1.5rem", gap:16, flexShrink:0, zIndex:50, position:"relative" }}>
      <div style={{ display:"flex", alignItems:"center", gap:10 }}>
        <div style={{ width:32, height:32, background:T.gold, borderRadius:6, display:"flex", alignItems:"center", justifyContent:"center", color:T.navy }}>{Ic.logo}</div>
        <div>
          <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"0.9rem", color:T.white }}>Koch, Schatz &amp; Kollegen</div>
          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.62rem", color:"rgba(255,255,255,0.45)", letterSpacing:"0.1em", textTransform:"uppercase" }}>Unfallakten-System v1.0</div>
        </div>
      </div>
      <div style={{ flex:1 }} />
      <BackendBadge online={backendOnline} />
      <div style={{ position:"relative" }}>
        <button onClick={() => setOpen(o => !o)} style={{ display:"flex", alignItems:"center", gap:8, background:"rgba(255,255,255,0.08)", border:"1px solid rgba(255,255,255,0.12)", borderRadius:8, padding:"6px 12px", cursor:"pointer", color:T.white, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem" }}>
          <div style={{ width:26, height:26, background:T.gold, borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", color:T.navy }}>{Ic.user}</div>
          <span style={{ maxWidth:120, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{user.name}</span>
          <span style={{ fontSize:"0.63rem", background:"rgba(200,168,75,0.2)", color:T.gold, border:"1px solid rgba(200,168,75,0.3)", padding:"1px 7px", borderRadius:10 }}>Admin</span>
        </button>
        {open && (
          <div style={{ position:"absolute", top:"calc(100% + 8px)", right:0, background:T.white, border:`1px solid ${T.border}`, borderRadius:10, boxShadow:"0 8px 32px rgba(0,0,0,0.15)", minWidth:200, overflow:"hidden", zIndex:200 }}>
            <div style={{ padding:"12px 14px 8px", borderBottom:`1px solid ${T.border}` }}>
              <div style={{ fontSize:"0.82rem", fontWeight:600, color:T.text }}>{user.name}</div>
              <div style={{ fontSize:"0.73rem", color:T.textMuted }}>{user.email}</div>
            </div>
            <button onClick={() => { setOpen(false); onLogout(); }} style={{ width:"100%", display:"flex", alignItems:"center", gap:8, padding:"10px 14px", background:"none", border:"none", cursor:"pointer", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", color:T.red }}>
              {Ic.logout} Abmelden
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   TAB BAR
══════════════════════════════════════════════════════════════ */
function TabBar({ tabs, active, onActivate, onClose }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current?.querySelector('[data-active="true"]');
    el?.scrollIntoView({ behavior:"smooth", block:"nearest", inline:"nearest" });
  }, [active]);

  return (
    <div style={{ background:T.navyDark, borderBottom:"1px solid rgba(200,168,75,0.18)", display:"flex", alignItems:"stretch", flexShrink:0, height:42 }}>
      <div ref={ref} style={{ display:"flex", alignItems:"stretch", overflowX:"auto", flex:1, scrollbarWidth:"none" }}>
        {tabs.map(tab => {
          const isA = tab.id === active, isDash = tab.id === "dashboard";
          return (
            <div key={tab.id} data-active={isA} onClick={() => onActivate(tab.id)}
              style={{ display:"flex", alignItems:"center", gap:7, padding:"0 14px", minWidth:isDash?118:160, maxWidth:230, cursor:"pointer", background:isA?"rgba(255,255,255,0.06)":"transparent", borderRight:"1px solid rgba(255,255,255,0.06)", borderBottom:isA?`2px solid ${T.gold}`:"2px solid transparent", transition:"background 0.15s", flexShrink:0, userSelect:"none" }}>
              <span style={{ color:isA?T.gold:"rgba(255,255,255,0.38)", flexShrink:0 }}>{isDash ? Ic.dash : tab.id==="email-import" ? Ic.email : Ic.akte}</span>
              <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", fontWeight:isA?600:400, color:isA?T.white:"rgba(255,255,255,0.52)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", flex:1 }}>{tab.label}</span>
              {!isFixed && tab.status && <span style={{ width:6, height:6, borderRadius:"50%", background:STATUS_MAP[tab.status]?.color||"#888", flexShrink:0 }} />}
              {!isFixed && (
                <span onClick={e => { e.stopPropagation(); onClose(tab.id); }}
                  style={{ display:"flex", alignItems:"center", justifyContent:"center", width:18, height:18, borderRadius:4, color:"rgba(255,255,255,0.33)", transition:"all 0.12s", flexShrink:0 }}
                  onMouseEnter={e => { e.currentTarget.style.background="rgba(239,68,68,0.16)"; e.currentTarget.style.color="#ef4444"; }}
                  onMouseLeave={e => { e.currentTarget.style.background="transparent"; e.currentTarget.style.color="rgba(255,255,255,0.33)"; }}>
                  {Ic.x}
                </span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   DASHBOARD
══════════════════════════════════════════════════════════════ */
function DashboardView({ onOpenAkte, aktenState }) {
  const [suche, setSuche]   = useState("");
  const [filter, setFilter] = useState("alle");
  const [sortK, setSortK]   = useState("az");
  const [sortD, setSortD]   = useState("asc");
  const [apiError, setApiError]   = useState(null);
  const [liveAkten, setLiveAkten] = useState(null);
  const [loadingAkten, setLoadingAkten] = useState(true);

  useEffect(() => {
    apiAkten.statistik()
      .then(data => { if (data?.akten) setLiveAkten(data.akten); setApiError(null); })
      .catch(err => { /* Demo-Modus: Mock-Daten */ if (err?.status && err.status !== 0) setApiError(err); })
      .finally(() => setLoadingAkten(false));
  }, []);

  const akten = React.useMemo(() =>
    (liveAkten ?? BASE_AKTEN).map(a => ({ ...a, status: aktenState[a.id]?.status || a.status })),
    [liveAkten, aktenState]
  );

  const stats = React.useMemo(() => ({
    gesamt: akten.length,
    offen: akten.filter(a => a.status==="offen").length,
    in_reg: akten.filter(a => a.status==="in_regulierung").length,
    abg: akten.filter(a => a.status==="abgeschlossen").length,
    klage: akten.filter(a => a.status==="klage").length,
    brutto: akten.reduce((s,a) => s+a.brutto, 0),
    reg: BASE_AKTEN.map(a => aktenState[a.id]?.regulierungen||[]).flat().reduce((s,r) => s+r.betrag_reguliert, 0),
  }), [akten, aktenState]);

  const pie = React.useMemo(() => [
    { name:"Offen",         value:stats.offen,  color:T.blue  },
    { name:"Regulierung",   value:stats.in_reg, color:T.amber },
    { name:"Abgeschlossen", value:stats.abg,    color:T.green },
    { name:"Klage",         value:stats.klage,  color:T.red   },
  ].filter(d => d.value > 0), [stats]);

  const gefiltert = React.useMemo(() => akten
    .filter(a => filter==="alle" || a.status===filter)
    .filter(a => {
      if (!suche) return true;
      const bs = aktenState[a.id];
      const mandant = bs?.beteiligte?.find(b => b.rolle==="mandant");
      return [a.az, a.unfallort, mandant?.name, mandant?.vorname, mandant?.kfz]
        .some(f => f?.toLowerCase().includes(suche.toLowerCase()));
    })
    .sort((a, b) => {
      const va = a[sortK]??0, vb = b[sortK]??0;
      return sortD==="asc" ? (va<vb?-1:1) : (va>vb?-1:1);
    }),
  [akten, filter, suche, sortK, sortD, aktenState]);

  const sortBy = k => { if (sortK===k) setSortD(d => d==="asc"?"desc":"asc"); else { setSortK(k); setSortD("asc"); } };
  const SortIc = ({ k }) => <span style={{ opacity:sortK===k?1:0.3, marginLeft:3, fontSize:"0.66rem" }}>{sortK===k ? (sortD==="asc"?"▲":"▼") : "▲"}</span>;

  return (
    <div style={{ flex:1, overflowY:"auto", background:T.offWhite }}>
      <div style={{ maxWidth:1440, margin:"0 auto", padding:"1.75rem" }}>

        <div style={{ marginBottom:"1.5rem" }}>
          <h1 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.75rem", fontWeight:700, color:T.navy, margin:0 }}>Dashboard</h1>
          <p style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", color:T.textMuted, marginTop:4 }}>
            {new Date().toLocaleDateString("de-DE",{weekday:"long",year:"numeric",month:"long",day:"numeric"})}
          </p>
        </div>

        {/* Fehler-Banner (nur wenn Backend erreichbar war, aber API-Fehler zurückgab) */}
        <ApiErrorBanner error={apiError} onRetry={() => {
          setLoadingAkten(true); setApiError(null);
          apiAkten.statistik()
            .then(d => { if (d?.akten) setLiveAkten(d.akten); setApiError(null); })
            .catch(e => { if (e?.status && e.status !== 0) setApiError(e); })
            .finally(() => setLoadingAkten(false));
        }} />

        {/* KPI row */}
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(155px,1fr))", gap:"1rem", marginBottom:"1.25rem" }}>
          {loadingAkten
            ? Array.from({length:5}).map((_,i) => (
                <div key={i} style={{ background:T.white, borderRadius:12, padding:"1rem 1.25rem", border:`1px solid ${T.border}`, borderTop:`3px solid ${T.border}` }}>
                  <Skeleton width="55%" height={10} style={{ marginBottom:10 }} />
                  <Skeleton width="35%" height={30} />
                </div>
              ))
            : [
            { label:"Gesamt",       v:stats.gesamt, c:T.navy,  f:"alle"          },
            { label:"Offen",        v:stats.offen,  c:T.blue,  f:"offen"         },
            { label:"Regulierung",  v:stats.in_reg, c:T.amber, f:"in_regulierung"},
            { label:"Abgeschlossen",v:stats.abg,    c:T.green, f:"abgeschlossen" },
            { label:"Klage",        v:stats.klage,  c:T.red,   f:"klage"         },
          ].map((k,i) => (
            <div key={i} onClick={() => setFilter(k.f)} style={{ background:T.white, borderRadius:12, padding:"1rem 1.25rem", border:`1px solid ${T.border}`, borderTop:`3px solid ${k.c}`, boxShadow:"0 2px 6px rgba(0,0,0,0.04)", cursor:"pointer", transition:"transform 0.15s,box-shadow 0.15s" }}
              onMouseEnter={e => { e.currentTarget.style.transform="translateY(-2px)"; e.currentTarget.style.boxShadow="0 6px 20px rgba(0,0,0,0.09)"; }}
              onMouseLeave={e => { e.currentTarget.style.transform=""; e.currentTarget.style.boxShadow="0 2px 6px rgba(0,0,0,0.04)"; }}>
              <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.68rem", fontWeight:600, letterSpacing:"0.08em", textTransform:"uppercase", color:T.textMuted, marginBottom:8 }}>{k.label}</div>
              <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"2.2rem", fontWeight:700, color:k.c, lineHeight:1 }}>{k.v}</div>
            </div>
          ))}
          {!loadingAkten && <div style={{ background:T.white, borderRadius:12, padding:"1rem 1.25rem", border:`1px solid ${T.border}`, borderTop:`3px solid ${T.gold}`, boxShadow:"0 2px 6px rgba(0,0,0,0.04)", gridColumn:"span 2" }}>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.68rem", fontWeight:600, letterSpacing:"0.08em", textTransform:"uppercase", color:T.textMuted, marginBottom:8 }}>Gesamtschaden / Reguliert</div>
            <div style={{ display:"flex", alignItems:"baseline", gap:10, flexWrap:"wrap" }}>
              <span style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.5rem", fontWeight:700, color:T.navy }}>{fmt€(stats.brutto)}</span>
              <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.9rem", fontWeight:600, color:T.green }}>{fmt€(stats.reg)} reguliert</span>
            </div>
            <div style={{ marginTop:8, height:4, background:T.border, borderRadius:4, overflow:"hidden" }}>
              <div style={{ height:"100%", width:`${Math.round(stats.reg/stats.brutto*100)}%`, background:`linear-gradient(90deg,${T.gold},${T.goldLight})`, borderRadius:4 }} />
            </div>
            <div style={{ fontSize:"0.68rem", color:T.textMuted, marginTop:3 }}>{Math.round(stats.reg/stats.brutto*100)} %</div>
          </div>}
        </div>

        {/* Charts */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 190px", gap:"1rem", marginBottom:"1.25rem" }}>
          <Card><div style={{ padding:"1rem 1.4rem 0.4rem" }}>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:"0.8rem" }}>Neue Akten · 6 Monate</div>
            <ResponsiveContainer width="100%" height={115}><BarChart data={MONATS} barSize={15}><XAxis dataKey="m" tick={{fontSize:11,fontFamily:"'IBM Plex Sans',sans-serif",fill:T.textMuted}} axisLine={false} tickLine={false}/><YAxis hide/><Tooltip contentStyle={{fontFamily:"'IBM Plex Sans',sans-serif",fontSize:12,borderRadius:8,border:`1px solid ${T.border}`}} cursor={{fill:`${T.navy}08`}}/><Bar dataKey="a" fill={T.navy} radius={[4,4,0,0]}/></BarChart></ResponsiveContainer>
          </div></Card>
          <Card><div style={{ padding:"1rem 1.4rem 0.4rem" }}>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:"0.8rem" }}>Regulierungen (€)</div>
            <ResponsiveContainer width="100%" height={115}><LineChart data={MONATS}><XAxis dataKey="m" tick={{fontSize:11,fontFamily:"'IBM Plex Sans',sans-serif",fill:T.textMuted}} axisLine={false} tickLine={false}/><YAxis hide/><Tooltip formatter={v=>fmt€(v)} contentStyle={{fontFamily:"'IBM Plex Sans',sans-serif",fontSize:12,borderRadius:8,border:`1px solid ${T.border}`}} cursor={{stroke:`${T.gold}44`}}/><Line type="monotone" dataKey="r" stroke={T.gold} strokeWidth={2.5} dot={{fill:T.gold,r:3}} activeDot={{r:5}}/></LineChart></ResponsiveContainer>
          </div></Card>
          <Card style={{ padding:"1rem 1.25rem" }}>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:"0.6rem" }}>Status</div>
            <ResponsiveContainer width="100%" height={90}><PieChart><Pie data={pie} cx="50%" cy="50%" innerRadius={28} outerRadius={42} dataKey="value" paddingAngle={2}>{pie.map((d,i) => <Cell key={i} fill={d.color}/>)}</Pie></PieChart></ResponsiveContainer>
            <div style={{ display:"flex", flexDirection:"column", gap:4, marginTop:6 }}>
              {pie.map((d,i) => <div key={i} style={{ display:"flex", alignItems:"center", gap:6, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", color:T.textMid }}><span style={{ width:8, height:8, borderRadius:2, background:d.color, flexShrink:0 }}/>{d.name} ({d.value})</div>)}
            </div>
          </Card>
        </div>

        {/* Table */}
        <Card>
          <div style={{ display:"flex", alignItems:"center", gap:10, padding:"0.9rem 1.4rem", borderBottom:`1px solid ${T.border}`, flexWrap:"wrap" }}>
            <h2 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.1rem", fontWeight:700, color:T.navy, margin:0, flex:1 }}>Akten</h2>
            <div style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
              {[["alle","Alle"],["offen","Offen"],["in_regulierung","Regulierung"],["abgeschlossen","Abgeschlossen"],["klage","Klage"]].map(([s,l]) => {
                const cnt = s==="alle" ? akten.length : akten.filter(a=>a.status===s).length;
                const sm = STATUS_MAP[s];
                return (
                  <button key={s} onClick={() => setFilter(s)} style={{ padding:"4px 9px", borderRadius:20, border:`1px solid ${filter===s?(sm?.color||T.navy):T.border}`, background:filter===s?(sm?.bg||T.goldPale):"transparent", color:filter===s?(sm?.color||T.navy):T.textMuted, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, cursor:"pointer" }}>
                    {l} ({cnt})
                  </button>
                );
              })}
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:7, background:T.surface, border:`1px solid ${T.border}`, borderRadius:8, padding:"5px 10px" }}>
              <span style={{ color:T.textFaint }}>{Ic.search}</span>
              <input placeholder="Az., Mandant, Ort …" value={suche} onChange={e => setSuche(e.target.value)}
                style={{ border:"none", background:"transparent", outline:"none", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", color:T.text, width:180 }} />
            </div>
          </div>
          <div style={{ overflowX:"auto" }}>
            <table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead>
                <tr style={{ background:T.surface }}>
                  {[{k:"az",l:"Aktenzeichen"},{k:null,l:"Mandant"},{k:"unfalldatum",l:"Unfalldatum"},{k:"unfallort",l:"Unfallort"},{k:"status",l:"Status"},{k:"brutto",l:"Schaden"},{k:null,l:"Reguliert"}].map(c => (
                    <th key={c.l} onClick={() => c.k && sortBy(c.k)} style={{ padding:"8px 14px", textAlign:"left", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.69rem", fontWeight:600, color:T.textMuted, letterSpacing:"0.06em", textTransform:"uppercase", borderBottom:`1px solid ${T.border}`, cursor:c.k?"pointer":"default", whiteSpace:"nowrap", userSelect:"none" }}>
                      {c.l}{c.k && <SortIc k={c.k}/>}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {gefiltert.map((a, i) => {
                  const bs = aktenState[a.id];
                  const mandant = bs?.beteiligte?.find(b => b.rolle==="mandant");
                  const gesamtReg = bs?.regulierungen?.reduce((s,r) => s+r.betrag_reguliert, 0) || 0;
                  return (
                    <tr key={a.id} onClick={() => onOpenAkte(a)} style={{ cursor:"pointer", borderBottom:`1px solid ${T.borderSoft}`, background:i%2===0?T.white:T.surface, transition:"background 0.1s" }}
                      onMouseEnter={e => e.currentTarget.style.background = T.goldPale}
                      onMouseLeave={e => e.currentTarget.style.background = i%2===0?T.white:T.surface}>
                      <td style={{ padding:"10px 14px" }}><div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.83rem", fontWeight:600, color:T.navy, display:"flex", alignItems:"center", gap:4 }}>{a.az} <span style={{ color:T.goldLight, opacity:0.7 }}>{Ic.chevR}</span></div></td>
                      <td style={{ padding:"10px 14px" }}><div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.84rem", color:T.text }}>{mandant ? `${mandant.name}, ${mandant.vorname}` : "–"}</div><div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.7rem", color:T.textFaint }}>{mandant?.kfz||""}</div></td>
                      <td style={{ padding:"10px 14px", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.8rem", color:T.textMid, whiteSpace:"nowrap" }}>{a.unfalldatum}</td>
                      <td style={{ padding:"10px 14px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", color:T.textMid, maxWidth:180, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{a.unfallort}</td>
                      <td style={{ padding:"10px 14px" }}><StatusBadge status={bs?.status||a.status}/></td>
                      <td style={{ padding:"10px 14px", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.83rem", fontWeight:600, color:T.text, whiteSpace:"nowrap" }}>{fmt€(a.brutto)}</td>
                      <td style={{ padding:"10px 14px" }}>
                        {gesamtReg > 0 ? (
                          <div><div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.83rem", fontWeight:600, color:T.green }}>{fmt€(gesamtReg)}</div><div style={{ height:3, background:T.border, borderRadius:3, marginTop:2, width:60 }}><div style={{ height:"100%", background:T.green, borderRadius:3, width:`${Math.min(100,Math.round(gesamtReg/(a.brutto*(a.hq/100))*100))}%` }}/></div></div>
                        ) : <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", color:T.textFaint }}>–</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div style={{ padding:"8px 1.4rem", borderTop:`1px solid ${T.border}`, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.72rem", color:T.textFaint }}>
            {gefiltert.length} von {akten.length} Akten · Klick auf Zeile öffnet Akte als Tab
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   SECTION: ÜBERSICHT
══════════════════════════════════════════════════════════════ */
function UebersichtSection({ akte, st, dispatch }) {
  const [notizen, setNotizen] = useState(st.notizen || "");
  const [nChanged, setNC]     = useState(false);
  const [toast, setToast]     = useState("");

  const mandant   = st.beteiligte?.find(b => b.rolle==="mandant");
  const gegner    = st.beteiligte?.find(b => b.rolle==="gegner");
  const gesamtReg = st.regulierungen?.reduce((s,r) => s+r.betrag_reguliert, 0) || 0;
  const brutto    = st.schaden?.gesamt_brutto || akte.brutto;
  const netto     = brutto * (akte.hq / 100);
  const regGrad   = netto > 0 ? Math.min(100, Math.round(gesamtReg / netto * 100)) : 0;

  const InfoRow = ({ label, value }) => value ? (
    <div style={{ borderBottom:`1px solid ${T.borderSoft}`, padding:"7px 0", display:"flex", gap:12 }}>
      <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.72rem", color:T.textFaint, width:110, flexShrink:0, paddingTop:1 }}>{label}</span>
      <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", color:T.text }}>{value}</span>
    </div>
  ) : null;

  return (
    <>
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"1.25rem" }}>

        {/* Mandant */}
        <Card>
          <CardHead title="Mandant" />
          <div style={{ padding:"0.9rem 1.4rem" }}>
            {mandant ? (
              <>
                <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.1rem", fontWeight:700, color:T.navy, marginBottom:"0.75rem" }}>
                  {mandant.name}{mandant.vorname ? `, ${mandant.vorname}` : ""}
                  {mandant.firma && <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", fontWeight:400, color:T.textMuted, marginTop:2 }}>{mandant.firma}</div>}
                </div>
                <InfoRow label="Anschrift" value={[mandant.anschrift, mandant.plz, mandant.ort].filter(Boolean).join(" · ")} />
                <InfoRow label="E-Mail" value={mandant.email} />
                <InfoRow label="Telefon" value={mandant.telefon} />
                <InfoRow label="KFZ-Kennzeichen" value={mandant.kfz} />
                <InfoRow label="Fahrzeugtyp" value={mandant.kfz_typ} />
                <InfoRow label="Versicherung" value={mandant.versicherung} />
                <InfoRow label="Vers.-Nr." value={mandant.vers_nr} />
                <InfoRow label="IBAN" value={mandant.iban} />
              </>
            ) : <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", color:T.textFaint }}>Noch kein Mandant erfasst.</div>}
          </div>
        </Card>

        {/* Gegner */}
        <Card>
          <CardHead title="Gegner / Versicherung" />
          <div style={{ padding:"0.9rem 1.4rem" }}>
            {gegner ? (
              <>
                <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.1rem", fontWeight:700, color:T.navy, marginBottom:"0.75rem" }}>
                  {gegner.versicherung || gegner.name}
                  {gegner.firma && gegner.firma !== gegner.name && <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", fontWeight:400, color:T.textMuted, marginTop:2 }}>{gegner.firma}</div>}
                </div>
                <InfoRow label="Vers.-Nr." value={gegner.vers_nr} />
                <InfoRow label="Schaden-Nr." value={gegner.schaden_nr} />
                <InfoRow label="E-Mail" value={gegner.email} />
                <InfoRow label="Telefon" value={gegner.telefon} />
                <InfoRow label="KFZ" value={gegner.kfz} />
              </>
            ) : <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", color:T.textFaint }}>Noch kein Gegner erfasst.</div>}
          </div>
        </Card>

        {/* Regulierungsstand */}
        <Card style={{ padding:"1.1rem 1.4rem" }}>
          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:"1rem" }}>Regulierungsstand</div>
          <div style={{ display:"flex", gap:"1.5rem", flexWrap:"wrap", marginBottom:"1rem" }}>
            {[{l:"Brutto",v:fmt€(brutto),c:T.textMid},{l:`Netto (${akte.hq} %)`,v:fmt€(netto),c:T.navy},{l:"Reguliert",v:fmt€(gesamtReg),c:T.green},{l:"Offen",v:fmt€(Math.max(0,netto-gesamtReg)),c:gesamtReg>=netto?T.green:T.amber}].map((s,i) => (
              <div key={i}><div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.68rem", color:T.textFaint, marginBottom:3 }}>{s.l}</div><div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.1rem", fontWeight:700, color:s.c }}>{s.v}</div></div>
            ))}
          </div>
          <div style={{ height:8, background:T.border, borderRadius:4, overflow:"hidden", marginBottom:6 }}>
            <div style={{ height:"100%", width:`${regGrad}%`, background:regGrad>=100?`linear-gradient(90deg,${T.green},#34d399)`:`linear-gradient(90deg,${T.gold},${T.goldLight})`, borderRadius:4, transition:"width 0.8s" }} />
          </div>
          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.75rem", color:T.textMuted, display:"flex", justifyContent:"space-between" }}>
            <span>{regGrad} % reguliert</span>
            <span>{st.regulierungen?.length||0} Zahlung{(st.regulierungen?.length||0)!==1?"en":""}</span>
          </div>
        </Card>

        {/* Status + Notizen */}
        <Card style={{ padding:"1.1rem 1.4rem", display:"flex", flexDirection:"column", gap:"1rem" }}>
          <div>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:8 }}>Akten-Status</div>
            <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
              {["offen","in_regulierung","abgeschlossen","klage"].map(s => {
                const isA = (st.status||akte.status) === s, sm = STATUS_MAP[s];
                return <button key={s} onClick={async () => {
                  dispatch({ type:"SET_STATUS", akteId:akte.id, status:s });
                  setToast(`Status → ${sm.label}`);
                  try { await apiAkten.aktualisieren(akte.id, { status: s }); }
                  catch { /* Demo-Modus: lokale Änderung */ }
                }} style={{ padding:"5px 12px", borderRadius:20, border:`1.5px solid ${isA?sm.color:T.border}`, background:isA?sm.bg:"transparent", color:isA?sm.color:T.textMuted, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", fontWeight:isA?600:400, cursor:"pointer", transition:"all 0.15s" }}>{sm.label}</button>;
              })}
            </div>
          </div>
          <div style={{ flex:1, display:"flex", flexDirection:"column", gap:5 }}>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.08em" }}>Notizen</div>
            <textarea value={notizen} onChange={e => { setNotizen(e.target.value); setNC(true); }} rows={5} placeholder="Interne Notizen zur Akte …" style={{ flex:1, padding:"9px 11px", border:`1.5px solid ${T.border}`, borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", color:T.text, background:T.surface, outline:"none", resize:"vertical" }} onFocus={e => e.target.style.borderColor=T.gold} onBlur={e => e.target.style.borderColor=T.border} />
            {nChanged && <Btn variant="gold" size="sm" onClick={async () => { dispatch({ type:"SET_NOTIZEN", akteId:akte.id, notizen }); setNC(false); setToast("Notizen gespeichert."); try { await apiAkten.aktualisieren(akte.id, { notizen }); } catch {} }}>{Ic.check} Speichern</Btn>}
          </div>
        </Card>

        {/* Aktivitäten */}
        <Card style={{ gridColumn:"span 2" }}>
          <CardHead title="Letzte Aktivitäten" />
          <div style={{ padding:"0 1.4rem 0.75rem" }}>
            {(st.aktivitaeten||[]).map((a, i) => (
              <div key={a.id} style={{ display:"flex", alignItems:"flex-start", gap:12, paddingTop:"0.8rem", borderTop:i>0?`1px solid ${T.borderSoft}`:"none" }}>
                <div style={{ width:28, height:28, borderRadius:7, background:T.goldPale, display:"flex", alignItems:"center", justifyContent:"center", color:T.gold, flexShrink:0 }}>{Ic.akte}</div>
                <div style={{ flex:1 }}><span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", fontWeight:600, color:T.navy }}>{a.user}</span><span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", color:T.textMid }}> – {a.aktion}</span></div>
                <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.72rem", color:T.textFaint, whiteSpace:"nowrap" }}>{a.zeit}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </>
  );
}

/* ══════════════════════════════════════════════════════════════
   SECTION: BETEILIGTE
══════════════════════════════════════════════════════════════ */
const ROLLEN = [{value:"mandant",label:"Mandant"},{value:"gegner",label:"Gegner"},{value:"zeuge",label:"Zeuge"},{value:"sachverstaendiger",label:"Sachverständiger"},{value:"sonstiger",label:"Sonstiger"}];
const ROLLEN_C = { mandant:{c:T.blue,bg:T.blueBg}, gegner:{c:T.red,bg:T.redBg}, zeuge:{c:T.amber,bg:T.amberBg}, sachverstaendiger:{c:T.green,bg:T.greenBg}, sonstiger:{c:T.textMuted,bg:T.surface} };

function BeteiligteSection({ beteiligte, dispatch, akteId }) {
  const [panelOpen, setPOpen] = useState(false);
  const [editItem, setEdit]   = useState(null);
  const [form, setForm]       = useState({});
  const [toast, setToast]     = useState("");

  const empty = { rolle:"mandant", name:"", vorname:"", firma:"", email:"", telefon:"", anschrift:"", plz:"", ort:"", kfz:"", kfz_typ:"", versicherung:"", vers_nr:"", schaden_nr:"", iban:"", notizen:"" };
  const F = (k, l, t="text", ph="") => <FieldInput label={l} value={form[k]||""} onChange={v => setForm(p => ({...p,[k]:v}))} type={t} placeholder={ph} />;

  const [betSaving, setBetSaving] = useState(false);

  const save = async () => {
    if (!form.name) { alert("Name ist Pflichtfeld."); return; }
    setBetSaving(true);
    const betData = { ...form, id: editItem?.id || Date.now() };
    try {
      if (editItem?.id && typeof editItem.id === "number" && editItem.id < 1e12) {
        // Echter DB-Record → PATCH
        await apiBeteiligte.aktualisieren(akteId, editItem.id, form);
      } else {
        // Neuer Beteiligter → POST
        const created = await apiBeteiligte.erstellen(akteId, form);
        if (created?.id) betData.id = created.id;
      }
    } catch { /* Demo-Modus */ }
    dispatch({ type:"SAVE_BETEILIGTER", akteId, beteiligter: betData });
    setBetSaving(false);
    setPOpen(false);
    setToast(editItem ? "Beteiligter gespeichert." : "Beteiligter hinzugefügt.");
  };

  return (
    <>
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
      <Card>
        <CardHead title={`Beteiligte (${beteiligte.length})`} action={<Btn size="sm" onClick={() => { setEdit(null); setForm(empty); setPOpen(true); }}>{Ic.plus} Hinzufügen</Btn>} />
        {beteiligte.length === 0 ? (
          <div style={{ padding:"2rem", textAlign:"center", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", color:T.textFaint }}>Noch keine Beteiligten erfasst.</div>
        ) : (
          <div style={{ overflowX:"auto" }}>
            <table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead><tr style={{ background:T.surface }}>{["Rolle","Name / Firma","Kontakt","KFZ","Versicherung",""].map(h => <th key={h} style={{ padding:"8px 14px", textAlign:"left", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.69rem", fontWeight:600, color:T.textMuted, letterSpacing:"0.06em", textTransform:"uppercase", borderBottom:`1px solid ${T.border}` }}>{h}</th>)}</tr></thead>
              <tbody>
                {beteiligte.map((b, i) => {
                  const rc = ROLLEN_C[b.rolle] || ROLLEN_C.sonstiger;
                  return (
                    <tr key={b.id} style={{ borderBottom:`1px solid ${T.borderSoft}`, background:i%2===0?T.white:T.surface }}>
                      <td style={{ padding:"10px 14px" }}>
                        <span style={{ display:"inline-flex", alignItems:"center", gap:4, background:rc.bg, color:rc.c, border:`1px solid ${rc.c}33`, borderRadius:12, padding:"2px 8px", fontSize:"0.7rem", fontWeight:600 }}>
                          {ROLLEN.find(r => r.value===b.rolle)?.label || b.rolle}
                        </span>
                      </td>
                      <td style={{ padding:"10px 14px" }}>
                        <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", fontWeight:600, color:T.navy }}>{b.name}{b.vorname ? ` ${b.vorname}` : ""}</div>
                        {b.firma && <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.75rem", color:T.textMuted }}>{b.firma}</div>}
                        {(b.anschrift||b.ort) && <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.7rem", color:T.textFaint }}>{b.anschrift}{b.plz?` · ${b.plz}`:""}{b.ort?` ${b.ort}`:""}</div>}
                      </td>
                      <td style={{ padding:"10px 14px" }}>
                        {b.email && <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", color:T.textMid }}>{b.email}</div>}
                        {b.telefon && <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.77rem", color:T.textFaint }}>{b.telefon}</div>}
                      </td>
                      <td style={{ padding:"10px 14px" }}>
                        {b.kfz && <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.82rem", fontWeight:600, color:T.text }}>{b.kfz}</div>}
                        {b.kfz_typ && <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.74rem", color:T.textFaint }}>{b.kfz_typ}</div>}
                      </td>
                      <td style={{ padding:"10px 14px" }}>
                        {b.versicherung && <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", color:T.textMid }}>{b.versicherung}</div>}
                        {b.vers_nr && <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.72rem", color:T.textFaint }}>{b.vers_nr}</div>}
                        {b.schaden_nr && <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.72rem", color:T.textFaint }}>SN: {b.schaden_nr}</div>}
                      </td>
                      <td style={{ padding:"10px 14px" }}>
                        <div style={{ display:"flex", gap:4 }}>
                          <Btn size="sm" variant="secondary" onClick={() => { setEdit(b); setForm({...b}); setPOpen(true); }}>{Ic.edit}</Btn>
                          <Btn size="sm" variant="danger"    onClick={() => { if (confirm("Beteiligten entfernen?")) {
                          try { await apiBeteiligte.loeschen(akteId, b.id); } catch { /* Demo */ }
                          dispatch({ type:"DELETE_BETEILIGTER", akteId, id:b.id });
                        }; }}>{Ic.trash}</Btn>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <SlidePanel open={panelOpen} onClose={() => setPOpen(false)} title={editItem ? "Beteiligten bearbeiten" : "Beteiligten hinzufügen"}>
        <div style={{ display:"flex", flexDirection:"column", gap:13 }}>
          <FieldSelect label="Rolle" value={form.rolle||"mandant"} onChange={v => setForm(p => ({...p,rolle:v}))} options={ROLLEN} />
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>{F("name","Nachname *")} {F("vorname","Vorname")}</div>
          {F("firma","Firma / Organisation")}
          <hr style={{ border:"none", borderTop:`1px solid ${T.border}`, margin:"2px 0" }} />
          {F("anschrift","Anschrift")}
          <div style={{ display:"grid", gridTemplateColumns:"90px 1fr", gap:10 }}>{F("plz","PLZ")} {F("ort","Ort")}</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>{F("email","E-Mail","email")} {F("telefon","Telefon","tel")}</div>
          <hr style={{ border:"none", borderTop:`1px solid ${T.border}`, margin:"2px 0" }} />
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>{F("kfz","KFZ-Kennzeichen",undefined,"OF-AB 123")} {F("kfz_typ","Fahrzeugtyp",undefined,"VW Passat")}</div>
          {F("versicherung","Versicherung")}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>{F("vers_nr","Vers.-Nr.")} {F("schaden_nr","Schaden-Nr.")}</div>
          {F("iban","IBAN")}
          <hr style={{ border:"none", borderTop:`1px solid ${T.border}`, margin:"2px 0" }} />
          <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
            <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMid, letterSpacing:"0.05em", textTransform:"uppercase" }}>Notizen</label>
            <textarea value={form.notizen||""} onChange={e => setForm(p => ({...p,notizen:e.target.value}))} rows={3} style={{ padding:"8px 10px", border:`1.5px solid ${T.border}`, borderRadius:7, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", color:T.text, background:T.surface, outline:"none", resize:"vertical" }} onFocus={e => e.target.style.borderColor=T.gold} onBlur={e => e.target.style.borderColor=T.border} />
          </div>
          <div style={{ display:"flex", gap:8, paddingTop:4 }}>
            <Btn variant="primary" onClick={save} disabled={betSaving} style={{ flex:1 }}>
              {betSaving ? <><div style={{ width:12, height:12, border:"2px solid rgba(255,255,255,0.3)", borderTopColor:"white", borderRadius:"50%", animation:"spin 0.7s linear infinite" }}/> Speichern …</> : <>{Ic.check} Speichern</>}
            </Btn>
            <Btn variant="secondary" onClick={() => setPOpen(false)}>Abbrechen</Btn>
          </div>
        </div>
      </SlidePanel>
    </>
  );
}

/* ══════════════════════════════════════════════════════════════
   SECTION: SCHADEN
══════════════════════════════════════════════════════════════ */
const SCHADEN_F = [
  {k:"reparaturkosten",   l:"Reparaturkosten"},
  {k:"wiederbeschaffung", l:"Wiederbeschaffungswert"},
  {k:"restwert",          l:"Restwert",          abzug:true},
  {k:"wertminderung",     l:"Merkantile Wertminderung"},
  {k:"nutzungsausfall",   l:"Nutzungsausfall"},
  {k:"mietwagenkosten",   l:"Mietwagenkosten"},
  {k:"sv_kosten",         l:"SV-Kosten (Gutachter)"},
  {k:"abschleppkosten",   l:"Abschleppkosten"},
  {k:"standkosten",       l:"Standkosten"},
  {k:"anabmeldekosten",   l:"An-/Abmeldekosten"},
  {k:"schmerzensgeld",    l:"Schmerzensgeld"},
  {k:"sonstiges",         l:"Sonstiges"},
];

function SchadenSection({ schaden, hq, dispatch, akteId }) {
  const [form, setForm]     = useState({ ...schaden });
  const [changed, setChg]   = useState(false);
  const [saving, setSaving] = useState(false);
  const [toast, setToast]   = useState("");

  const upd = (k, v) => { setForm(p => ({...p,[k]:parseFloat(v)||0})); setChg(true); };

  const brutto = SCHADEN_F.reduce((s, f) => f.abzug ? s-(parseFloat(form[f.k])||0) : s+(parseFloat(form[f.k])||0), 0);
  const netto  = brutto * (hq / 100);

  const save = async () => {
    setSaving(true);
    const schadenData = { ...form, gesamt_brutto: brutto };
    try {
      await apiSchaden.speichern(akteId, schadenData);
    } catch (e) {
      // Demo-Modus: nur lokal speichern
    }
    dispatch({ type:"SAVE_SCHADEN", akteId, schaden: schadenData });
    setSaving(false); setChg(false); setToast("Schaden gespeichert.");
  };

  const quelleLabels = { manuell:"Manuell", gutachten_pdf:"Gutachten (PDF)", abrechnung_pdf:"Abrechnung (PDF)", korrektur:"Korrektur" };
  const quelleColors = { manuell:{c:T.textMuted,bg:T.surface}, gutachten_pdf:{c:T.blue,bg:T.blueBg}, abrechnung_pdf:{c:T.green,bg:T.greenBg}, korrektur:{c:T.amber,bg:T.amberBg} };
  const qc = quelleColors[form.quelle] || quelleColors.manuell;

  return (
    <>
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
      <Card>
        <CardHead
          title="Schadenpositionen"
          action={
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <span style={{ display:"inline-flex", alignItems:"center", gap:5, background:qc.bg, color:qc.c, border:`1px solid ${qc.c}33`, borderRadius:12, padding:"2px 8px", fontSize:"0.7rem", fontWeight:600 }}>
                {quelleLabels[form.quelle]||form.quelle}
              </span>
              {changed && <Btn variant="gold" onClick={save} disabled={saving}>{saving?"…":Ic.check} Speichern</Btn>}
            </div>
          }
        />
        <div style={{ padding:"1.25rem 1.4rem" }}>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(215px,1fr))", gap:"1rem", marginBottom:"1.4rem" }}>
            {SCHADEN_F.map(f => (
              <div key={f.k} style={{ display:"flex", flexDirection:"column", gap:4 }}>
                <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.69rem", fontWeight:600, color:f.abzug?T.red:T.textMid, letterSpacing:"0.04em", display:"flex", alignItems:"center", gap:3 }}>
                  {f.abzug && <span style={{ color:T.red }}>−</span>}{f.l}
                </label>
                <div style={{ display:"flex", border:`1.5px solid ${T.border}`, borderRadius:7, overflow:"hidden", background:T.surface }}
                  onFocusCapture={e => e.currentTarget.style.borderColor=T.gold}
                  onBlurCapture={e  => e.currentTarget.style.borderColor=T.border}>
                  <span style={{ padding:"7px 9px", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.78rem", color:T.textFaint, background:T.offWhite, borderRight:`1px solid ${T.border}`, flexShrink:0 }}>€</span>
                  <input type="number" min="0" step="0.01" value={form[f.k]||""} onChange={e => upd(f.k, e.target.value)} placeholder="0" style={{ flex:1, padding:"7px 9px", border:"none", background:"transparent", outline:"none", fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.86rem", color:T.text }} />
                </div>
                {f.k==="sonstiges" && (
                  <input placeholder="Beschreibung" value={form.sonstiges_beschr||""} onChange={e => setForm(p => ({...p,sonstiges_beschr:e.target.value}))} style={{ padding:"5px 8px", border:`1px solid ${T.border}`, borderRadius:6, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.77rem", color:T.textMid, background:T.surface, outline:"none" }} />
                )}
              </div>
            ))}
          </div>
          {/* Summe */}
          <div style={{ borderTop:`2px solid ${T.border}`, paddingTop:"1rem", display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:"1rem" }}>
            {[
              { l:"Gesamtschaden (Brutto)",   v:fmt€(brutto), c:T.navy,  bg:T.surface   },
              { l:`Netto (Haftung ${hq} %)`, v:fmt€(netto),  c:T.navy,  bg:T.goldPale  },
              { l:"Quelle",                   v:null,         c:T.text,  bg:T.surface   },
            ].map((s, i) => (
              <div key={i} style={{ background:s.bg, borderRadius:10, padding:"0.85rem 1rem", border:`1px solid ${T.border}` }}>
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.69rem", color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:6 }}>{s.l}</div>
                {i < 2 ? (
                  <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.5rem", fontWeight:700, color:s.c }}>{s.v}</div>
                ) : (
                  <select value={form.quelle||"manuell"} onChange={e => { setForm(p => ({...p,quelle:e.target.value})); setChg(true); }} style={{ padding:"5px 8px", border:`1px solid ${T.border}`, borderRadius:6, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", color:T.text, background:T.white, cursor:"pointer", outline:"none" }}>
                    <option value="manuell">Manuell</option>
                    <option value="gutachten_pdf">Gutachten (PDF)</option>
                    <option value="abrechnung_pdf">Abrechnung (PDF)</option>
                    <option value="korrektur">Korrektur</option>
                  </select>
                )}
              </div>
            ))}
          </div>
        </div>
      </Card>
    </>
  );
}

/* ══════════════════════════════════════════════════════════════
   SECTION: REGULIERUNGEN
══════════════════════════════════════════════════════════════ */
function RegulierungSection({ regulierungen, brutto, hq, dispatch, akteId }) {
  const [showForm, setShowF] = useState(false);
  const [form, setForm]      = useState({ datum:"", betrag_gefordert:"", betrag_reguliert:"", status:"teilreguliert", vers_referenz:"", kuerz_begruendung:"" });
  const [toast, setToast]    = useState("");

  const netto     = brutto * (hq / 100);
  const gesamtReg = regulierungen.reduce((s, r) => s + r.betrag_reguliert, 0);
  const regGrad   = netto > 0 ? Math.min(100, Math.round(gesamtReg / netto * 100)) : 0;
  const offen     = Math.max(0, netto - gesamtReg);

  const addReg = async () => {
    if (!form.datum || !form.betrag_reguliert) { alert("Datum und regulierter Betrag sind Pflichtfelder."); return; }
    const regData = { ...form, id: Date.now(), betrag_gefordert: parseFloat(form.betrag_gefordert)||0, betrag_reguliert: parseFloat(form.betrag_reguliert)||0 };
    try {
      const created = await apiSchaden.regulierungErfassen(akteId, regData);
      if (created?.id) regData.id = created.id;
    } catch { /* Demo-Modus */ }
    dispatch({ type:"ADD_REGULIERUNG", akteId, regulierung: regData });
    setShowF(false);
    setForm({ datum:"", betrag_gefordert:"", betrag_reguliert:"", status:"teilreguliert", vers_referenz:"", kuerz_begruendung:"" });
    setToast("Regulierung erfasst.");
  };

  return (
    <>
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
      <div style={{ display:"flex", flexDirection:"column", gap:"1.25rem" }}>

        {/* KPIs */}
        <Card style={{ padding:"1.1rem 1.4rem" }}>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:"1rem", marginBottom:"1rem" }}>
            {[{l:"Forderung (netto)",v:fmt€(netto),c:T.navy},{l:"Reguliert",v:fmt€(gesamtReg),c:T.green},{l:"Offen",v:fmt€(offen),c:offen>0?T.amber:T.green}].map((s,i) => (
              <div key={i} style={{ background:T.surface, borderRadius:9, padding:"0.85rem 1rem", border:`1px solid ${T.border}` }}>
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.69rem", color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:5 }}>{s.l}</div>
                <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.35rem", fontWeight:700, color:s.c }}>{s.v}</div>
              </div>
            ))}
          </div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:6 }}>
            <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", color:T.textMuted }}>Regulierungsgrad</span>
            <span style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.15rem", fontWeight:700, color:regGrad>=100?T.green:T.navy }}>{regGrad} %</span>
          </div>
          <div style={{ height:10, background:T.border, borderRadius:5, overflow:"hidden" }}>
            <div style={{ height:"100%", width:`${regGrad}%`, background:regGrad>=100?`linear-gradient(90deg,${T.green},#34d399)`:`linear-gradient(90deg,${T.gold},${T.goldLight})`, borderRadius:5, transition:"width 0.7s" }} />
          </div>
        </Card>

        {/* Timeline */}
        <Card>
          <CardHead title={`Regulierungen (${regulierungen.length})`} action={<Btn size="sm" onClick={() => setShowF(o => !o)}>{Ic.plus} Neue Regulierung</Btn>} />

          {showForm && (
            <div style={{ padding:"1.1rem 1.4rem", borderBottom:`1px solid ${T.border}`, background:T.goldPale }}>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(175px,1fr))", gap:"0.9rem", marginBottom:"1rem" }}>
                <FieldInput label="Datum *" value={form.datum} onChange={v => setForm(p => ({...p,datum:v}))} type="date" />
                <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
                  <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMid, letterSpacing:"0.05em", textTransform:"uppercase" }}>Gefordert (€)</label>
                  <input type="number" value={form.betrag_gefordert} onChange={e => setForm(p => ({...p,betrag_gefordert:e.target.value}))} placeholder={Math.round(netto)} style={{ padding:"8px 10px", border:`1.5px solid ${T.border}`, borderRadius:7, fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.86rem", color:T.text, background:T.surface, outline:"none" }} onFocus={e => e.target.style.borderColor=T.gold} onBlur={e => e.target.style.borderColor=T.border} />
                </div>
                <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
                  <label style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMid, letterSpacing:"0.05em", textTransform:"uppercase" }}>Reguliert (€) *</label>
                  <input type="number" value={form.betrag_reguliert} onChange={e => setForm(p => ({...p,betrag_reguliert:e.target.value}))} placeholder="0" style={{ padding:"8px 10px", border:`1.5px solid ${T.border}`, borderRadius:7, fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.86rem", color:T.text, background:T.surface, outline:"none" }} onFocus={e => e.target.style.borderColor=T.gold} onBlur={e => e.target.style.borderColor=T.border} />
                </div>
                <FieldSelect label="Status" value={form.status} onChange={v => setForm(p => ({...p,status:v}))} options={[{value:"vollreguliert",label:"Vollreguliert"},{value:"teilreguliert",label:"Teilreguliert"},{value:"abgelehnt",label:"Abgelehnt"},{value:"ausstehend",label:"Ausstehend"}]} />
                <FieldInput label="Vers.-Referenz" value={form.vers_referenz} onChange={v => setForm(p => ({...p,vers_referenz:v}))} placeholder="REF-2025-001" />
                <FieldInput label="Kürzungsbegründung" value={form.kuerz_begruendung} onChange={v => setForm(p => ({...p,kuerz_begruendung:v}))} placeholder="z.B. Wertminderung" />
              </div>
              <div style={{ display:"flex", gap:8 }}>
                <Btn variant="gold" onClick={addReg}>{Ic.check} Erfassen</Btn>
                <Btn variant="secondary" onClick={() => setShowF(false)}>Abbrechen</Btn>
              </div>
            </div>
          )}

          {regulierungen.length === 0 && !showForm ? (
            <div style={{ padding:"2rem", textAlign:"center", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", color:T.textFaint }}>Noch keine Regulierungen erfasst.</div>
          ) : (
            <div style={{ padding:"0.75rem 1.4rem 1rem" }}>
              {regulierungen.map((r, i) => {
                const diff = r.betrag_gefordert - r.betrag_reguliert;
                const rs = REG_STATUS[r.status] || REG_STATUS.ausstehend;
                return (
                  <div key={r.id} style={{ display:"flex", gap:14, paddingBottom:i<regulierungen.length-1?"1rem":"0", marginBottom:i<regulierungen.length-1?"1rem":"0", borderBottom:i<regulierungen.length-1?`1px dashed ${T.border}`:"none" }}>
                    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", flexShrink:0 }}>
                      <div style={{ width:12, height:12, borderRadius:"50%", background:rs.color, marginTop:3 }} />
                      {i < regulierungen.length-1 && <div style={{ flex:1, width:2, background:T.border, margin:"5px 0" }} />}
                    </div>
                    <div style={{ flex:1 }}>
                      <div style={{ display:"flex", alignItems:"center", gap:8, flexWrap:"wrap", marginBottom:6 }}>
                        <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.8rem", color:T.textMuted }}>{r.datum}</span>
                        {r.vers_referenz && <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.75rem", color:T.textFaint }}>{r.vers_referenz}</span>}
                        <StatusBadge status={r.status} map={REG_STATUS} />
                      </div>
                      <div style={{ display:"flex", gap:16, flexWrap:"wrap" }}>
                        {r.betrag_gefordert>0 && <div><div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.68rem", color:T.textFaint }}>Gefordert</div><div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.9rem", fontWeight:600, color:T.text }}>{fmt€(r.betrag_gefordert)}</div></div>}
                        <div><div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.68rem", color:T.textFaint }}>Reguliert</div><div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.9rem", fontWeight:600, color:T.green }}>{fmt€(r.betrag_reguliert)}</div></div>
                        {diff>0 && <div><div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.68rem", color:T.textFaint }}>Differenz</div><div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.9rem", fontWeight:600, color:T.red }}>−{fmt€(diff)}</div></div>}
                      </div>
                      {r.kuerz_begruendung && <div style={{ marginTop:5, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.79rem", color:T.textMuted, fontStyle:"italic" }}>„{r.kuerz_begruendung}"</div>}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      </div>
    </>
  );
}

/* ══════════════════════════════════════════════════════════════
   SECTION: DOKUMENTE
══════════════════════════════════════════════════════════════ */
const DOK_TYPEN = [{value:"gutachten",label:"Gutachten"},{value:"abrechnungsschreiben",label:"Abrechnungsschreiben"},{value:"forderungsschreiben",label:"Forderungsschreiben"},{value:"sachstandsanfrage",label:"Sachstandsanfrage"},{value:"klage",label:"Klage"},{value:"sonstiges",label:"Sonstiges"}];

function DokumenteSection({ dokumente, dispatch, akteId }) {
  const [dragging, setDrag]   = useState(false);
  const [uploading, setUpl]   = useState(false);
  const [uploadTyp, setTyp]   = useState("gutachten");
  const [toast, setToast]     = useState("");
  const inputRef              = useRef(null);

  const parseStyle = {
    erfolgreich:        { c:T.green,    bg:T.greenBg,  label:"Geparst"   },
    fehler:             { c:T.red,      bg:T.redBg,    label:"Fehler"    },
    ausstehend:         { c:T.textMuted,bg:T.surface,  label:"Ausstehend"},
    manuell_korrigiert: { c:T.blue,     bg:T.blueBg,   label:"Korrigiert"},
  };

  const [uploadProgress, setUploadProgress] = useState(0);

  const fakeUpload = async files => {
    if (!files.length) return;
    const f   = files[0];
    const ext = f.name.split(".").pop().toLowerCase();
    const typ = ["jpg","jpeg","png"].includes(ext) ? "jpg" : ext==="docx" ? "docx" : "pdf";
    setUpl(true); setUploadProgress(0);

    let dokData = {
      id: Date.now(), typ: uploadTyp, dateiname: f.name, dateityp: typ,
      groesse: f.size || Math.floor(Math.random()*900000+100000),
      hochgeladen_am: new Date().toLocaleString("de-DE",{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit"}),
      parse_status: typ==="pdf" ? "erfolgreich" : "ausstehend",
      parse_konfidenz: typ==="pdf" ? (0.7 + Math.random()*0.28) : null,
    };

    try {
      const created = await apiDokumente.hochladen(akteId, f, uploadTyp, pct => setUploadProgress(pct));
      if (created?.id) dokData = { ...dokData, ...created };
    } catch {
      // Demo-Modus: nur lokaler Fake-Upload
      await new Promise(r => setTimeout(r, 1200));
    }

    dispatch({ type:"ADD_DOKUMENT", akteId, dokument: dokData });
    setUpl(false); setUploadProgress(0);
    setToast(`${f.name} hochgeladen${typ==="pdf" ? " und geparst" : ""}.`);
  };

  return (
    <>
      {toast && <Toast msg={toast} onDone={() => setToast("")} />}
      <div style={{ display:"flex", flexDirection:"column", gap:"1.25rem" }}>

        {/* Upload */}
        <Card style={{ padding:"1.25rem 1.4rem" }}>
          <div style={{ marginBottom:"1rem", maxWidth:250 }}>
            <FieldSelect label="Dokumenttyp" value={uploadTyp} onChange={setTyp} options={DOK_TYPEN} />
          </div>
          <div
            onDragOver={e => { e.preventDefault(); setDrag(true); }}
            onDragLeave={() => setDrag(false)}
            onDrop={e => { e.preventDefault(); setDrag(false); fakeUpload([...e.dataTransfer.files]); }}
            onClick={() => !uploading && inputRef.current?.click()}
            style={{ border:`2px dashed ${dragging?T.gold:T.border}`, borderRadius:12, padding:"2.5rem 1.5rem", textAlign:"center", cursor:uploading?"default":"pointer", background:dragging?T.goldPale:"transparent", transition:"all 0.2s" }}>
            <input ref={inputRef} type="file" accept=".pdf,.docx,.jpg,.jpeg,.png" style={{ display:"none" }} onChange={e => fakeUpload([...e.target.files])} />
            {uploading ? (
              <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:12 }}>
                <div style={{ width:32, height:32, border:`3px solid ${T.goldTrim}`, borderTopColor:T.gold, borderRadius:"50%", animation:"spin 0.8s linear infinite" }} />
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", color:T.textMuted }}>Hochladen und analysieren …</div>
                {uploadProgress > 0 && uploadProgress < 100 && (
                  <div style={{ width:200 }}>
                    <div style={{ height:4, background:T.border, borderRadius:4, overflow:"hidden" }}>
                      <div style={{ height:"100%", width:`${uploadProgress}%`, background:`linear-gradient(90deg,${T.gold},${T.goldLight})`, borderRadius:4, transition:"width 0.3s" }}/>
                    </div>
                    <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.7rem", color:T.textFaint, textAlign:"center", marginTop:3 }}>{uploadProgress} %</div>
                  </div>
                )}
              </div>
            ) : (
              <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:10 }}>
                <span style={{ color:dragging?T.gold:T.textFaint }}>{Ic.upload}</span>
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.9rem", fontWeight:600, color:dragging?T.gold:T.textMid }}>Datei hier ablegen oder klicken</div>
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", color:T.textFaint }}>PDF, DOCX, JPG, PNG · max. 20 MB · PDFs werden automatisch geparst</div>
              </div>
            )}
          </div>
        </Card>

        {/* Liste */}
        <Card>
          <CardHead title={`Dokumente (${dokumente.length})`} />
          {dokumente.length === 0 ? (
            <div style={{ padding:"2rem", textAlign:"center", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", color:T.textFaint }}>Noch keine Dokumente hochgeladen.</div>
          ) : dokumente.map((d, i) => {
            const ps = parseStyle[d.parse_status] || parseStyle.ausstehend;
            const isPdf = d.dateityp === "pdf";
            return (
              <div key={d.id} style={{ display:"flex", alignItems:"center", gap:13, padding:"11px 1.4rem", borderBottom:i<dokumente.length-1?`1px solid ${T.borderSoft}`:"none", transition:"background 0.1s" }}
                onMouseEnter={e => e.currentTarget.style.background=T.surface}
                onMouseLeave={e => e.currentTarget.style.background="transparent"}>
                <div style={{ width:38, height:38, borderRadius:8, background:isPdf?T.redBg:T.blueBg, display:"flex", alignItems:"center", justifyContent:"center", color:isPdf?T.red:T.blue, flexShrink:0 }}>
                  {isPdf ? Ic.pdf : Ic.word}
                </div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", fontWeight:600, color:T.text, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{d.dateiname}</div>
                  <div style={{ display:"flex", alignItems:"center", gap:6, marginTop:3, flexWrap:"wrap" }}>
                    <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", background:T.surface, color:T.textMuted, border:`1px solid ${T.border}`, borderRadius:10, padding:"1px 7px" }}>{DOK_TYPEN.find(t => t.value===d.typ)?.label||d.typ}</span>
                    <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.69rem", color:T.textFaint }}>{fmtSize(d.groesse)}</span>
                    <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.69rem", color:T.textFaint }}>{d.hochgeladen_am}</span>
                  </div>
                </div>
                <div style={{ display:"flex", alignItems:"center", gap:8, flexShrink:0 }}>
                  {isPdf && (
                    <>
                      <span style={{ display:"inline-flex", alignItems:"center", gap:4, background:ps.bg, color:ps.c, border:`1px solid ${ps.c}33`, borderRadius:10, padding:"2px 8px", fontSize:"0.7rem", fontWeight:600 }}>
                        {d.parse_status==="erfolgreich" && Ic.check} {ps.label}
                      </span>
                      {d.parse_konfidenz != null && (
                        <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.77rem", fontWeight:600, color:d.parse_konfidenz>0.7?T.green:d.parse_konfidenz>0.4?T.amber:T.red }}>{Math.round(d.parse_konfidenz*100)} %</span>
                      )}
                    </>
                  )}
                  <Btn size="sm" variant="secondary" onClick={async () => {
                    try {
                      await apiDokumente.download(akteId, d.id, d.dateiname);
                    } catch {
                      setToast(`${d.dateiname} wird heruntergeladen … (Demo-Modus)`);
                    }
                  }}>{Ic.download}</Btn>
                  <Btn size="sm" variant="danger" onClick={() => { if (confirm("Dokument löschen?")) {
                          try { await apiDokumente.loeschen(akteId, d.id); } catch { /* Demo */ }
                          dispatch({ type:"DELETE_DOKUMENT", akteId, id:d.id });
                        }; }}>{Ic.trash}</Btn>
                </div>
              </div>
            );
          })}
        </Card>
      </div>
    </>
  );
}

/* ══════════════════════════════════════════════════════════════
   SECTION: WORD-GENERIERUNG
══════════════════════════════════════════════════════════════ */
function WordSection({ akte, st }) {
  const [loading, setL] = useState({});
  const [done,    setD] = useState({});
  const [toast, setT]   = useState("");

  const gen = async (typ, label) => {
    setL(p => ({...p,[typ]:true})); setD(p => ({...p,[typ]:false}));
    try {
      await apiWord.generieren(akte.id, typ);
    } catch {
      // Demo-Modus: Simulation
      await new Promise(r => setTimeout(r, 1600));
    }
    setL(p => ({...p,[typ]:false})); setD(p => ({...p,[typ]:true}));
    setT(`${label} erstellt und gespeichert.`);
  };

  const gegner   = st.beteiligte?.find(b => b.rolle==="gegner");
  const mandant  = st.beteiligte?.find(b => b.rolle==="mandant");
  const netto    = (st.schaden?.gesamt_brutto||akte.brutto) * (akte.hq/100);
  const gesamtReg= st.regulierungen?.reduce((s,r) => s+r.betrag_reguliert, 0) || 0;

  const docs = [
    { typ:"forderungsschreiben", label:"Forderungsschreiben",  icon:"⚖️", an:gegner?.versicherung||"Versicherung",  desc:"Schadensersatzforderung an den Haftpflichtversicherer gemäß §§ 7, 17, 18 StVG, § 115 VVG mit vollständiger Schadensaufstellung." },
    { typ:"sachstandsanfrage",   label:"Sachstandsanfrage",    icon:"📋", an:gegner?.versicherung||"Versicherung",  desc:"Nachfrage bei ausbleibender Regulierung nach 4–6 Wochen. Klageandrohung mit 7-Tage-Frist." },
    { typ:"abrechnungsuebersicht",label:"Abrechnungsübersicht",icon:"📊", an:mandant?.name||"Mandant",             desc:"Mandanteninformation über den aktuellen Regulierungsstand mit übersichtlicher Schadenaufstellung." },
  ];

  return (
    <>
      {toast && <Toast msg={toast} onDone={() => setT("")} />}
      <div style={{ display:"flex", flexDirection:"column", gap:"1.25rem" }}>

        <div style={{ background:T.navyDark, borderRadius:12, padding:"1rem 1.4rem", border:"1px solid rgba(200,168,75,0.2)", display:"flex", alignItems:"center", gap:14, flexWrap:"wrap" }}>
          <div style={{ color:T.gold }}>{Ic.word}</div>
          <div style={{ flex:1 }}>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.82rem", fontWeight:600, color:T.white }}>Dokumente werden automatisch aus den Aktendaten generiert</div>
            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.75rem", color:"rgba(255,255,255,0.48)", marginTop:2 }}>Kanzlei-Design (Navy/Gold) · DIN 5008 · Haftungsquote {akte.hq} %</div>
          </div>
          <div style={{ display:"flex", gap:16, flexShrink:0 }}>
            {[{l:"Forderung",v:fmt€(netto)},{l:"Reguliert",v:fmt€(gesamtReg)},{l:"Offen",v:fmt€(Math.max(0,netto-gesamtReg))}].map((s,i) => (
              <div key={i} style={{ textAlign:"center" }}>
                <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.9rem", fontWeight:600, color:T.white }}>{s.v}</div>
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.67rem", color:"rgba(255,255,255,0.44)", marginTop:1 }}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(290px,1fr))", gap:"1.25rem" }}>
          {docs.map(doc => {
            const isL = loading[doc.typ], isD = done[doc.typ];
            return (
              <Card key={doc.typ} style={{ padding:"1.4rem", display:"flex", flexDirection:"column", gap:14, transition:"transform 0.15s,box-shadow 0.15s" }}
                onMouseEnter={e => { e.currentTarget.style.transform="translateY(-2px)"; e.currentTarget.style.boxShadow="0 8px 24px rgba(0,0,0,0.09)"; }}
                onMouseLeave={e => { e.currentTarget.style.transform=""; e.currentTarget.style.boxShadow=""; }}>
                <div style={{ display:"flex", alignItems:"flex-start", gap:12 }}>
                  <div style={{ width:44, height:44, borderRadius:10, background:T.navy, display:"flex", alignItems:"center", justifyContent:"center", fontSize:"1.35rem", flexShrink:0 }}>{doc.icon}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1rem", fontWeight:700, color:T.navy }}>{doc.label}</div>
                    <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.71rem", color:T.textFaint, marginTop:2 }}>An: {doc.an}</div>
                  </div>
                  {isD && <span style={{ color:T.green }}>{Ic.check}</span>}
                </div>
                <p style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.81rem", color:T.textMuted, lineHeight:1.65, margin:0 }}>{doc.desc}</p>
                <div style={{ display:"flex", gap:8, marginTop:"auto" }}>
                  <button onClick={() => gen(doc.typ, doc.label)} disabled={isL}
                    style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", gap:7, padding:"9px 14px", background:isD?T.greenBg:T.navy, color:isD?T.green:T.white, border:isD?`1px solid ${T.green}33`:"none", borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.84rem", fontWeight:600, cursor:isL?"default":"pointer", opacity:isL?0.7:1, transition:"all 0.2s" }}>
                    {isL ? <><div style={{ width:13, height:13, border:"2px solid rgba(255,255,255,0.3)", borderTopColor:"white", borderRadius:"50%", animation:"spin 0.7s linear infinite" }}/> Erstellen …</> : isD ? <>{Ic.check} Erstellt</> : <>{Ic.word} Generieren &amp; Speichern</>}
                  </button>
                  <button onClick={async () => {
                    try {
                      await apiWord.vorschau(akte.id, doc.typ);
                    } catch {
                      setT(`Vorschau ${doc.label} (Demo: kein Backend)`);
                    }
                  }} style={{ padding:"9px 12px", background:T.surface, border:`1px solid ${T.border}`, borderRadius:8, cursor:"pointer", color:T.textMuted, display:"flex", alignItems:"center", gap:5, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.77rem", fontWeight:500 }}>
                    {Ic.download} Vorschau
                  </button>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </>
  );
}

/* ══════════════════════════════════════════════════════════════
   AKTE DETAIL VIEW
══════════════════════════════════════════════════════════════ */
function AkteDetailView({ akte, st, dispatch }) {
  const [sec, setSec] = useState("uebersicht");

  const tabs = [
    { id:"uebersicht",    label:"Übersicht" },
    { id:"beteiligte",    label:`Beteiligte (${st.beteiligte?.length||0})` },
    { id:"schaden",       label:"Schaden" },
    { id:"regulierung",   label:`Regulierung (${st.regulierungen?.length||0})` },
    { id:"dokumente",     label:`Dokumente (${st.dokumente?.length||0})` },
    { id:"word",          label:"Word-Generierung" },
  ];

  return (
    <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>

      {/* Header */}
      <div style={{ background:T.navy, padding:"1.1rem 1.75rem 0", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"flex-start", gap:13, marginBottom:"0.8rem", flexWrap:"wrap" }}>
          <div style={{ width:40, height:40, background:T.goldTrim, borderRadius:9, border:"1px solid rgba(200,168,75,0.3)", display:"flex", alignItems:"center", justifyContent:"center", color:T.gold, flexShrink:0 }}>{Ic.akte}</div>
          <div style={{ flex:1, minWidth:200 }}>
            <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.68rem", color:"rgba(200,168,75,0.65)", letterSpacing:"0.1em", textTransform:"uppercase", marginBottom:2 }}>Aktenzeichen</div>
            <h1 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.55rem", fontWeight:700, color:T.white, margin:0, lineHeight:1.1 }}>{akte.az}</h1>
            <div style={{ display:"flex", alignItems:"center", gap:8, marginTop:4, flexWrap:"wrap" }}>
              <StatusBadge status={st.status||akte.status} />
              <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.74rem", color:"rgba(255,255,255,0.45)" }}>{akte.unfalldatum}</span>
              <span style={{ color:"rgba(255,255,255,0.2)" }}>·</span>
              <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.74rem", color:"rgba(255,255,255,0.45)", maxWidth:240, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{akte.unfallort}</span>
              <span style={{ color:"rgba(255,255,255,0.2)" }}>·</span>
              <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.74rem", color:"rgba(255,255,255,0.45)" }}>Haftung {akte.hq} %</span>
            </div>
          </div>
          <div style={{ display:"flex", gap:14, background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:10, padding:"8px 15px", flexShrink:0, flexWrap:"wrap" }}>
            {[
              { l:"Schaden (brutto)", v:fmt€(akte.brutto) },
              { l:`Netto (${akte.hq} %)`, v:fmt€(akte.brutto*(akte.hq/100)) },
              { l:"Reguliert", v:fmt€(st.regulierungen?.reduce((s,r)=>s+r.betrag_reguliert,0)||0) },
            ].map((s,i) => (
              <div key={i} style={{ textAlign:"center" }}>
                <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.88rem", fontWeight:600, color:T.white }}>{s.v}</div>
                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.63rem", color:"rgba(255,255,255,0.4)", marginTop:2 }}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ display:"flex", overflowX:"auto", scrollbarWidth:"none" }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setSec(t.id)}
              style={{ padding:"8px 16px", background:"transparent", border:"none", borderBottom:sec===t.id?`2px solid ${T.gold}`:"2px solid transparent", color:sec===t.id?T.white:"rgba(255,255,255,0.5)", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.81rem", fontWeight:sec===t.id?600:400, cursor:"pointer", transition:"all 0.15s", whiteSpace:"nowrap", flexShrink:0 }}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Section content */}
      <div style={{ flex:1, overflowY:"auto", background:T.offWhite, padding:"1.5rem 1.75rem" }}>
        <div style={{ maxWidth:1200 }}>
          {sec==="uebersicht"   && <UebersichtSection akte={akte} st={st} dispatch={dispatch} />}
          {sec==="beteiligte"   && <BeteiligteSection beteiligte={st.beteiligte||[]} dispatch={dispatch} akteId={akte.id} />}
          {sec==="schaden"      && <SchadenSection schaden={st.schaden||{}} hq={akte.hq} dispatch={dispatch} akteId={akte.id} />}
          {sec==="regulierung"  && <RegulierungSection regulierungen={st.regulierungen||[]} brutto={st.schaden?.gesamt_brutto||akte.brutto} hq={akte.hq} dispatch={dispatch} akteId={akte.id} />}
          {sec==="dokumente"    && <DokumenteSection dokumente={st.dokumente||[]} dispatch={dispatch} akteId={akte.id} />}
          {sec==="word"         && <WordSection akte={akte} st={st} />}
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   AKTEN REDUCER
══════════════════════════════════════════════════════════════ */
function reducer(state, action) {
  const { akteId } = action;
  const cur = state[akteId] || {};
  switch (action.type) {
    case "SAVE_BETEILIGTER": {
      const list = cur.beteiligte || [];
      const idx  = list.findIndex(b => b.id === action.beteiligter.id);
      return { ...state, [akteId]:{ ...cur, beteiligte: idx>=0 ? list.map((b,i) => i===idx ? action.beteiligter : b) : [...list, action.beteiligter] } };
    }
    case "DELETE_BETEILIGTER":
      return { ...state, [akteId]:{ ...cur, beteiligte:(cur.beteiligte||[]).filter(b => b.id!==action.id) } };
    case "SAVE_SCHADEN":
      return { ...state, [akteId]:{ ...cur, schaden:action.schaden } };
    case "ADD_REGULIERUNG":
      return { ...state, [akteId]:{ ...cur, regulierungen:[...(cur.regulierungen||[]), action.regulierung] } };
    case "ADD_DOKUMENT":
      return { ...state, [akteId]:{ ...cur, dokumente:[...(cur.dokumente||[]), action.dokument] } };
    case "DELETE_DOKUMENT":
      return { ...state, [akteId]:{ ...cur, dokumente:(cur.dokumente||[]).filter(d => d.id!==action.id) } };
    case "SET_STATUS":
      return { ...state, [akteId]:{ ...cur, status:action.status } };
    case "SET_NOTIZEN":
      return { ...state, [akteId]:{ ...cur, notizen:action.notizen } };
    default: return state;
  }
}

/* ══════════════════════════════════════════════════════════════
   EMAIL IMPORT VIEW – MODUL 3
══════════════════════════════════════════════════════════════ */

const EMAIL_STATUS = {
  zugeordnet:       { label:"Zugeordnet",       color:T.green,    bg:T.greenBg  },
  nicht_zugeordnet: { label:"Nicht zugeordnet", color:T.amber,    bg:T.amberBg  },
  fehler:           { label:"Fehler",           color:T.red,      bg:T.redBg    },
  duplikat:         { label:"Duplikat",         color:T.textMuted,bg:T.surface  },
};

const MATCH_LABELS = {
  aktenzeichen:    { label:"Aktenzeichen",    color:T.blue  },
  kfz_kennzeichen: { label:"KFZ-Kennzeichen", color:T.green },
  absender_email:  { label:"Absender-E-Mail", color:T.amber },
};

const IMPORT_STEPS = [
  "Verbinde mit IMAP-Server …",
  "Prüfe auf neue E-Mails …",
  "Lade Nachrichten herunter …",
  "Parse E-Mail-Header …",
  "Ordne Akten zu …",
  "Speichere Anhänge …",
  "Aktualisiere Import-Log …",
];

function EmailImportView({ onOpenAkte }) {
  const [log, setLog]             = useState(MOCK_EMAIL_LOG_BASE);
  const [filter, setFilter]       = useState("alle");
  const [suche, setSuche]         = useState("");
  const [expanded, setExpanded]   = useState(null);
  const [importing, setImporting] = useState(false);
  const [importStep, setStep]     = useState(-1);
  const [importResult, setResult] = useState(null);
  const [toast, setToast]         = useState("");

  const stats = {
    gesamt:           log.length,
    zugeordnet:       log.filter(e => e.status==="zugeordnet").length,
    nicht_zugeordnet: log.filter(e => e.status==="nicht_zugeordnet").length,
    fehler:           log.filter(e => e.status==="fehler" || e.status==="duplikat").length,
    anhaenge:         log.flatMap(e => e.anhaenge||[]).length,
    ungelesen:        log.filter(e => !e.als_gelesen).length,
  };

  const gefiltert = log
    .filter(e => filter==="alle" || e.status===filter)
    .filter(e => {
      if (!suche) return true;
      const s = suche.toLowerCase();
      return [e.von_email, e.von_name, e.betreff, e.erkannt_az, e.erkannt_kfz, e.akte_az]
        .some(f => f?.toLowerCase().includes(s));
    });

  const startImport = async () => {
    if (importing) return;
    setImporting(true); setResult(null); setStep(0);

    // Schrittweise Animation
    let step = 0;
    const advanceStep = () => new Promise(r => {
      step++;
      if (step < IMPORT_STEPS.length) { setStep(step); setTimeout(r, 420 + Math.random()*160); }
      else { setStep(step); setTimeout(r, 300); }
    });

    // Backend-Aufruf parallel zur Animation
    const runAnimation = async () => {
      for (let i = 0; i < IMPORT_STEPS.length; i++) await advanceStep();
    };

    const apiCallPromise = apiEmail.starten().catch(() => null); // null bei Demo-Modus
    await Promise.all([runAnimation(), apiCallPromise.then(() => {})]);
    const apiResult = await apiCallPromise;

    const now = new Date().toLocaleTimeString("de-DE",{hour:"2-digit",minute:"2-digit"});

    if (apiResult?.neue_emails) {
      // Echte API-Antwort
      const newEntries = (apiResult.neue_emails || []).map((e, i) => ({ ...e, id: Date.now() + i, als_gelesen: false }));
      if (newEntries.length) setLog(prev => [...newEntries, ...prev]);
      setResult({ neu: apiResult.neue_emails.length, zugeordnet: apiResult.zugeordnet ?? 0, anhaenge: apiResult.anhaenge ?? 0 });
      setToast(`Import: ${apiResult.neue_emails.length} neue E-Mail(s) importiert.`);
    } else {
      // Demo-Modus: Mock-Einträge
      const newEntries = [
        { id:Date.now(),   empfangen_am:`09.03.2026 ${now}`, von_email:"rv-info@ruv.de",    von_name:"R+V Versicherung", betreff:"Weitere Unterlagen zu AZ 24-1087 angefordert",    erkannt_az:"24-1087", erkannt_kfz:null,      match:"aktenzeichen",    akte_az:"24-1087", akte_id:12, anhaenge:[{name:"Anforderung_RV_neu.pdf",size:98700,typ:"pdf",parse_status:"erfolgreich",konfidenz:0.84}], status:"zugeordnet", als_gelesen:false },
        { id:Date.now()+1, empfangen_am:`09.03.2026 ${now}`, von_email:"devk-info@devk.de", von_name:"DEVK",             betreff:"OF-WK 7 – ergänzende Stellungnahme zum Schaden", erkannt_az:null,      erkannt_kfz:"OF-WK 7",  match:"kfz_kennzeichen", akte_az:"25-0040", akte_id:3,  anhaenge:[],                                                                                           status:"zugeordnet", als_gelesen:false },
      ];
      setLog(prev => [...newEntries, ...prev]);
      setResult({ neu:2, zugeordnet:2, anhaenge:1 });
      setToast("Import abgeschlossen: 2 neue E-Mails importiert. (Demo-Modus)");
    }

    setImporting(false); setStep(-1);
  };

  const markRead    = id  => setLog(prev => prev.map(e => e.id===id ? {...e, als_gelesen:true} : e));
  const markAllRead = ()  => setLog(prev => prev.map(e => ({...e, als_gelesen:true})));

  const handleOpenAkte = entry => {
    const akte = BASE_AKTEN.find(a => a.id === entry.akte_id);
    if (akte) onOpenAkte(akte);
  };

  return (
    <div style={{ flex:1, overflowY:"auto", background:T.offWhite }}>
      {toast && <Toast msg={toast} onDone={() => setToast("")}/>}
      <div style={{ maxWidth:1440, margin:"0 auto", padding:"1.75rem" }}>

        {/* Header */}
        <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", marginBottom:"1.5rem", flexWrap:"wrap", gap:12 }}>
          <div>
            <h1 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.75rem", fontWeight:700, color:T.navy, margin:0 }}>E-Mail-Import</h1>
            <p style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", color:T.textMuted, marginTop:4 }}>
              Automatischer IMAP-Import · Letzte Synchronisation: <span style={{ fontWeight:600, color:T.text }}>{IMAP_CONFIG.letzte_sync} Uhr</span>
            </p>
          </div>
          <div style={{ display:"flex", gap:10, alignItems:"center", flexWrap:"wrap" }}>
            <div style={{ display:"flex", alignItems:"center", gap:7, background:T.white, border:`1px solid ${T.border}`, borderRadius:8, padding:"7px 13px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", color:T.textMid }}>
              <span style={{ width:8, height:8, borderRadius:"50%", background:T.green, display:"block" }}/>
              Verbunden · {IMAP_CONFIG.host}
            </div>
            {stats.ungelesen > 0 && (
              <button onClick={markAllRead} style={{ display:"flex", alignItems:"center", gap:6, padding:"7px 13px", background:T.surface, border:`1px solid ${T.border}`, borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", color:T.textMid, cursor:"pointer" }}>
                {Ic.check} Alle als gelesen
              </button>
            )}
            <button onClick={startImport} disabled={importing}
              style={{ display:"flex", alignItems:"center", gap:8, padding:"9px 18px", background:importing?T.navyMid:T.navy, color:T.white, border:"none", borderRadius:8, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", fontWeight:600, cursor:importing?"default":"pointer", position:"relative", overflow:"hidden", minWidth:200 }}>
              {importing
                ? <><div style={{ width:14, height:14, border:"2px solid rgba(255,255,255,0.3)", borderTopColor:"white", borderRadius:"50%", animation:"spin 0.7s linear infinite" }}/>{IMPORT_STEPS[importStep]||"…"}</>
                : <>{Ic.refresh} Jetzt importieren</>}
              <div style={{ position:"absolute", bottom:0, left:0, right:0, height:2, background:`linear-gradient(90deg,${T.gold},${T.goldLight})` }}/>
            </button>
          </div>
        </div>

        {/* Result Banner */}
        {importResult && (
          <div style={{ background:T.greenBg, border:`1px solid ${T.green}33`, borderRadius:10, padding:"12px 16px", marginBottom:"1.25rem", display:"flex", alignItems:"center", gap:12, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.85rem", color:T.green }}>
            {Ic.check}
            <span><strong>{importResult.neu} neue E-Mails</strong> importiert · {importResult.zugeordnet} Akten zugeordnet · {importResult.anhaenge} Anhang geparst</span>
            <button onClick={() => setResult(null)} style={{ marginLeft:"auto", background:"none", border:"none", cursor:"pointer", color:T.green, display:"flex" }}>{Ic.x}</button>
          </div>
        )}

        {/* KPI-Karten */}
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(155px,1fr))", gap:"1rem", marginBottom:"1.25rem" }}>
          {[
            { label:"Gesamt",           v:stats.gesamt,           c:T.navy,      f:"alle"            },
            { label:"Zugeordnet",       v:stats.zugeordnet,       c:T.green,     f:"zugeordnet"      },
            { label:"Nicht zugeordnet", v:stats.nicht_zugeordnet, c:T.amber,     f:"nicht_zugeordnet"},
            { label:"Fehler",           v:stats.fehler,           c:T.red,       f:"fehler"          },
            { label:"Anhänge",          v:stats.anhaenge,         c:T.blue,      f:"alle"            },
            { label:"Ungelesen",        v:stats.ungelesen,        c:T.textMuted, f:"alle"            },
          ].map((k,i) => (
            <div key={i} onClick={() => setFilter(k.f)} style={{ background:T.white, borderRadius:12, padding:"1rem 1.25rem", border:`1px solid ${T.border}`, borderTop:`3px solid ${k.c}`, boxShadow:"0 2px 6px rgba(0,0,0,0.04)", cursor:"pointer", transition:"transform 0.15s,box-shadow 0.15s" }}
              onMouseEnter={e => { e.currentTarget.style.transform="translateY(-2px)"; e.currentTarget.style.boxShadow="0 6px 20px rgba(0,0,0,0.09)"; }}
              onMouseLeave={e => { e.currentTarget.style.transform=""; e.currentTarget.style.boxShadow="0 2px 6px rgba(0,0,0,0.04)"; }}>
              <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.68rem", fontWeight:600, letterSpacing:"0.08em", textTransform:"uppercase", color:T.textMuted, marginBottom:8 }}>{k.label}</div>
              <div style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"2.2rem", fontWeight:700, color:k.c, lineHeight:1 }}>{k.v}</div>
            </div>
          ))}
        </div>

        {/* Charts + Config */}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 310px", gap:"1rem", marginBottom:"1.25rem" }}>
          <Card>
            <div style={{ padding:"1rem 1.4rem 0.6rem" }}>
              <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.08em", marginBottom:"0.8rem" }}>Import-Verlauf · 7 Tage</div>
              <ResponsiveContainer width="100%" height={140}>
                <BarChart data={EMAIL_TAGES_STATS} barSize={18} barCategoryGap="30%">
                  <XAxis dataKey="tag" tick={{fontSize:10,fontFamily:"'IBM Plex Sans',sans-serif",fill:T.textMuted}} axisLine={false} tickLine={false}/>
                  <YAxis hide/>
                  <Tooltip contentStyle={{fontFamily:"'IBM Plex Sans',sans-serif",fontSize:12,borderRadius:8,border:`1px solid ${T.border}`}}
                    formatter={(v,n) => [v, n==="zugeordnet"?"Zugeordnet":n==="nicht_zugeordnet"?"Nicht zugeordnet":"Fehler"]}/>
                  <Bar dataKey="zugeordnet"       fill={T.green} stackId="a" radius={[0,0,0,0]}/>
                  <Bar dataKey="nicht_zugeordnet" fill={T.amber} stackId="a" radius={[0,0,0,0]}/>
                  <Bar dataKey="fehler"           fill={T.red}   stackId="a" radius={[3,3,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
              <div style={{ display:"flex", gap:14, marginTop:6 }}>
                {[{c:T.green,l:"Zugeordnet"},{c:T.amber,l:"Nicht zugeordnet"},{c:T.red,l:"Fehler"}].map((d,i) => (
                  <div key={i} style={{ display:"flex", alignItems:"center", gap:5, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.72rem", color:T.textMuted }}>
                    <span style={{ width:10, height:10, borderRadius:2, background:d.c }}/>{d.l}
                  </div>
                ))}
              </div>
            </div>
          </Card>

          <Card>
            <CardHead title="IMAP-Konfiguration" action={
              <span style={{ display:"inline-flex", alignItems:"center", gap:5, background:T.greenBg, color:T.green, border:`1px solid ${T.green}33`, borderRadius:12, padding:"2px 9px", fontSize:"0.7rem", fontWeight:600 }}>
                <span style={{ width:6, height:6, borderRadius:"50%", background:T.green }}/> Verbunden
              </span>
            }/>
            <div style={{ padding:"0.9rem 1.4rem" }}>
              {[
                ["Server",       `${IMAP_CONFIG.host}:${IMAP_CONFIG.port}`],
                ["Protokoll",    "IMAP · SSL/TLS"],
                ["Benutzer",     IMAP_CONFIG.user],
                ["Ordner",       IMAP_CONFIG.ordner],
                ["Max. Fetch",   `${IMAP_CONFIG.max_fetch} E-Mails`],
                ["Nächste Sync", `${IMAP_CONFIG.naechste_sync} Uhr`],
              ].map(([l,v]) => (
                <div key={l} style={{ display:"flex", gap:10, padding:"6px 0", borderBottom:`1px solid ${T.borderSoft}` }}>
                  <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.71rem", color:T.textFaint, width:100, flexShrink:0, paddingTop:1 }}>{l}</span>
                  <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.79rem", color:T.text }}>{v}</span>
                </div>
              ))}
              <div style={{ marginTop:"0.9rem" }}>
                <Btn variant="secondary" size="sm" onClick={() => setToast("Konfiguration wird geöffnet …")} style={{ width:"100%" }}>
                  {Ic.settings} Konfiguration bearbeiten
                </Btn>
              </div>
            </div>
          </Card>
        </div>

        {/* Import-Log Tabelle */}
        <Card>
          <div style={{ display:"flex", alignItems:"center", gap:10, padding:"0.9rem 1.4rem", borderBottom:`1px solid ${T.border}`, flexWrap:"wrap" }}>
            <h2 style={{ fontFamily:"'Playfair Display',Georgia,serif", fontSize:"1.1rem", fontWeight:700, color:T.navy, margin:0, flex:1 }}>
              Import-Log
              {stats.ungelesen > 0 && <span style={{ marginLeft:8, fontSize:"0.72rem", fontWeight:600, background:T.blue, color:T.white, borderRadius:10, padding:"2px 8px" }}>{stats.ungelesen} neu</span>}
            </h2>
            <div style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
              {[["alle","Alle",stats.gesamt],["zugeordnet","Zugeordnet",stats.zugeordnet],["nicht_zugeordnet","Nicht zugeordnet",stats.nicht_zugeordnet],["fehler","Fehler",stats.fehler]].map(([f,l,cnt]) => {
                const es = EMAIL_STATUS[f]; const isA = filter===f;
                return <button key={f} onClick={() => setFilter(f)} style={{ padding:"4px 9px", borderRadius:20, border:`1px solid ${isA?(es?.color||T.navy):T.border}`, background:isA?(es?.bg||T.goldPale):"transparent", color:isA?(es?.color||T.navy):T.textMuted, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, cursor:"pointer" }}>{l} ({cnt})</button>;
              })}
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:7, background:T.surface, border:`1px solid ${T.border}`, borderRadius:8, padding:"5px 10px" }}>
              <span style={{ color:T.textFaint }}>{Ic.search}</span>
              <input placeholder="Absender, Betreff, AZ …" value={suche} onChange={e => setSuche(e.target.value)} style={{ border:"none", background:"transparent", outline:"none", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", color:T.text, width:195 }}/>
            </div>
          </div>

          <div style={{ overflowX:"auto" }}>
            <table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead>
                <tr style={{ background:T.surface }}>
                  {["","Empfangen","Absender","Betreff","Erkennung","Zugeordnete Akte","Anhänge","Status",""].map((h,i) => (
                    <th key={i} style={{ padding:"8px 12px", textAlign:"left", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.69rem", fontWeight:600, color:T.textMuted, letterSpacing:"0.06em", textTransform:"uppercase", borderBottom:`1px solid ${T.border}`, whiteSpace:"nowrap" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {gefiltert.map((e, i) => {
                  const isExp = expanded === e.id;
                  const mc = MATCH_LABELS[e.match];
                  const es = EMAIL_STATUS[e.status] || EMAIL_STATUS.nicht_zugeordnet;
                  return (
                    <React.Fragment key={e.id}>
                      <tr
                        style={{ borderBottom:`1px solid ${T.borderSoft}`, background:!e.als_gelesen?"rgba(59,130,246,0.04)":i%2===0?T.white:T.surface, cursor:"pointer", transition:"background 0.1s" }}
                        onMouseEnter={ev => ev.currentTarget.style.background = T.goldPale}
                        onMouseLeave={ev => ev.currentTarget.style.background = !e.als_gelesen?"rgba(59,130,246,0.04)":i%2===0?T.white:T.surface}>
                        <td style={{ padding:"10px 6px 10px 14px", width:18 }} onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}>
                          {!e.als_gelesen && <span style={{ width:8, height:8, borderRadius:"50%", background:T.blue, display:"block" }}/>}
                        </td>
                        <td style={{ padding:"10px 12px", whiteSpace:"nowrap" }} onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}>
                          <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.78rem", color:T.textMid }}>{e.empfangen_am}</div>
                        </td>
                        <td style={{ padding:"10px 12px", maxWidth:180 }} onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}>
                          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", fontWeight:e.als_gelesen?400:600, color:T.text, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{e.von_name||e.von_email}</div>
                          <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.7rem", color:T.textFaint, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{e.von_email}</div>
                        </td>
                        <td style={{ padding:"10px 12px", maxWidth:240 }} onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}>
                          <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.83rem", fontWeight:e.als_gelesen?400:600, color:T.text, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{e.betreff || <span style={{ color:T.textFaint }}>(kein Betreff)</span>}</div>
                        </td>
                        <td style={{ padding:"10px 12px" }} onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}>
                          {mc ? (
                            <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
                              <span style={{ display:"inline-flex", alignItems:"center", background:`${mc.color}18`, color:mc.color, border:`1px solid ${mc.color}33`, borderRadius:10, padding:"1px 7px", fontSize:"0.69rem", fontWeight:600, whiteSpace:"nowrap" }}>{mc.label}</span>
                              <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.75rem", color:T.textMid, fontWeight:600 }}>{e.erkannt_az || e.erkannt_kfz || "–"}</span>
                            </div>
                          ) : <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", color:T.textFaint }}>–</span>}
                        </td>
                        <td style={{ padding:"10px 12px" }}>
                          {e.akte_az ? (
                            <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                              <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.82rem", fontWeight:600, color:T.navy }}>{e.akte_az}</span>
                              <button onClick={ev => { ev.stopPropagation(); handleOpenAkte(e); }}
                                style={{ background:T.goldPale, border:`1px solid rgba(200,168,75,0.3)`, borderRadius:5, padding:"2px 7px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", cursor:"pointer", color:T.navy, fontWeight:600, display:"flex", alignItems:"center", gap:3 }}>
                                {Ic.chevR} Öffnen
                              </button>
                            </div>
                          ) : <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", color:T.textFaint }}>–</span>}
                        </td>
                        <td style={{ padding:"10px 12px" }} onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}>
                          {(e.anhaenge||[]).length > 0 ? (
                            <div style={{ display:"flex", alignItems:"center", gap:5 }}>
                              <span style={{ color:T.textMuted }}>{Ic.attach}</span>
                              <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", color:T.textMid }}>{e.anhaenge.length}</span>
                              {e.anhaenge.some(a => a.parse_status==="erfolgreich") && <span style={{ fontSize:"0.68rem", background:T.greenBg, color:T.green, border:`1px solid ${T.green}33`, borderRadius:8, padding:"0px 5px" }}>geparst</span>}
                            </div>
                          ) : <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", color:T.textFaint }}>–</span>}
                        </td>
                        <td style={{ padding:"10px 12px" }} onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}>
                          <StatusBadge status={e.status} map={EMAIL_STATUS}/>
                        </td>
                        <td style={{ padding:"10px 12px" }}>
                          <button onClick={() => { setExpanded(isExp?null:e.id); markRead(e.id); }}
                            style={{ background:"none", border:"none", cursor:"pointer", color:T.textFaint, display:"flex", padding:4, borderRadius:4 }}
                            onMouseEnter={ev => ev.currentTarget.style.color=T.navy}
                            onMouseLeave={ev => ev.currentTarget.style.color=T.textFaint}>
                            <svg viewBox="0 0 24 24" fill="currentColor" style={{ width:14, height:14, transform:isExp?"rotate(180deg)":"none", transition:"transform 0.2s" }}><path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"/></svg>
                          </button>
                        </td>
                      </tr>

                      {isExp && (
                        <tr>
                          <td colSpan={9} style={{ padding:"0 14px 14px 38px", background:T.goldPale, borderBottom:`1px solid ${T.border}` }}>
                            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:"1rem", paddingTop:"1rem" }}>
                              {/* E-Mail Details */}
                              <div>
                                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:8 }}>E-Mail-Details</div>
                                {[["Von",`${e.von_name} <${e.von_email}>`],["Betreff",e.betreff||"(kein Betreff)"],["Empfangen",e.empfangen_am],["Status",e.als_gelesen?"Gelesen":"Ungelesen"]].map(([l,v]) => (
                                  <div key={l} style={{ display:"flex", gap:8, marginBottom:6 }}>
                                    <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.71rem", color:T.textFaint, width:80, flexShrink:0 }}>{l}</span>
                                    <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.79rem", color:T.text, wordBreak:"break-all" }}>{v}</span>
                                  </div>
                                ))}
                                {e.fehler && <div style={{ marginTop:8, background:T.redBg, border:`1px solid ${T.red}33`, borderRadius:7, padding:"7px 10px", fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", color:T.red }}>⚠ {e.fehler}</div>}
                              </div>
                              {/* Parser */}
                              <div>
                                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:8 }}>Parser-Ergebnis</div>
                                {[["Erkanntes AZ",e.erkannt_az||"–"],["Erkanntes KFZ",e.erkannt_kfz||"–"],["Match-Methode",e.match?MATCH_LABELS[e.match]?.label:"Keine Übereinstimmung"],["Zugeordnet zu",e.akte_az||"–"]].map(([l,v]) => (
                                  <div key={l} style={{ display:"flex", gap:8, marginBottom:6 }}>
                                    <span style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.71rem", color:T.textFaint, width:120, flexShrink:0 }}>{l}</span>
                                    <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.79rem", color:T.text, fontWeight:(e.erkannt_az&&l==="Erkanntes AZ")||(e.akte_az&&l==="Zugeordnet zu")?600:400 }}>{v}</span>
                                  </div>
                                ))}
                              </div>
                              {/* Anhänge */}
                              <div>
                                <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.7rem", fontWeight:600, color:T.textMuted, textTransform:"uppercase", letterSpacing:"0.06em", marginBottom:8 }}>Anhänge ({(e.anhaenge||[]).length})</div>
                                {(e.anhaenge||[]).length === 0
                                  ? <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.8rem", color:T.textFaint }}>Keine Anhänge</div>
                                  : (e.anhaenge||[]).map((a,ai) => {
                                      const isPdf = a.typ==="pdf";
                                      const ps = a.parse_status==="erfolgreich"?{c:T.green,l:"Geparst"}:a.parse_status==="nicht_unterstuetzt"?{c:T.amber,l:"Nicht unterstützt"}:{c:T.textMuted,l:a.parse_status};
                                      return (
                                        <div key={ai} style={{ display:"flex", alignItems:"center", gap:8, background:T.white, border:`1px solid ${T.border}`, borderRadius:7, padding:"7px 10px", marginBottom:5 }}>
                                          <span style={{ color:isPdf?T.red:T.textMuted }}>{isPdf?Ic.pdf:Ic.attach}</span>
                                          <div style={{ flex:1, minWidth:0 }}>
                                            <div style={{ fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", fontWeight:600, color:T.text, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{a.name}</div>
                                            <div style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.68rem", color:T.textFaint }}>{fmtSize(a.size)}</div>
                                          </div>
                                          <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:2, flexShrink:0 }}>
                                            <span style={{ fontSize:"0.68rem", fontWeight:600, color:ps.c }}>{ps.l}</span>
                                            {a.konfidenz!=null && <span style={{ fontFamily:"'IBM Plex Mono',monospace", fontSize:"0.68rem", color:a.konfidenz>0.7?T.green:T.amber }}>{Math.round(a.konfidenz*100)} %</span>}
                                          </div>
                                        </div>
                                      );
                                    })
                                }
                                {e.akte_id && (
                                  <button onClick={() => handleOpenAkte(e)} style={{ marginTop:6, width:"100%", display:"flex", alignItems:"center", justifyContent:"center", gap:6, padding:"7px", background:T.navy, color:T.white, border:"none", borderRadius:7, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.78rem", fontWeight:600, cursor:"pointer" }}>
                                    {Ic.akte} Akte {e.akte_az} öffnen
                                  </button>
                                )}
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div style={{ padding:"8px 1.4rem", borderTop:`1px solid ${T.border}`, fontFamily:"'IBM Plex Sans',sans-serif", fontSize:"0.72rem", color:T.textFaint, display:"flex", justifyContent:"space-between" }}>
            <span>{gefiltert.length} von {log.length} Einträgen</span>
            <span>Klick auf Zeile expandiert Details · „Öffnen" springt zur Akte</span>
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   APP SHELL
══════════════════════════════════════════════════════════════ */
function AppShell({ user, onLogout }) {
  const [tabs, setTabs]          = useState([{ id:"dashboard", label:"Dashboard" }, { id:"email-import", label:"E-Mail-Import" }]);
  const [active, setActive]      = useState("dashboard");
  const [aktenState, dispatch]   = useReducer(reducer, INITIAL_STATE);
  const { online }               = useBackend();

  const handleLogout = useCallback(async () => {
    await apiAuth.logout().catch(() => {}); // immer ausloggen, auch bei Fehler
    onLogout();
  }, [onLogout]);

  const openAkte = useCallback((baseAkte) => {
    const tabId = `akte-${baseAkte.id}`;
    if (tabs.find(t => t.id===tabId)) { setActive(tabId); return; }
    setTabs(p => [...p, { id:tabId, label:baseAkte.az, status:aktenState[baseAkte.id]?.status||baseAkte.status, akte:baseAkte }]);
    setActive(tabId);
  }, [tabs, aktenState]);

  const closeTab = useCallback((tabId) => {
    if (tabId === "email-import") return; // protected tab
    setTabs(prev => {
      const filtered = prev.filter(t => t.id!==tabId);
      if (active===tabId) {
        const idx = prev.findIndex(t => t.id===tabId);
        setActive(prev[Math.max(0, idx-1)]?.id || "dashboard");
      }
      return filtered;
    });
  }, [active]);

  const tabsLive = tabs.map(t => t.akte ? { ...t, status:aktenState[t.akte.id]?.status||t.status } : t);
  const activeTab = tabs.find(t => t.id===active);

  return (
    <div style={{ height:"100vh", display:"flex", flexDirection:"column", overflow:"hidden" }}>
      <TopNav user={user} onLogout={handleLogout} backendOnline={online} />
      <TabBar tabs={tabsLive} active={active} onActivate={setActive} onClose={closeTab} />
      <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
        {active==="dashboard"    ? <DashboardView onOpenAkte={openAkte} aktenState={aktenState} />
        : active==="email-import"? <EmailImportView onOpenAkte={openAkte} />
        : activeTab?.akte        ? <AkteDetailView akte={activeTab.akte} st={aktenState[activeTab.akte.id]||{}} dispatch={dispatch} />
        : null}
      </div>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=IBM+Plex+Sans:wght@300;400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap');
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
        @keyframes slideUp { from { transform: translateY(16px); opacity: 0; } to { transform: none; opacity: 1; } }
        * { box-sizing: border-box; }
        body { margin: 0; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #d4ccbc; border-radius: 3px; }
        input[type=number]::-webkit-inner-spin-button { opacity: 0; }
      `}</style>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   ROOT
══════════════════════════════════════════════════════════════ */
export default function App() {
  const [user, setUser] = useState(null);
  if (!user) return <LoginPage onLogin={setUser} />;
  return <AppShell user={user} onLogout={() => setUser(null)} />;
}
