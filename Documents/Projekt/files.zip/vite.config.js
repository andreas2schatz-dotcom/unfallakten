// vite.config.js – Unfallakten Frontend
// ─────────────────────────────────────────────────────────────────────────────
// Proxy-Regel:  /auth/*, /akten/*, /email/*, /health  → Backend (Port 5000)
// SPA-Routing:  404 → index.html (React Router)
// Build-Output: dist/ (wird von nginx serviert)
// ─────────────────────────────────────────────────────────────────────────────

import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';

export default defineConfig(({ mode }) => ({
  plugins: [
    react({
      // Schnellere HMR durch Babel-Transforms
      fastRefresh: true,
    }),
  ],

  // ── Entwicklungs-Server ───────────────────────────────────────────────────
  server: {
    host:       '0.0.0.0',
    port:       5173,
    strictPort: true,

    // API-Proxy: lokales npm run dev → http://localhost:5000
    // In Docker:  VITE_BACKEND_URL=http://backend:5000 npm run dev
    proxy: {
      '/auth':   { target: process.env.VITE_BACKEND_URL || 'http://localhost:5000', changeOrigin: true },
      '/akten':  { target: process.env.VITE_BACKEND_URL || 'http://localhost:5000', changeOrigin: true },
      '/email':  { target: process.env.VITE_BACKEND_URL || 'http://localhost:5000', changeOrigin: true },
      '/health': { target: process.env.VITE_BACKEND_URL || 'http://localhost:5000', changeOrigin: true },
    },
  },

  // ── Preview-Server (nach Build) ───────────────────────────────────────────
  preview: {
    host: '0.0.0.0',
    port: 4173,
  },

  // ── Build-Konfiguration ───────────────────────────────────────────────────
  build: {
    outDir:        'dist',
    emptyOutDir:   true,
    sourcemap:     mode === 'development',  // Nur in Dev

    // Chunk-Splitting: Recharts und React separat cachen
    rollupOptions: {
      output: {
        manualChunks: {
          'react-vendor':    ['react', 'react-dom'],
          'recharts-vendor': ['recharts'],
        },
        // Statische Asset-Namen mit Hash für Cache-Busting
        assetFileNames:  'assets/[name]-[hash][extname]',
        chunkFileNames:  'assets/[name]-[hash].js',
        entryFileNames:  'assets/[name]-[hash].js',
      },
    },

    // Ziel: aktuelle Browser (kein IE11)
    target: 'es2020',

    // Warngrenze für Chunks (in kB)
    chunkSizeWarningLimit: 1000,
  },

  // ── Umgebungsvariablen ────────────────────────────────────────────────────
  // VITE_* Variablen werden ins Bundle eingebettet
  envPrefix: 'VITE_',

  // ── Resolve-Aliases ───────────────────────────────────────────────────────
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
    },
  },

  // ── Optimierungen ─────────────────────────────────────────────────────────
  optimizeDeps: {
    include: ['react', 'react-dom', 'recharts'],
  },
}));
